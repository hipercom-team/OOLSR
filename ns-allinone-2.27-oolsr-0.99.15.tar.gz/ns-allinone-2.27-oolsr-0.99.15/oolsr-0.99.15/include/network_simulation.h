//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NETWORK_SIMULATION_H
#define _NETWORK_SIMULATION_H

//---------------------------------------------------------------------------

#include "base.h"

#include <vector>

#include "scheduler.h"
class OLSRIface;

//---------------------------------------------------------------------------
// Simulation system network

/// An interface used for OLSR.
/// It performs whatever system calls are necessary to receive and send
/// packets
class SimulationIface
{
public:
  SimulationIface(IScheduler* aScheduler,
		  IPacketReceiver* aReceiver, Address aAddress);

  /// Send a packet to an interface ([mmr] the packet must be freed afterwise).
  void sendPacket(MemoryBlock* packet);

  /// Receive a packet (packet is owned).
  void receivePacket(MemoryBlock* packet, Address sendIfaceAddress);

  /// Return the maximum packet that the interface can send without IP
  /// fragmentation
  int getMTU();

  Address getAddress() 
  { return address; }

  void setOLSRIface(OLSRIface* aIface)
  { associatedIface = aIface; }

  OLSRIface* getOLSRIface()
  { return associatedIface; }

  void addDestination(SimulationIface* destinationIface)
  { destinationIfaceList.push_back(destinationIface); }

protected:
  /// The address of this interface
  Address address;

  /// The higher level interface associated to this system interface
  /// used when calling 
  OLSRIface* associatedIface;

  /// A scheduler
  IScheduler* scheduler;

  /// The list of ifaces this interface sends to
  std::vector<SimulationIface*> destinationIfaceList;

  /// The object which 
  IPacketReceiver* receiver;
};

//---------------------------------------------------------------------------

/// Limited network configurator
class SimulationNetworkConfigurator
{
public:
  /// Add one route in the kernel
  void addRoute(SimulationIface* iface, Address destIpAddress,
		Address gatewayAddress, Address netMaskAddress, 
		int metric);

  /// Remove one route from the kernel
  void removeRoute(SimulationIface* iface, Address destIpAddress,
		   Address gatewayAddress, Address netMaskAddress, 
		   int metric);
};

//---------------------------------------------------------------------------

#endif // _NETWORK_SIMULATION_H
