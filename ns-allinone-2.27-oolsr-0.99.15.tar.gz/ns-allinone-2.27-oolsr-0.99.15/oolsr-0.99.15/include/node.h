//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//            Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NODE_H
#define _NODE_H

//---------------------------------------------------------------------------

#include "base.h"
#include <list>
using std::list;

//---------------------------------------------------------------------------

#include "general.h"
#include "address.h"
#include "tuple.h"
#include "packet.h"
#include "protocol_config.h"
#include "scheduler_generic.h"
#include "log.h"
#include "protocol_tuple.h"
#include "protocol_observer.h"
#include "node_link_monitoring.h"

#ifdef WITH_MULTICAST_ENCAPSULATION
class EMMessage;
#endif

#ifdef MULTICAST_RESEARCH
//#include "sym.h"
class MC_Helper_;

class GMAMessage;
class MIMessage;
#endif /*MULTICAST_RESEARCH*/

//---------------------------------------------------------------------------

#if defined(MULTICAST_ENCAPSULATION) && defined(MULTICAST_RESEARCH)
class IMulticastManager
{
public:
  virtual void notifyReceiverAdd() = 0;
  virtual void notifyReceiverDelete() =0;
  virtual void notifySenderAdd() =0;
  virtual void notifySenderDelete() =0;

  virtual void receiveJoinedGroupMessage( /* XXX:... to do */ ) = 0;
  virtual bool shouldForward(EMMessage* encapsulatedMulticastMessage);
  
};

class IMulticastNode
{
public:
  virtual void sendJoinedGroupMessage
  (std::list< std::pair<Address, Time>>& content) = 0;
  virtual void* getNode() {}
};
#endif

//---------------------------------------------------------------------------

class OLSRIface; 

//---------------------------------------------------------------------------

class Node;

typedef void (Node::*NodeMethod)();
typedef void (Node::*NodeMethodArgVoid)(void*);

class NodeMethodCallback : public IEvent
{
public:
  NodeMethodCallback(Node* aNode, NodeMethodArgVoid aMethod)
    : node(aNode), method(aMethod) {}

  virtual void handleEvent(void* data) { (node->*method)(data); }

  Node* node;
  NodeMethodArgVoid method;
};

//--------------------------------------------------

class Node : public IPacketReceiver, public IProtocolSubject
	   //XXX ,public IMulticastNode
{
public:
#ifdef MULTICAST_RESEARCH
  MC_Helper_ *mc_helper;  // I can't remember is it right????
  // must call mc_helper.initMulticast when topology is stablized..
  void initMulticast();
  void startMulticast();
  void processMulticastJoinGroup(Address groupAddress); // from local node
  
  void processMulticastLeaveGroup(Address groupAddress); // from local node
  
  void processMulticastSenderJoin(Address groupAddress); // from local node
  
  void processMulticastSenderLeave(Address groupAddress); // from local node
  
  void processGMAMessage(GMAMessage* message);
  void processMIMessage(MIMessage* message);
  
  bool shouldForwardEMMessage(EMMessage* message);

  void writeJoinedGroupList(ostream& out);
  void writeGroupMap(ostream& out);

 void updateMulticastDistanceInfo();
  void eventGMAGeneration();
   void eventMIGeneration();
  unsigned int senderNum;
  bool isMember(Address group);

#else

#if 0
  bool shouldForwardEMMessage(EMMessage* message)
  { return true; }
#endif

#endif

  //-------------------- Initialization
  Node();

  virtual ~Node() {}

  /// XXX: obsolete doc warning!:
  /// Configure the node with several things:
  /// - Object composition: a IScheduler, a IOScheduler, a PacketManager,
  /// and a NetworkConfigurator are given to the Node, which will
  /// use them as a part of itself
  /// - Configuration of the protocol, and of the system is passed
  /// through ProtocolConfig and SystemConfig
  /// - the list of the interfaces of the node is also given.
  void configure(IScheduler* aBaseScheduler, 
		 AddressFactory* aAddressFactory,
		 PacketManager* aPacketManager,
		 INetworkConfigurator* aNetworkConfigurator,
		 ProtocolConfig* aProtocolConfig,
		 std::vector<ISystemIface*>& aSystemIfaceList,
		 Log* aLog);

  ///-------------------- General processing


  /// This used to cache informations
  /// int consistencyCounter;

  /// Start the OLSR node after everything has been properly configured
  virtual void start();

  bool isRunning()
  { return (getCurrentTime() > protocolConfig->startTime 
	    || protocolConfig->startTime<0)
      && (getCurrentTime() > protocolConfig->stopTime 
	  || protocolConfig->stopTime<0); }

  /// Remove all the expired tuples.
  virtual void performTupleExpiration();

  void eventPerformExpiration(void* timePtr);
  void getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime);
  void scheduleExpirationEvent();

  bool oneHopNeighborhoodChanged;

  void notifyOneHopNeighborhoodChange() 
  { 
    oneHopNeighborhoodChanged = true;
    shouldRecomputeRoute = true;
  }

  bool twoHopNeighborhoodChanged;

  void notifyTwoHopNeighborhoodChange() 
  { 
    twoHopNeighborhoodChanged = true;
    shouldRecomputeRoute = true;
  }

  void processChange(bool shouldUpdateTable)
  {
    if(oneHopNeighborhoodChanged || twoHopNeighborhoodChanged) {
      computeMPR(); // @@2362-2364
    }

    oneHopNeighborhoodChanged = false;
    twoHopNeighborhoodChanged = false;

    if(shouldUpdateTable && shouldRecomputeRoute) {
      bool shouldReallyComputeTable =
	(protocolConfig->routeCalculationStartTime < 0.0)
	|| (getCurrentTime() > protocolConfig->routeCalculationStartTime);

      if (shouldReallyComputeTable) {
	#ifdef MULTICAST_RESEARCH
		updateMulticastDistanceInfo();
	#endif
	if (!protocolConfig->noRouteCalculation) {
	  if (protocolConfig->fastRouteCalculation)
	    fasterComputeRoutingTable();
	  else computeRoutingTable();
	  shouldRecomputeRoute = false;
	}
      }
    }
  }

  //-------------------- Link Monitoring

  HeardIfaceSet heardIfaceSet;

  //-------------------- NeighborSensing

  /// [NeighborSensing] The Neighbor Tuple Set
  NeighborSet neighborSet;
 
  /// [NeighborSensing] The Link Tuple Set
  LinkSet linkSet;

  /// [NeighborSensing] The Two Hop Neighbor Set
  TwoHopNeighborSet twoHopNeighborSet;

  /// [NeighborSensing] This method is called when the OLSR Node is started
  void startNeighborSensing();

  /// [NeighborSensing] This method is called when an HelloMessage is received
  /// and should be processed.
  void processHelloMessage(/*borrowed*/ HelloMessage* message);

  LinkTuple* _processHelloLinkSet(HelloMessage* message);

  NeighborTuple* _processHelloNeighborSet(HelloMessage* hello,
					  LinkTuple* linkTuple);

  void _processHelloTwoHopNeighborSet(HelloMessage* hello,
				      NeighborTuple* neighborTuple);

  void _processHelloMPRSelectorSet(HelloMessage* hello,
				   NeighborTuple* neighborTuple);

  LinkEntry* _findAddrInLinkMessage(HelloMessage* hello, Address ifaceAddress,
				    bool notUnspecLink, bool mprNeigh);

  NeighborType _getNeighborType(Address mainAddress);



  /// [NeighborSensing] This method is called when an HelloMessage should
  /// be generated.
  void eventHelloGeneration();

  /// [NeighborSensing] Returns whether the address is the address of a
  /// symmetrical neighbor.
  /// Requirement: mainAddress should be a main address, not an interface
  /// address.
  bool isSymmetricNeighbor(const Address& mainAddress);

  /// [NeighborSensing] This method is called each time the MPR changed.
  /// This is an opportunity for neighbor sensing to send an additionnal
  /// HELLO for instance
  void eventMPRChange();

  /// [NeighborSensing] The MPR Selector Tuple Set.
  MPRSelectorSet mprSelectorSet;

  /// [NeighborSensing] Returns true if and only of ifaceAddress is the
  /// address of an interface of a node which choosed this node as MPR.
  bool isMPRSelector(Address ifaceAddress);

  //-------------------- TopologyDiscovery

  /// [TopologyDiscovery] The Topology Tuple Set
  TopologySet topologySet; 

  /// [TopologyDiscovery] This method is called when the OLSR Node is started
  void startTopologyDiscovery();

  /// [TopologyDiscovery] This method is called when an TCMessage is received
  /// and should be processed.
  void processTCMessage(/*borrowed*/ TCMessage* message);

  /// [TopologyDiscovery] This method is called when an TCMessage should
  /// be generated.
  void eventTCGeneration();

  //-------------------- MPRSelection
  list<NeighborTuple*> mprList;

  /// [MPRSelection] This method is called when the OLSR Node is started.
  void startMPRSelection();

  /// [MPRSelection] Recompute the MPR of the node.
  void computeMPR();

  /// [MPRSelection] Returns true if and only of ifaceAddress is the
  /// address of an interface of a node which is a MPR.
  bool isMPR(Address ifaceAddress);

  //-------------------- IfaceAssociationBase (see iface)

  /// [IfaceAssociationBase] The Multiple Interface Association Information
  /// Base.
  IfaceAssociationSet ifaceAssociationSet;

  /// [IfaceAssociationBase] This method is called when the OLSR Node 
  /// is started.
  void startIfaceAssociationBase();

  /// [IfaceAssociationBase] This method is called when an MIDMessage is
  /// received and should be processed.
  void processMIDMessage(/*borrowed*/ MIDMessage* message);

  /// [IfaceAssociationBase] This method is called when an MIDMessage should
  /// be generated.
  void eventMIDGeneration();

  /// [IfaceAssociationBase] Convert an interface address to a main address
  /// according to the Iface Association Tuple, and to the temporary
  /// association if one was set by setTemporaryIfaceAssociation
  /// and not removed later by forgetTemporaryIfaceAssociation
  Address ifaceToMainAddress(Address ifaceAddress);

  /// XXXWRONG: [IfaceAssociationBase] Set temporary interface association.
  /// This is used as an optimization when processing HELLO.
  void setTemporaryIfaceAssociation(Address mainAddress, Address ifaceAddress,
				    Time validityTime);

  /// XXXWRONG: [IfaceAssociationBase] Possibly remove the last temporary
  /// interface
  /// association
  /// set by the method setTemporaryIfaceAssociation.
  void forgetTemporaryIfaceAssociation();

  /// [PRP] used to maintain invariants properly
  void notifyNoLongerMainAddress(Address previousMainAddress);

  //-------------------- HNABase (see node_hna.cc)
  // [HNABase] The Host and Network Association Information Base
  HNASet hnaAssociationSet;

  /// [HNABase] The Host and Network Association advertised by
  /// this node.
  list< std::pair<Address,Address> > advertisedHNAList;

  /// [HNABase] This method is called when the OLSR Node 
  /// is started.
  void startHNABase();

  /// [HNABase] This method is called when an HNAMessage is
  /// received and should be processed.
  void processHNAMessage(/*borrowed*/ HNAMessage* message);

  /// [HNABase] This method is called when an HNAMessage should
  /// be generated.
  void eventHNAGeneration();

  //-------------------- RoutingTableCalculation (in node_route_calculation.cc)

  bool shouldRecomputeRoute;
  RoutingTable* currentRoutingTable;

  /// [RoutingTableCalculation] This method is called when the OLSR Node 
  /// is started.
  void startRoutingTableCalculation();

  /// [RoutingTableCalculation] Recompute the routing table
  void computeRoutingTable();
  void fasterComputeRoutingTable();

  /// [RoutingTableCalculation] (internal) Empties the current routing table.
  void _setRoutingTable(RoutingTable* routingTable);

  //-------------------- Jitter strategy (see node_general.cc)
  /// [JitterStrategy] Initialize the counters of the jitter strategy
  void startJitterStrategy();

  /// [JitterStrategy] The moment at which the node decide to send or
  /// not the message which are pending in the queues.
  void eventJitterStrategy(void* intAsVoidPtr);

  double jitterStrategyEventTime;
  unsigned int jitterStrategyEventIndex;

  void processJitterStrategy();

  typedef struct {
    Time minTime; Time maxTime; NodeMethod method; char* info;
  } GenerationEvent;

  list<GenerationEvent> generationEventList;

  /// [JitterStrategy] The 
  void addGenerationEvent(Time minDelay, Time maxDelay,
			  NodeMethod method, char* info)

  { 
    D(*log, lEventStrategy, getRealTime() << " [add-generation-event] " 
      << minDelay << " " << maxDelay << " " << info << endl);
    GenerationEvent event = { minDelay, maxDelay, method, info };
    generationEventList.push_back(event);
  }
  
  void scheduleNextJitterStrategyEvent(bool shouldReschedule = false);

  Time adjustTimeWithGeneration(Time upcomingTime, bool& hasChanged);


  //-------------------- Internal data

  AddressFactory* getAddressFactory() { return addressFactory; }
  PacketManager* getPacketManager() { return packetManager; }

  //-------------------- Debugging
  unsigned int nodeInstanceIdx;
  unsigned int eventCounter;
  Log* log;

  //-------------------- Extensions
  void addMessageHandler(unsigned int messageType,
			 IMessageHandler* handler)
  { packetManager->addMessageHandler(messageType, handler); }


  //-------------------- Autoconfiguration
#ifdef NU_AUTOCONF
  // Propagate the changes back to the tuple sets and other data structures
  virtual void propagateAddressChange(AddressMap<Address>& addressChange);
#endif /*NU_AUTOCONF*/

  //-------------------------------------------------- 
  // [IProtocolSubject]

  list<IProtocolObserver*> observerList;

  virtual void attach(IProtocolObserver* observer,
		      bool observeMajorTupleChange,
		      bool observeMinorTupleChange);
  virtual void detach(IProtocolObserver* observer);

  virtual vector<string>* getTableNameList(); /* result is owned */
  virtual vector<vector<string>*>* getTableContent(string name);

  //--------------------------------------------------

  Time _startDelay(Time minDelay, Time maxDelay)
  { 
    if (protocolConfig->delayGeneration) 
      return drawDouble(maxDelay-minDelay)+minDelay;
    else return minDelay;
  }

  //--------------------------------------------------

protected:
  Time currentTime;
  Time expiredTime;
  Time nextTupleExpireTime;
  PacketManager* packetManager;
  ProtocolConfig* protocolConfig; /// The configuration of the protocol
  IScheduler* baseScheduler;
  INetworkConfigurator* networkConfigurator;
  AddressFactory* addressFactory; //XXX: not initialized

  list<OLSRIface*> ifaceList; /// The list of interfaces of the node
  /// the first interface is the interface with the main address

public:
  //--------------------------------------------------
  // Implementation of INodeFacade

  int getMprCoverage() { return protocolConfig->mpr_coverage; }

  double getHysteresisThresholdHigh() 
  { return protocolConfig->hyst_threshold_high; }

  double getHysteresisThresholdLow() 
  { return protocolConfig->hyst_threshold_low; }

  double getHysteresisScaling() 
  { return protocolConfig->hyst_scaling; }

  int getSignalThresholdHigh() 
  { return protocolConfig->signal_threshold_high; }

  int getSignalThresholdLow() 
  { return protocolConfig->signal_threshold_low; }

  virtual Time getExpireTime() { return expiredTime; }

  virtual Time getCurrentTime() { return currentTime; }

  virtual Time getRealTime() { return baseScheduler->getTime(); }

  virtual Address getMainAddress()
  { return getMainIface()->getAddress(); }

  virtual OLSRIface* getMainIface() { return ifaceList.front(); }

  list<Address>* addressListCache;

  virtual list<Address>* getAddressList()
  { 
    if(addressListCache == NULL) {
      addressListCache = new list<Address>;
      for(std::list<OLSRIface*>::iterator it = ifaceList.begin();
	  it != ifaceList.end(); it++) 
	addressListCache->push_back((*it)->getAddress());
    }
    return addressListCache;
  }

  virtual list<OLSRIface*>* getIfaceList()
  { return &ifaceList; }

  virtual OLSRIface* getIfaceByAddress(Address address)
  {
    for(std::list<OLSRIface*>::iterator it = ifaceList.begin(); 
	it != ifaceList.end(); it++) 
      if ((*it)->getAddress() == address)
	return (*it);
    return NULL;
  }

  bool isOneOfOurIfaceAddress(Address address)
  { return getIfaceByAddress(address) != NULL; }

  virtual ProtocolConfig* getProtocolConfig() { return protocolConfig; }

  /// facade for IScheduler::addEvent
  virtual EventIdentifier addEvent(Time relativeTime, IEvent* event,
				   void* data)
  { return baseScheduler->addEvent(relativeTime, event, data); }

  /// facade for IScheduler::addEventAt
  virtual EventIdentifier addEventAt(Time absoluteTime, IEvent* event,
				     void* data)
  { return baseScheduler->addEventAt(absoluteTime, event, data); }

  //--------------------------------------------------
  // Implementation of IPacketReceiver
  // (packet:owned)
  virtual void evReceivePacket(/*owned*/ MemoryBlock* packet,
			       Address sendIfaceAddress,
			       OLSRIface* recvIface);


  //--------------------------------------------------
  DuplicateSet duplicateSet;

  //--------------------------------------------------
  // Miscellaneous functions

  void logState(ostream& out);

  void writeMPRSet(ostream& out);

  void writeIfaceList(ostream& out);

  void dumpMPR() { writeMPRSet(cerr); }
  void dumpOneHop() { neighborSet.write(cerr); }
  void dumpTwoHop() { twoHopNeighborSet.write(cerr); }
  void dump();

protected:
 
  // Utility function
  void updateCurrentTime()
  { currentTime = getRealTime(); }


  void preEvent(const char* eventName)
  {
    eventCounter++;
    if(log->lState && (log->out!=NULL)) {
      (*log->out) << getRealTime() << " [event-begin] " << getRealTime()
		  << " " << eventName << " " << getMainAddress() 
		  << " #" << eventCounter << endl;
      logState(*log->out);
    }
  }

  void postEvent(const char* eventName)
  {
    if(log->lState && (log->out!=NULL)) {
      logState(*log->out);
      (*log->out) << getRealTime() << " [event-end] " << getRealTime()
		  << " " << eventName << " " << getMainAddress() 
		  << " #" << eventCounter << endl;
    }
  }
};

//---------------------------------------------------------------------------

struct HasLinkNeighborAddress 
{
  HasLinkNeighborAddress(Node* aNode, Address mainAddress) 
    : node(aNode), address(mainAddress) {}
  bool operator () (LinkTuple& linkTuple) 
  { return address == 
      node->ifaceToMainAddress(linkTuple.L_neighbor_iface_addr);}

  HasLinkNeighborAddress()
  { Fatal("Must not be called"); } // Only for swig, do not use

  Node* node;
  Address address;
};

struct HasTwoHopNeighborAddress 
{
  HasTwoHopNeighborAddress(Address mainAddress) 
    : address(mainAddress) {}
  bool operator () (TwoHopNeighborTuple& twoHopTuple) 
  { return address == twoHopTuple.N_neighbor_main_addr; }

  HasTwoHopNeighborAddress()
  { Fatal("Must not be called"); } // Only for swig, do not use

  Address address;
};

//---------------------------------------------------------------------------

#endif // _NODE_H
