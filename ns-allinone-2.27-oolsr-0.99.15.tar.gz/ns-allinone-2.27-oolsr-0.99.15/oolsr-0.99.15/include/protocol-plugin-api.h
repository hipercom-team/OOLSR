//---------------------------------------------------------------------------
//                          Protocol-Plugin API
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// $Id: protocol-plugin-api.h,v 1.13 2004/10/04 15:46:39 adjih Exp $
//---------------------------------------------------------------------------
// Note: everything here should be allocated by free.
// 
// XXX: this file should be distributed upon a less restrictive copyright
// as it only document interface
//---------------------------------------------------------------------------

#ifndef _PROTOCOL_PLUGIN_API_H
#define _PROTOCOL_PLUGIN_API_H

//---------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

//---------------------------------------------------------------------------

#define PPA_VERSION_MAJOR 6
#define PPA_VERSION_MINOR 0

#define PPA_FAILURE 0
#define PPA_OK 1

//---------------------------------------------------------------------------

typedef struct {
  void* data;
  int size;
} PPA_Packet;

typedef void* PPA_PluginNode;
typedef void* PPA_PlugeeNode;
typedef void* PPA_Address;

typedef struct s_ProtocolRoute {
  PPA_Address localInterfaceAddress;
  PPA_Address nextHopInterfaceAddress;
  PPA_Address destinationAddress;
  int distance;
} PPA_Route;

#define PPA_ADD_ROUTE 1
#define PPA_DEL_ROUTE 2

//--------------------------------------------------

typedef struct s_PluginProtocolApi {

  PPA_PluginNode (*createNodeFunction)(PPA_PlugeeNode plugeeNode,
				       int nbInterface,
				       /* borrowed: */
				       PPA_Address* interfaceAddressArray,
				       int* interfaceMTUArray,
				       /* borrowed: */
				       void* configData, int configSize);

#if 0
  void (*nodeSetConfigFunction)(PPA_PluginNode pluginNode,
				char* name, char* value);

  char (*nodeGetConfigFunction)(PPA_PluginNode pluginNode,
				char* name);

  void (*nodeSetConfigFunction)(PPA_PluginNode pluginNode,
				void* data, int dataSize);
#endif

  void (*nodeStartFunction)(PPA_PluginNode pluginNode);
  
  void (*nodeReceiveFunction)(PPA_PluginNode pluginNode,
			      PPA_Address senderAddress,
			      PPA_Address receiverAddress,
			      PPA_Packet packet); /* owned */

  /* deprecated: */
  void (*nodeOutputFunction)(PPA_PluginNode pluginNode, char* fileName); 

  void (*nodeWriteFunction)(PPA_PluginNode pluginNode, 
			    char** result /* owned*/); 

  /* the following are optional, use NULL if not defined */
  /* XXX: may be changed to include IP src, IP dst, ports, ... */
  void (*nodeMulticastEncapsulateFunction) (PPA_PluginNode pluginNode,
				    PPA_Address destinationMulticastAddress,
					    PPA_Packet packet /* owned*/);
  
  void (*nodeMulticastJoinGroupFunction)(PPA_PluginNode pluginNode,
					 PPA_Address multicastAddress);

  void (*nodeMulticastLeaveGroupFunction)(PPA_PluginNode pluginNode,
					  PPA_Address multicastAddress);

  void (*nodeMulticastSenderJoinFunction)(PPA_PluginNode pluginNode,
					  PPA_Address multicastAddress);

  void (*nodeMulticastSenderLeaveFunction)(PPA_PluginNode pluginNode,
					   PPA_Address multicastAddress);

  /* optional, use NULL if not defined */
  int (*pluginGetExtension) (void* data1, void* data2);

} PPA_PluginApi;

//--------------------------------------------------

typedef void (*PPA_CallbackFunction)(void* data1, void* data2, void* data3);

typedef struct s_PlugeeApi {

  int addressSize;

  void (*sendPacketFunction)(PPA_PlugeeNode plugeeNode,
			     PPA_Address srcAddress, /* of one of iface */
			     PPA_Address dstAddress,
			     PPA_Packet packet); /* owned */

  int (*configureRouteFunction)(PPA_PlugeeNode plugeeNode,
				/* borrowed: */
				PPA_Route* route,
				int flags /* add or delete */);

  void (*scheduleAtFunction)(double relativeTime,
			     PPA_CallbackFunction function,
			     void* data1, void* data2, void* data3);

  void (*getBroadcastAddressFunction)(PPA_Address resultAddress);

  double (*getCurrentTimeFunction)();

  /* optional, use NULL if not defined */
  void (*sendDecapsulatedMulticastPacketFunction)
       (PPA_PlugeeNode plugeeNode,
	PPA_Address originatorAddress,
	PPA_Address destinationAddress,
	PPA_Address receiverAddress,
	PPA_Packet packet /*own*/);
       
  /* optional, use NULL if not defined */
  int (*getExtension) (void* data1, void* data2);

} PPA_PlugeeApi;

//---------------------------------------------------------------------------

#define PPA_InitFunctionName "protocolPluginApiInit"

typedef int (*PPA_ProtocolPluginApiInitFunc)(int major, int minor,
					     PPA_PlugeeApi* plugeeApi, 
					     PPA_PluginApi** resultPluginApi);

//---------------------------------------------------------------------------
// Optional functions, offered by static_plugee.o and dynamic_plugee.o

extern int doesRequirePlugin();

extern void loadPlugin(char* fileName,
		       PPA_PlugeeApi* myApi, PPA_PluginApi** pluginApi);

//---------------------------------------------------------------------------

#ifdef __cplusplus
} // extern "C"
#endif

//---------------------------------------------------------------------------

#endif // _PROTOCOL_PLUGIN_API_H
