//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//         Paul Muhlethaler, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Note:
// This files uses rather complex templatology due to C++ shortcomings
// Still, the useful information is the following:
//   The interface of BasicTupleSetIterator
//   The interface of BasicTupleSet
// the rest is poetry.
//---------------------------------------------------------------------------

#ifndef _TUPLE_H
#define _TUPLE_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>
#include <vector>
#include <set>

#include "general.h"
#include "address.h"

//---------------------------------------------------------------------------

template <typename Value>
class ListManager
{
public:
  typedef typename std::list<Value> Container;
  typedef typename std::list<Value>::iterator iterator;
  static void put(Container& container, const Value& value)
  { container.push_back(value); }
  static void remove(Container& container, const Value& value)
  { container.remove(value); }
};

template <typename Value>
class SetManager
{
public:
  typedef typename std::set<Value> Container;
  typedef typename std::set<Value>::iterator iterator;
  static void put(Container& container, const Value& value)
  { container.insert(value); }
  static void remove(Container& container, const Value& value)
  { container.erase(value); }
};

template <typename Value>
class ContainerManager : public SetManager<Value*>
{ };

class IsIterationEnd {};

//---------------------------------------------------------------------------

/// An abstract Tuple. All tuples should inherit from it.
class ITuple
{
public:
  /// Returns the time at which the tuple will be considered as expired
  virtual Time getExpireTime() = 0;

  /// This function must be called each time some changes have been 
  /// performed on the tuple
  virtual void update() = 0;
};

//---------------------------------------------------------------------------

template<class Tuple, class Manager>
class IVeryBasicTupleSet
{
public:
  /// constructor.
  //BasicTupleSet(Tuple* tuple );

  /// Add a new tuple to the set (steals the reference).
  virtual void add(Tuple* tuple) = 0;

  /// Remove the tuple from the set
  // this method should be private/protected
  virtual void remove(Tuple* tuple) = 0;

  /// Remove the tuple from the set, and delete the pointer
  virtual void removeAndDelete(Tuple* tuple) = 0;
};

//--------------------------------------------------

/// An abstract iterator on Tuple, based on the Iterator Design Pattern,
/// and the STL iterator methods name
template<class Tuple, class Manager = ContainerManager<Tuple> >
class BasicTupleSetIterator
{
  
public:
  IVeryBasicTupleSet<Tuple,Manager>* set;
  
  // Returns the current item. isDone() must have been checked
  // to be false before calling this method.
  // (the returned reference is borrowed).
  Tuple* getCurrent();

  // Advance the iterator to the next item. isDone() must have been
  // checked to be false before calling this method.
  void next();

  // Returns true if there is no longer any tuple to get
  bool isDone();

  /// Removes the current item pointed by the iterator
  void removeCurrentAndDoNext();

  /// Removes and delete the current item pointed by the iterator
  void removeAndDeleteCurrentAndDoNext();

  //--------------------------------------------------
  // Functions for C++ compatibility
  Tuple* operator * () { return getCurrent(); }
  void operator ++ () { next(); }
  bool operator != (const IsIterationEnd& marker) { return !isDone(); }

  // Internal implementation
  typename Manager::iterator q;
  typename Manager::iterator itEnd;
};

//---------------------------------------------------------------------------

//#ifndef SWIG
template <class Tuple, class Iterator, class Function>
class Filter
{
public:

  Filter<Tuple,Iterator,Function>()
  { Fatal("Must not be called"); } // Only for swig, do not use

  Filter<Tuple,Iterator,Function>(Function aFunction, Iterator aIterator)  
    : function(aFunction), it(aIterator) { (void)ensureValid(); }

  bool ensureValid() {
    for(;;) {
      if(it.isDone()) return false;
      if (function(*it.getCurrent())) return true;
      it.next();
    }
  }

  Tuple* getCurrent() { return it.getCurrent(); }
  bool isDone() { return it.isDone(); }
  void next() { it.next(); (void)ensureValid(); }

  // Functions for C++ compatibility
  Tuple* operator * () { return getCurrent(); }
  void operator ++ () { next(); }
  bool operator != (const IsIterationEnd& marker) { return !isDone(); }

protected:
  Function function;
  Iterator it;
};
//#endif // !defined(SWIG)

//---------------------------------------------------------------------------

#ifdef SYSTEMwindows
#define ABSTRACT { Fatal("Abstract function"); }
#else
#define ABSTRACT = 0
#endif

class IBasicTupleSet // just to avoid specilization of ostream&
{
public:
  virtual void write(ostream& out) = 0;
};

/// A basic Tuple Set.
template<class Tuple, class Manager = ContainerManager<Tuple>,
   class Iterator = BasicTupleSetIterator<Tuple, Manager> >
class BasicTupleSet : public IBasicTupleSet, 
                      public IVeryBasicTupleSet<Tuple, Manager>
{
  
public:

  /// Add a new tuple to the set (steals the reference).
  virtual void add(Tuple* tuple);

  /// Remove the tuple from the set
  // this method should be private/protected
  virtual void remove(Tuple* tuple);

  /// Remove the tuple from the set, and delete the pointer
  virtual void removeAndDelete(Tuple* tuple);


  //typedef BasicTupleSetIterator<Tuple, Manager> TupleIterator;
  typedef Iterator TupleIterator; // XXX: for previous code compatibility only

  /// Returns an iterator, which will iterate on the list of 
  /// the tuples of the tuple set.
  TupleIterator getIter();

  /// Returns an iterator, which will iterate on the list of the tuples
  /// of the tuple set.
  //TupleIterator getIterFilter(IBooleanFunction<Tuple>* filterFunc);

  /// Returns the minimum expire time
  /// hasMinTime indicates whether there was at least one tuple or not
  /// if not, the result value should not be used.
  Time getMinExpireTime(bool& hasMinTime);

  /// Expurge the TupleSet from the expired tuples
  /// each removed tuples goes through the notifyRemoval method first
  /// but NOTE: is then deleted (unlike 'remove' method, which does not delete)
  virtual void removeAndDeleteExpired(Time currentTime);

  // compatibility with C++ format
  IsIterationEnd end() { return IsIterationEnd(); }

  friend class BasicTupleSetIterator<Tuple, Manager>; 

  virtual ~BasicTupleSet<Tuple, Manager>()
  { 
    typename Manager::iterator current = content.begin();
    typename Manager::iterator contentEnd = content.end();
    while(current != contentEnd) {
      typename Manager::iterator next = current;
      next++;
      content.erase(current);
      current = next;
    }
  }

  int empty() { return content.empty(); }

private:

  void _internalAdd(Tuple* tuple)
  { Manager::put(content, tuple); }

  void _internalRemove(Tuple* tuple)
  { Manager::remove(content, tuple); }

protected:
  /// (Design Pattern: template method). This function is called
  /// each time a tuple is removed from the BasicTupleSet
  virtual void notifyRemoval(Tuple* tuple) ABSTRACT;

  virtual void notifyPreRemoval(Tuple* tuple) { }

  /// (Design Pattern: template method). This function is called
  /// each time a tuple is added to the BasicTupleSet
  virtual void notifyAddition(Tuple* tuple) ABSTRACT;

  // Internal implementation
  BasicTupleSetIterator<Tuple, Manager> it;
  typename Manager::Container content; // the set itself
};

#ifndef SWIG
static inline ostream& operator << 
(ostream& out, IBasicTupleSet& tupleSet)
{ tupleSet.write(out); return out; }
#endif /* SWIG */

//--------------------------------------------------

template<class Tuple, class Manager = ContainerManager<Tuple>,
        class Iterator = BasicTupleSetIterator<Tuple, Manager> >
class OptimizedBasicTupleSet : public BasicTupleSet<Tuple, Manager, Iterator>
{
public:
  typedef Iterator TupleIterator;

  virtual void add(Tuple* tuple)
  {
    // Put this is the optimization map
    Address addressKey = getAddressKey(tuple);
    typename Manager::Container* tupleList = keyToTupleList.get(addressKey);
    if (tupleList == NULL) {
      typename Manager::Container emptyList;
      keyToTupleList.add(addressKey, emptyList);
      tupleList = keyToTupleList.get(addressKey);
      assert( tupleList != NULL );
    }
    Manager::put(*tupleList, tuple);
    //XXX: tupleList->push_back(tuple);

    // Perform the normal addition
    BasicTupleSet<Tuple,Manager>::add(tuple);
  }
  
  virtual void remove(Tuple* tuple)
  { 
    // Perform the normal removal
    BasicTupleSet<Tuple, Manager>::remove(tuple); 
    
    // Remove this from the optimization map
    Address addressKey = getAddressKey(tuple);
    typename Manager::Container* tupleList = keyToTupleList.getPtr(addressKey, NULL);
    assert( tupleList != NULL );
    Manager::remove(*tupleList, tuple);
    //tupleList->remove(tuple);
  }

  /// Returns an iterator, which will iterate on the list of 
  /// the tuples of the tuple set.
  TupleIterator getIter()
  { return BasicTupleSet<Tuple,Manager>::getIter(); }

  TupleIterator getIter(Address addressKey)
  { 
    TupleIterator result;
    result.set = this; 
    typename Manager::Container* tupleList = keyToTupleList.getPtr(addressKey,
								   &emptyList);
    assert( tupleList != NULL );
    result.q = (tupleList->begin()) ;
    result.itEnd = (tupleList->end());
    return result; 
  }

  virtual Address getAddressKey(Tuple* tuple) = 0;

protected:
  AddressMap<typename Manager::Container> keyToTupleList;
  typename Manager::Container emptyList;
};

//---------------------------------------------------------------------------
// Utility macros
//---------------------------------------------------------------------------

#ifndef SWIG
#ifndef MORE_OPT
#define IteratorArg(x) 
#else
#define IteratorArg(x) x
#endif
#endif /* SWIG */

#define EndSearch } return NULL;

#define BeginOptimizedSearch(typeName, iterArg) \
    for(TupleIterator it = getIter(IteratorArg(iterArg)); \
        !it.isDone(); it.next()) { \
      typeName* current = it.getCurrent(); 

#define OptimizedSearch(typeName, condition, iterArg) \
  BeginOptimizedSearch(typeName, iterArg) { \
     if (condition) \
       return current; \
  } EndSearch

#define Search(typeName, condition) \
  BeginOptimizedSearch(typeName, ) { \
     if (condition) \
       return current; \
  } EndSearch

//---------------------------------------------------------------------------

#endif // _TUPLE_H
