//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// The main OLSR daemon
//---------------------------------------------------------------------------

#include "base.h"

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "mystream.h"
#include <vector>

#if !defined(SYSTEMwindows)
#include <unistd.h> // for fork (XXX: move to system_linux.cc)
#include <errno.h> // ... ditto
#endif

//---------------------------------------------------------------------------

#include "general.h"
#include "log.h"
#include "scheduler_unix.h"
#include "node.h"
#include "network_generic.h"
#include "network_linux.h"
#include "protocol_config.h"

//---------------------------------------------------------------------------

extern ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig);
extern ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig);

#ifndef UNDER_CE
int main(int argc, char** argv)
#else
int startOLSR(int argc, char** argv)
#endif
{
  //int i;
  //int nbIface = argc-1;

  cerr.precision(15);
  cout.precision(15);

  if(argc <= 1) {
    cerr << "Syntax: " << argv[0] 
	      << " [options...] with options:" << endl;
    cerr << " -f <config file>: reads a configuration file " << endl;
    cerr << " -i <iface name>: use interface <iface name> (repeat if there are several ifaces)" << endl;
    cerr << " --use-ipv4 : use IPv4" << endl;
    cerr << " --use-ipv6 : use IPv6" << endl;
    cerr << " --<parameter name> <parameter value>" << endl;
    cerr << " --<command> [<command args> ...]" << endl;
    cerr << " --on <iface name> <iface parameter name>"
                 " <iface parameter value>" << endl;
    exit(EXIT_FAILURE);
  }

  ConfigParser parser;
  Log* log = new Log;
  ProtocolConfig* protocolConfig = new ProtocolConfig;
  parser.parseArgList(*protocolConfig, *log, argv+1, argc-1);

  if(protocolConfig->ipv4 && protocolConfig->ipv6) 
    protocolConfig->ipv4 = false; // IPv6 take precedence

  if (protocolConfig->onlyParseConfig) {
    cout << "# Configuration output:" << endl;
    exit(EXIT_SUCCESS);
  }

  //--------------------------------------------------

  ISystemFactory* systemFactory = NULL;

  if (protocolConfig->ipv6) {
    systemFactory = getIPv6SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Exit("Cannot use IPv6, check that your binary supports it");
  } else if (protocolConfig->ipv4) {
    systemFactory = getIPv4SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Exit("Cannot use IPv4, check that your binary supports it");
  } else Exit("Neither ipv4 nor ipv6 are defined in configuration.");

  Node* node = new Node;
  PacketManager* packetManager = new PacketManager(node);

  std::list<ISystemIface*> systemIfaceList;

  typedef std::map<string,GeneratedIfaceConfig*> IfaceNameToConfig;
  for(IfaceNameToConfig::iterator it = protocolConfig->ifaceConfig.begin();
      it != protocolConfig->ifaceConfig.end(); it++) {
    string ifaceName = (*it).first;
    GeneratedIfaceConfig* ifaceConfig = (*it).second;
    ISystemIface* systemIface = 
      systemFactory->getIfaceByName(protocolConfig,
				    ifaceName.c_str(), ifaceConfig);
    if(systemIface == NULL)
      Exit("Cannot find a usable interface with name '" 
	   << ifaceName.c_str() 
	   << "' (check you have site-local address when using ipv6)\n");
    if (ifaceName != protocolConfig->mainIface)
      systemIfaceList.push_back(systemIface);
    else systemIfaceList.push_front(systemIface);
    systemIface->openSocket(node);
  }
  
  std::vector<ISystemIface*> systemIfaceVector;
  for (std::list<ISystemIface*>::iterator it = systemIfaceList.begin();
       it != systemIfaceList.end(); it++)
    systemIfaceVector.push_back(*it);

  if(protocolConfig->ifaceConfig.begin()
     == protocolConfig->ifaceConfig.end()) {
    Exit("No interfaces have been given for running OOLSR");
  }
  
#ifndef NOLOG
  if(!protocolConfig->noLog) {
    if (globalLog == NULL) { // XXX: should be done elsewhere
      // XXX: not implemented
      //globalLog = new Log;
      //globalLog->out = createLogFile(protocolConfig->logFileName,
      //				     "global");
    }
    Address address = //Address(systemFactory->getAddressFactory(), 
      systemIfaceVector[0]->getAddress();
    log->out = createLogFile(protocolConfig->logFileName,
			     toText(address));
  }
#endif

#ifndef SYSTEMwindows
  if(!protocolConfig->noFork) {
    // Daemonize (from olsrdv7)
    // XXX: not windows compatible
    pid_t childPid = fork();
    if (childPid < 0)  
      Exit("Failure in fork(): " << strerror(errno));
    else if (childPid == 0) // Parent
      exit(EXIT_SUCCESS);
    close(0);
    close(1);
    close(2);
    setsid();
  }
#else
#endif

  // Configure the node
  node->configure(systemFactory->getScheduler(),
		  systemFactory->getAddressFactory(),
		  packetManager, 
		  systemFactory->getNetworkConfigurator(),
		  protocolConfig,
		  systemIfaceVector,
		  log); // XXX: should be configured with protocolConfig
  
  node->start();

  systemFactory->visitNode(node);
  systemFactory->getScheduler()->runUntilNoEvent();

  exit(EXIT_SUCCESS);
  return EXIT_SUCCESS;
}

//---------------------------------------------------------------------------
