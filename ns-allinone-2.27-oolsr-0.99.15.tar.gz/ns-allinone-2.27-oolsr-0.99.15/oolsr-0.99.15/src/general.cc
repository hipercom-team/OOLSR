//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "mystream.h"

#ifndef SYSTEMwindows
#include <sys/stat.h>
#include <sys/types.h> //XXX:remove
#endif


#include "general.h"
#include "log.h"

//---------------------------------------------------------------------------

const double C = 1.0/16.0; // @@3502

void debugMe()
{
  // 
  cout << "debug point" << endl;
}

int toMantissaExponentByte(Time value)
{
  assert( C <= value && value <= fromMantissaExponentByte(0xff) );
  int b=0;
  while( (value/C) >= (1<<(b+1)) ) // @@3595
    b++;

  double aFloat = 16*(value/(C*(1<<b))-1); // @@3597
  int a = (int)aFloat; // @@3598
  if(a<aFloat) a++;

  if(a==16) { // @@3600
    b++;
    a=0;
  }

  assert(0<=a && a<=15 && 0<=b && b<=15); // @@3602
  return a*16+b; // @@3603
}


Time fromMantissaExponentByte(int valueAsByte)
{
  int a = (valueAsByte>>4); // @@3571-3572
  int b = (valueAsByte&0xf); // @@3572-3573
  return C*((16+a)<<b)/16.0; // @@3569
}

//---------------------------------------------------------------------------

//MemoryBlock::MemoryBlock(void* initialData, int initialSize, bool aOwned)
//{ Fatal("XXX: not implemented"); }


MemoryBlock::MemoryBlock(int initialSize)
{
  data = new octet[initialSize];
  size = initialSize;
}

MemoryBlock* MemoryBlock::clone()
{
  MemoryBlock* result = new MemoryBlock(size);
  memcpy(result->data, data, size);
  return result;
}

MemoryBlock::~MemoryBlock()
{ delete [] data; data = NULL; }

ostream& operator << (ostream& out, MemoryBlock& block)
{
  if(block.size != 0) {
    out << hex;
    for(int i=0;i<block.size;i++)
      out << (i>0&&(i%4)==0?"_":"") << setw(2) << setfill('0') 
	  << (unsigned int)block.data[i];
    out << dec;
  } else out << "<empty>";
  return out;
}

//---------------------------------------------------------------------------

string stringBitAnd(string a, string b)
{
  string result = a;
  assert(a.size() == b.size() && result.size() == a.size() );
  octet* aData = (octet*)a.data(); // this assumes string stores 8-bit chars.
  octet* bData = (octet*)b.data();
  for (unsigned int i=0; i<a.size(); i++) {
    result[i] = aData[i] & bData[i];
  }
  return result;
}

string stringBitNot(string a)
{ 
  string result = a;
  assert(result.size() == a.size() );
  octet* aData = (octet*) a.data();
  for (unsigned int i=0; i<a.size(); i++) {
    int dataInt = (int)aData[i]; 
    assert( inrange(0, dataInt, 0x100) );
    result[i] = 0xffu ^ aData[i];
  }
  return result;
}

string makeStringBitMaskNetworkOrder(int size, int prefix)
{
  string result(size, '\0');
  int currentPrefix = prefix;
  const int BitPerByte = 8;
  for (int i=0; i<size;i++) {
    if (currentPrefix >= BitPerByte) {
      currentPrefix -= BitPerByte;
      result[i] = (unsigned char)((1<<BitPerByte)-1);
    } else if (currentPrefix > 0) {
      result[i]  = ((1<<currentPrefix)-1) << (BitPerByte-currentPrefix);
      currentPrefix = 0;
    } else result[i] = 0;
  }
  return result;
}

//---------------------------------------------------------------------------
// Basic string functions (they are similar to Python string methods)
//---------------------------------------------------------------------------

vector<string> stringSplit(string aLine, string charSet)
{
  string line = aLine;
  vector<string> result;
  while(line.length() > 0) {
    string::size_type pos = line.find_first_of(charSet);
    result.push_back(line.substr(0, pos));
    line.erase(0, pos);
    if (pos != string::npos) {
      pos = line.find_first_not_of(charSet);
      line.erase(0, pos);
    }
  }
  return result;
}

// XXX: should be purely functional
string stringReplace(const string& aLine, const string& before, 
		     const string& after)
{
  string line = aLine;
  string result;
  while(line.length()>0) {
    string::size_type pos = line.find(before);
    result += line.substr(0, pos);
    if (pos != string::npos) {
      line.erase(0, before.length()); // remove the "before"
      result += after;
    }
  }
  return result;
}

string stringLStrip(string a, string charSet)
{
  string::size_type pos = a.find_first_not_of(charSet);
  if (pos == string::npos) 
    return "";
  else return a.substr(pos, a.length()-pos);
}

string stringRStrip(string a, string charSet)
{
  string::size_type pos = a.find_last_not_of(charSet);
  if (pos == string::npos) 
    return "";
  else return a.substr(0, pos+1);
}

string stringStrip(string a, string charSet)
{ return stringLStrip(stringRStrip(a, charSet), charSet); }

string strReplace(string data, string before, string after)
{
  string result = data;
  string::size_type previousPos = 0;
  for(;;) {
    string::size_type pos = result.find(before, previousPos);
    if (pos == string::npos) 
      return result;
    result.replace(pos, before.length(), after);
    previousPos = pos + before.length();
    if (previousPos >= result.length())
      return result;
  }
}

bool stringStartsWith(string a, string b)
{ return strncmp(a.c_str(),b.c_str(),strlen(b.c_str())) == 0; }

bool stringEndsWith(string a, string b)
{ 
  if (a.length() < b.length())
    return false;
  int pos = a.length()-b.length();
  return strncmp(a.c_str()+pos,b.c_str(),strlen(b.c_str())) == 0; 
}


string stringLower(string a)
{ 
  string result;
  for (unsigned int i = 0; i< a.length();i++)
    result += tolower(a[i]);
  return result;
}

string format3UInt(void* data)
{
  ostringstream result;
  unsigned int* info = (unsigned int*)data;
  result << info[0] << "," << info[1] << "," << info[2];
  return result.str();
}

//---------------------------------------------------------------------------

Log* globalLog = NULL;

ostream* createLogFile(string fileTemplate, string infix) 
{
#if defined(SYSTEMlinux) || defined(SYSTEMcygwin)
  //XXX:windows
  if (fileTemplate == "-")
#ifdef SYSTEMlinux
    return new ofstream("/proc/self/fd/1"); // XXX! not windows compat.
#else
  return &cout;
#endif
  if (fileTemplate == "")
    return new ofstream("/dev/null");
  string::size_type pos = fileTemplate.find('/');
  if (pos != string::npos && pos != 0) {
    string dirName = fileTemplate.substr(0, pos);
    (void)mkdir(dirName.c_str(), 0700); // XXX! not Windows compatible?
  }
#endif
  string name = strReplace(fileTemplate, "%s", infix);
  if (fileTemplate == name && infix == "global") {
    name += "." + infix;
  }
  return new ofstream(name.c_str()); // XXX! when close? 

#if 0
  char name[1024]; // XXX! hack
  (void)mkdir("./tmp", 0700); // XXX! not Windows compatible?
  strcpy(name, "./tmp/olsr.log");

  for(int i=0;i<simulatorApi->addressSize;i++) {
    strcat(name, ".");
    char substr[1024];
    sprintf(substr, "%d", (((unsigned char*)address)[i]));
    strcat(name, substr);
  }
  return new ofstream(name); // XXX! when close?
#endif
}

//---------------------------------------------------------------------------
