#include <stdlib.h> // drand48

#include <sys/time.h>
#include <stdio.h>

#include "general.h"

//---------------------------------------------------------------------------

 /// Draw a random number (double) between 0 (incl.) and maxValue (excl.)
double drawDouble(double maxValue)
{ return rand()/(double)(RAND_MAX)*maxValue; }

double getTimeOfDay()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
}

