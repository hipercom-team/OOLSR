//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// XXX: should use select for writing data
//---------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <list>
using std::list;
using std::string;

//#define DD(x) do { cout<< x ; } while(0)
#define DD(x) do { } while(0)

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <errno.h>

#include <scheduler_simulation.h>
#include <scheduler_unix.h>

#include "libhttpd.h"

#include "http_support.h"
//#include "html_support.cc"

//DESIRED_MAX_MAPPED_FILES.
#include <sys/select.h>

//---------------------------------------------------------------------------

//httpd_send_err( hc, 400, httpd_err400title, "", httpd_err400form, "" );

int httpd_read(httpd_conn* connection)
{
  int status = -1, spaceLeft = -1;
  void* buffer = NULL;
  if (connection->read_idx == connection->read_size)
      httpd_realloc_str( &connection->read_buf, &connection->read_size, 
			 2*connection->read_size+128 );
  buffer = connection->read_buf + connection->read_idx;
  spaceLeft = connection->read_size - connection->read_idx ;
  status = read(connection->conn_fd, buffer, spaceLeft);
  if (status == 0) {
    return -1; // eof of connection
  } else if (status < 0) {
    if (errno == EAGAIN || errno == EINTR || errno == EWOULDBLOCK)
      return 0; // this is ok
    else return -1;
  } else {
    connection->read_idx += status;
  }
  return status;
}

//---------------------------------------------------------------------------

bool strStartsWith(char* data, char* otherData)
{ return strncmp(data, otherData, strlen(otherData)) == 0; }

//---------------------------------------------------------------------------

class HTTPServer;

class HTTPConnection : public IFdHandler, public IHTTPConnection
{
public:
  typedef enum {
    StateWaitingFirstChar, StateInput, StateSendingOutput, StateSendingFile,
    StateFinished
  } State;

protected:
  State state;
  IOScheduler* scheduler;
  HTTPServer* server;

  httpd_conn connection;

public:
  HTTPConnection(HTTPServer* aServer, IOScheduler* aScheduler,
		 httpd_conn& aConnection) 
    : state(StateWaitingFirstChar), scheduler(aScheduler), server(aServer)
  { connection = aConnection; }



  virtual bool waitingForInput() 
  { return (state == StateWaitingFirstChar) || (state == StateInput); }
  virtual bool waitingForOutput() 
  { return (state == StateSendingOutput) || (state == StateSendingFile); }
  virtual bool waitingForExcept() 
  { return false; /* XXX: TODO*/ }

  virtual void handleInput();

  virtual void handleOutput() 
  {
    //XXX: nothing for now
  }

  virtual void handleExcept() 
  { Fatal("Impossible handleExcept"); }

  void onInputError()
  { sendError(400, httpd_err400title, httpd_err400form); }

  virtual void send404Error()
  { sendError(404, httpd_err400title, httpd_err400form); }

  virtual void sendError(int errorCode, string title, string data) 
  {
    httpd_send_err(&connection, errorCode, (char*)title.c_str(), "",
		   (char*)data.c_str(), connection.encodedurl );
    httpd_write_response(&connection);
    httpd_close_conn( &connection, NULL );
    scheduler->removeFdHandler(this);
    //XXX: delete memory
    //XXX: delete from list in server 
  }

  virtual void close() 
  { writeAndEndConnection(); }

  virtual void serveFile()
  {
    if (httpd_start_request(&connection, NULL) < 0) {
      DD("@"<<connection.conn_fd<<": error in starting serving\n");
      onInputError();
      return;
    }
    
    if (connection.conn_fd < 0) { // end of connection
      DD("@"<<connection.conn_fd<<": end of connection\n");
      onInputError();
      return;
    }
    
    state = StateSendingFile;

    DD("@"<<connection.conn_fd<<": sending response\n");
    if (connection.responselen != 0)
      write(connection.response, connection.responselen);
    
    httpd_write_fully(connection.conn_fd, connection.file_address, 
		      connection.bytes_to_send);
    endConnection();
  }


  void writeAndEndConnection()
  {
    write(connection.response, connection.responselen);
    endConnection();
  }

  virtual void write(string data) 
  { write((char*)data.c_str(), data.length()); }

  virtual string getURL()
  { return connection.decodedurl; }

  virtual string getAuthentication()
  { return connection.authorization; }

  virtual void sendAuthenticate(string authenticateFieldOrRealm)
  {
    httpd_send_authenticate(&connection, 
			    (char*)authenticateFieldOrRealm.c_str()); //XXX
    writeAndEndConnection();
  }


  void write(char* data, int dataLength) // XXX: blocking:
  { httpd_write_fully(connection.conn_fd, data, dataLength);  }

  virtual FileDescriptor getFileDescriptor() 
  { return connection.conn_fd; /* XXX: IPv6*/ }


  void endConnection()
  {
    scheduler->removeFdHandler(this);
    httpd_close_conn( &connection, NULL ); // XXX: free / remove from parent
    state = StateFinished;
  } 
};

//---------------------------------------------------------------------------

class HTTPServer : public IHTTPServer, public IFdHandler
{
public:
  HTTPServer() : visitor(NULL), scheduler(NULL)  {}
  
  virtual void open(IOScheduler* aScheduler, unsigned short port,
		    IHTTPConnectionVisitor* aVisitor)
  {
    assert( scheduler == NULL );
    scheduler = aScheduler;
    visitor = aVisitor;

    httpd_sockaddr ipv4Addr; //XXX: IPv6
    ipv4Addr.sa_in.sin_family = AF_INET;
    ipv4Addr.sa_in.sin_addr.s_addr = INADDR_ANY;
    ipv4Addr.sa_in.sin_port = htons(port);
    
    server = httpd_initialize
      (/*hostname*/ NULL, /*httpd_sockaddr*/ &ipv4Addr, 
       /*httpd_sockaddr*/ NULL,
       /*port*/ 9090, /*cgi_pattern*/ NULL, /*cgi_limit*/ 0, 
       /*charset*/ "iso-8859-1",
       /*p3p*/ "", /*max_age*/ -1, /*cwd*/ "/tmp", /*no_log*/ 1, 
       /*logfp*/ stdout,
       /*no_symlink_check*/ 1, /*vhost*/ 0, /*global_passwd*/ 0, 
       /*url_pattern*/ "",
       /*local_pattern*/ "", /*no_empty_referers*/ 0 );

    if (server == NULL)
      Fatal("Could not initialize httpd_server");

    DD(fprintf(stdout, "Server: IPv4=%d IPv6=%d\n", server->listen4_fd,
	    server->listen6_fd)); // XXX
    start();
  }
  

  void start()
  { scheduler->addFdHandler(this, NULL); }

  // IFdHandler methods
  virtual FileDescriptor getFileDescriptor() 
  { return server->listen4_fd; /* XXX: IPv6*/ }

  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; }
  virtual void handleOutput() { Fatal("Impossible handleOutput"); }
  virtual void handleExcept() { Fatal("Impossible handleExcept"); }

  virtual void handleInput()
  {
    httpd_conn connection;
    memset(&connection, 0, sizeof(connection));
  
    // Create a new connection
    int status = httpd_get_conn(server, server->listen4_fd, &connection);
    if (status == GC_FAIL) {
      Warn("Failed to get a connection.\n");
      return;
    }
    DD( fprintf(stderr, "ok %d\n", connection.conn_fd) );
    HTTPConnection* httpConnection = new HTTPConnection(this, 
							scheduler, connection);
    scheduler->addFdHandler(httpConnection, NULL);
    connectionList.push_back(httpConnection);
  }

  virtual void setHTMLErrorTemplate(string htmlTemplate)
  { httpd_set_response_template((char*)htmlTemplate.c_str()); }


  virtual ~HTTPServer()
  { httpd_terminate(server); }
  
public:
  IHTTPConnectionVisitor* visitor; // XXX: why public
protected:
  IOScheduler* scheduler;
  httpd_server* server;
  list<HTTPConnection*> connectionList;
};

//---------------------------------------------------------------------------


void HTTPConnection::handleInput() 
{
  /* Set the connection file descriptor to no-delay mode. */
  //httpd_set_ndelay( connection.conn_fd );
  
  // Parse the whole message
  int MaxRequestSize = 16*1024;
  int status = httpd_read(&connection);
  
  if (status < 0 || (int)connection.read_size > MaxRequestSize) {
    DD("@"<<connection.conn_fd<<": read error, status="<<status
       <<" ("<<connection.read_size<<")"<<endl);
      onInputError();
      return;
  }
  
#if 0
  if (status > 0 && state == StateWaitingFirstChar
      &&);
	// XXX: TODO
#endif 
  
  int requestStatus = httpd_got_request(&connection);
  
  DD("@"<<connection.conn_fd<<": read status="<<status
     <<", requestStatus="<<requestStatus<<endl);
  
  if (requestStatus == GR_BAD_REQUEST) {
    DD("@"<<connection.conn_fd<<": bad request\n");
    onInputError();
    return;
  }
  
  if (requestStatus != GR_GOT_REQUEST) {
    DD("@"<<connection.conn_fd<<": need to parse more\n");
    return; // parse more.
  }
  
  // Parse it
  if (httpd_parse_request(&connection) < 0) {
    DD("@"<<connection.conn_fd<<": error in parsing\n");
    onInputError();
    return;
  }
  
#if 0
  DD("@"<<connection.conn_fd<<": "<<connection.expnfilename<<"\n");
  if (!strcmp(connection.decodedurl, "/"))
    serveIndex();
  else if (strStartsWith(connection.decodedurl, "/serve"))
    serveFile();
  else if (strStartsWith(connection.decodedurl, "/action"))
    serveAction();
  else if (strStartsWith(connection.decodedurl, "/test-auth")) {
    httpd_send_authenticate(&connection, "basic");
    writeAndEndConnection();
  else if (strStartsWith(connection.decodedurl, "/internal/table/")) {
    //serveTable(connection.decodedurl);
    writeAndEndConnection();
  } else {
    httpd_send_err(&connection, 404, httpd_err400title, "",  // XXX: 404
		   httpd_err400form, connection.encodedurl );
    writeAndEndConnection();
  }
#endif
    if (connection.authorization != NULL 
	&& strlen(connection.authorization)>0)
      cout << "Authorization: " << connection.authorization << endl;
  
  server->visitor->visit(this);  
}

#if 0
static char* responseTemplate = 
"\
<HTML>\n\
<HEAD><TITLE>%d %s</TITLE></HEAD>\n\
<BODY BGCOLOR=\"#cc9999\" TEXT=\"#000000\" LINK=\"#2020ff\" VLINK=\"#4040cc\">\n\
<H2>%d %s</H2>\n";

void httpd_set_response_template(/*borrowed*/ char* template)
#endif

//---------------------------------------------------------------------------

IHTTPServer* makeHTTPServer()
{ return new HTTPServer; }

#if 0
main()
{
  SimulationScheduler internalScheduler;
  IOScheduler scheduler(&internalScheduler);
  HTTPServer httpServer(&scheduler, 9090);

  //httpd_server* server = httpServer.server;
  httpServer.start();
  scheduler.runUntilNoEvent();
}
#endif

//---------------------------------------------------------------------------
