//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the "general" functions of Node
//---------------------------------------------------------------------------

#include "general.h"
#include "node.h"

//---------------------------------------------------------------------------

void Node::dump()
{ logState(cerr); }

void dumpAddress(Address& address)
{ cerr << address; }

void dumpNode(Node& node)
{ node.logState(cerr); }

void dumpMessage(IMessageContent& message)
{ cerr << message; }

//---------------------------------------------------------------------------

static int nodeInstanceCounter = 0;

Node::Node() : heardIfaceSet(),
	       neighborSet(this), linkSet(this), twoHopNeighborSet(this),
	       mprSelectorSet(this), topologySet(this), 
	       ifaceAssociationSet(this), hnaAssociationSet(this),
	       duplicateSet(this)
{
  nodeInstanceIdx = nodeInstanceCounter++;

#ifdef MULTICAST_RESEARCH
  initMulticast();
#endif
  packetManager = NULL;
  protocolConfig = NULL;
  baseScheduler = NULL;
  networkConfigurator = NULL;
  addressListCache = NULL; // XXX: free at end
  currentRoutingTable = new RoutingTable(this); // XXX: never NULL now

  oneHopNeighborhoodChanged = true;
  twoHopNeighborhoodChanged = true;;
}

void Node::start()
{
  D(*log, lConfig,
    getRealTime() << " [config] " << getMainAddress() << " " 
    << (*protocolConfig) << endl);
  for(std::list<OLSRIface*>::iterator it = ifaceList.begin();
      it != ifaceList.end(); it++) {
    D(*log, lConfig,
      getRealTime() << " [iface-config] " << getMainAddress() << " " 
      << (*it)->getAddress() << (*(*it)->getConfig()) << endl);
  }

  eventCounter = 0;

  startNeighborSensing();
  startTopologyDiscovery();
  startJitterStrategy();
  startRoutingTableCalculation();
  startHNABase();
  startIfaceAssociationBase();
#ifdef MULTICAST_RESEARCH
  startMulticast();
#endif 
  scheduleNextJitterStrategyEvent(true);
}

void Node::configure(IScheduler* aBaseScheduler,
		     AddressFactory* aAddressFactory,
		     PacketManager* aPacketManager,
		     INetworkConfigurator* aNetworkConfigurator,
		     ProtocolConfig* aProtocolConfig,
		     std::vector<ISystemIface*>& systemIfaceList,
		     Log* aLog)
{
  addressFactory = aAddressFactory;
  packetManager = aPacketManager;
  protocolConfig = aProtocolConfig;
  baseScheduler = aBaseScheduler;
  networkConfigurator = aNetworkConfigurator;
  log = aLog;

  ifaceList.clear();
  for (unsigned int i=0;i<systemIfaceList.size();i++) {
    OLSRIface* iface = new OLSRIface(this, systemIfaceList[i]);
    ifaceList.push_back(iface); // XXX: must be deleted at end of program
  }

  advertisedHNAList.clear();
  for(std::list< std::pair<string,string> >::iterator it 
	= protocolConfig->hnaList.begin();
      it != protocolConfig->hnaList.end(); it++) {
    Address networkAddress = 
      addressFactory->parseAddress((char*)((*it).first.c_str()));
    Address networkMask = 
      addressFactory->parseAddress((char*)((*it).second.c_str()));
    advertisedHNAList.push_back
      ( std::pair<Address,Address>(networkAddress, networkMask) );
  }


  currentTime = baseScheduler->getTime();
  expiredTime = currentTime;
  nextTupleExpireTime = currentTime;
}

// The main receiving function.
void Node::evReceivePacket(MemoryBlock* packet,
			   Address sendIfaceAddress,
			   OLSRIface* recvIface)
{
  updateCurrentTime();
  preEvent("receive-packet");
  D(*log, lEvent,
    getRealTime() << " [receive-packet] " << getMainAddress() << " " 
    << sendIfaceAddress << " " << recvIface->getAddress() << " " << (*packet) 
    << endl );
  if (isRunning()) {
    packetManager->processPacket(sendIfaceAddress,
				 recvIface->getAddress(),
				 packet);
    processChange(true);
  }
  postEvent("receive-packet");
}

//---------------------------------------------------------------------------

//--------------- Expiration management

template<class Tuple>
void updateMinExpireTime(Time& result, bool& alreadyHasMinTime,
			 BasicTupleSet<Tuple>& set)
{
  bool hasTime = false;
  Time newTime = set.getMinExpireTime(hasTime);
  if (hasTime) {
    if(!alreadyHasMinTime || (newTime < result))
      result = newTime;
    alreadyHasMinTime = true;
  }
}

void Node::performTupleExpiration()
{
  expiredTime = getCurrentTime();
  Time clock = expiredTime;

  linkSet.removeAndDeleteExpired(clock);
  twoHopNeighborSet.removeAndDeleteExpired(clock);
  mprSelectorSet.removeAndDeleteExpired(clock);
  topologySet.removeAndDeleteExpired(clock);
  ifaceAssociationSet.removeAndDeleteExpired(clock);
  hnaAssociationSet.removeAndDeleteExpired(clock);
  // (XXX: one could do lazy-removal of duplicate set)
  duplicateSet.removeAndDeleteExpired(clock); 

  nextTupleExpireTime = currentTime;
}

void Node::getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime)
{
  //XXX:remove: this->nextTupleExpireTime;

  hasExpireTime = false;
  updateMinExpireTime(nextExpireTime, hasExpireTime, linkSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, twoHopNeighborSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, mprSelectorSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, topologySet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, ifaceAssociationSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, hnaAssociationSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, duplicateSet);
}

void Node::eventPerformExpiration(void* timePtr)
{
  updateCurrentTime();

  Time* previousTime = (Time*)timePtr;
  if (nextTupleExpireTime>*previousTime) {
    // the min expire time as changed since, so don't bother
    delete previousTime;
    return;
  }

  preEvent("expire");
  performTupleExpiration();
  processChange(true);
  scheduleExpirationEvent();
  postEvent("expire");
  delete previousTime;
}

void Node::scheduleExpirationEvent()
{
  bool hasExpireTime;
  Time nextExpireTime;
  getNextExpireTime(nextExpireTime, hasExpireTime);
  if(hasExpireTime && nextExpireTime >= this->nextTupleExpireTime) {
    Time* expireTimePtr = new Time;
    *expireTimePtr = nextExpireTime;
    this->nextTupleExpireTime = nextExpireTime;
    addEventAt(nextExpireTime, 
	       new NodeMethodCallback(this, &Node::eventPerformExpiration),
	       expireTimePtr);
  }
}

//---------------------------------------------------------------------------

//-------------------- Jitter strategy
/// [JitterStrategy] Initialize the counters of the jitter strategy

void Node::startJitterStrategy()
{ 
  jitterStrategyEventTime = getCurrentTime();
  jitterStrategyEventIndex = 0;
  addEvent(0.0, new NodeMethodCallback(this, &Node::eventJitterStrategy),
	   (void*)jitterStrategyEventIndex);
}

/// [JitterStrategy] The moment at which the node decide to send orc
/// not the message which are pending in the queues.

void Node::eventJitterStrategy(void* uintAsVoidPtr)
{
  unsigned int eventIndex = (unsigned int)uintAsVoidPtr;
  updateCurrentTime();
  D(*log, lEventStrategy, getRealTime() << " [event-strategy] " << getMainAddress() 
    << " " << eventIndex);
  if (eventIndex != jitterStrategyEventIndex) {
    D(*log, lEventStrategy, " ignored" << endl);
    return; // the event was overridden
  }

  double delay = drawDouble(protocolConfig->strategyInterval);

  // XXX: non-optimal: because the event may be canceled in processJitterStrat.
  jitterStrategyEventIndex++;
  jitterStrategyEventTime = getCurrentTime() + delay;
  D(*log, lEventStrategy, " ok " << jitterStrategyEventTime << endl);
  addEvent(delay, new NodeMethodCallback(this, &Node::eventJitterStrategy),
	   (void*)jitterStrategyEventIndex);
  
  processJitterStrategy();
}

void Node::processJitterStrategy()
{
  bool shouldReschedule = false;

  jitterStrategyEventTime = 
    adjustTimeWithGeneration(jitterStrategyEventTime, shouldReschedule);
  if(shouldReschedule) {
    D(*log, lEventStrategy, " [strategy-reschedule] " 
      << jitterStrategyEventTime << endl);
  }

  bool hasProcessedEvent = false;

  // Process all generation events that must be scheduled now:
  std::list<GenerationEvent>::iterator it = generationEventList.begin();
  while(it != generationEventList.end()) {
    std::list<GenerationEvent>::iterator current = it;
    it++;
    if ((*current).maxTime < jitterStrategyEventTime) {
      assert((*current).minTime <= getCurrentTime());
      NodeMethod method = (*current).method;
      D(*log, lEventStrategy, getRealTime() << " [event-strategy-callback] " 
	<< getMainAddress() << " " << endl);
      (this->*method)();
      generationEventList.erase(current);
      hasProcessedEvent = true;
    }
  }
  // XXX: those might have re-generated expiring events...
  // It should be ok, if the INTERVALs-MAXJITTER > strategyInterval

  // Process and send all messages that would be expired by 
  // strategy time:
  packetManager->sendUpToTime(jitterStrategyEventTime);

  processChange(true);
  if (hasProcessedEvent) // XXX: is this really necessary?
    scheduleExpirationEvent();
  scheduleNextJitterStrategyEvent(shouldReschedule);
}

Time Node::adjustTimeWithGeneration(Time upcomingTime, bool& hasChanged)
{
  Time nextTime = upcomingTime;
  hasChanged = false;
  for(std::list<GenerationEvent>::iterator it = generationEventList.begin();
      it != generationEventList.end(); it++) 
    {
      if ((*it).minTime > getCurrentTime() && (*it).maxTime < nextTime) {
	nextTime = drawDouble((*it).maxTime - (*it).minTime) + (*it).minTime;
	hasChanged = true;
      }
    }
  return nextTime;
}

void Node::scheduleNextJitterStrategyEvent(bool shouldReschedule)
{
  bool hasChanged = false;
  jitterStrategyEventTime = adjustTimeWithGeneration
    (jitterStrategyEventTime, hasChanged);  

  if (shouldReschedule || hasChanged) {
    jitterStrategyEventIndex++;
    D(*log, lEventStrategy, getRealTime() << " [strategy-reschedule] " 
      << getMainAddress() << " " << jitterStrategyEventIndex << " "  
      << jitterStrategyEventTime << endl);

    addEventAt(jitterStrategyEventTime,
	     new NodeMethodCallback(this, &Node::eventJitterStrategy),
	     (void*)jitterStrategyEventIndex);
  }
}

//---------------------------------------------------------------------------

void Node::writeIfaceList(ostream& out)
{
  out << "[node-iface]";
  std::list<Address>* addressList = getAddressList();
  for(std::list<Address>::iterator it = addressList->begin();
      it != addressList->end(); it++)
    out << " "<< (*it);
  out << endl;
}

#ifndef LOG_LINK_SET
#define LOG_LINK_SET
#endif

void Node::logState(ostream& out)
{
  out << getRealTime() << " [state-begin] " << getMainAddress()
      << endl;
  out << getRealTime() << " [table-neighbor] " << getMainAddress()
      << ": " << neighborSet << endl;
#ifdef LOG_LINK_SET
  out << getRealTime() << " [table-link] " << getMainAddress()
      << ": " << linkSet << endl;
#endif
  out << getRealTime() << " [table-two-hop] " << getMainAddress()
      << ": " << twoHopNeighborSet << endl;
  out << getRealTime() << " [table-topology] " << getMainAddress()
      << ": " << topologySet << endl;
  out << getRealTime() << " [table-mpr] "<< getMainAddress()
      << ": "; writeMPRSet(out); out << endl;
  out << getRealTime() << " [table-mpr-selector] "<< getMainAddress()
      << ": " << mprSelectorSet << endl;
  out << getRealTime() << " [table-route] " << getMainAddress()
      << ": " << (*currentRoutingTable) << endl;
  out << getRealTime() << " [table-mid] " << getMainAddress()
      << ": " << ifaceAssociationSet << endl;
  out << getRealTime() << " [table-hna] " << getMainAddress()
      << ": " << hnaAssociationSet << endl;
  out << getRealTime() << " [table-duplicate] " << getMainAddress()
      << ": " << duplicateSet << endl;
#ifdef MULTICAST_RESEARCH
  out << getRealTime() << " [table-joined-group-list] " << getMainAddress()
      << ": "; writeJoinedGroupList(out); out << endl;
  out << getRealTime() << " [table-group-map] " << getMainAddress()
      << ": "; writeGroupMap(out); out << endl;
#endif

  out << getRealTime() << " [state-end] " << getMainAddress()
      << endl;


}

//---------------------------------------------------------------------------

#ifndef NO_STAT
//XXX:windows

#endif

//---------------------------------------------------------------------------
