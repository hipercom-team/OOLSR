//---------------------------------------------------------------------------
//                                OOLSR
//             Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the Multiple Interface Association Information Base.
//---------------------------------------------------------------------------

#include "base.h"

#include <list>
using std::list;

#include "node.h"

//---------------------------------------------------------------------------
/// [HNAAssociationBase] This method is called when the OLSR Node 
/// is started.

void Node::startHNABase()
{
  Time delay = _startDelay(0, protocolConfig->HNA_INTERVAL);
  addGenerationEvent(delay, delay, &Node::eventHNAGeneration,"hna-generation");
 //XXXok should we send immediatly a hna message or delay it for a random period ???
}

//---------------------------------------------------------------------------
/// [HNABase] This method is called when an HNAMessage is
/// received and should be processed.

void Node::processHNAMessage(HNAMessage* message)
{
  Message* header = message->header;
   
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();

  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress)) // @@XXX2513-2515
    //XXX: was bug: if (!isSymmetricNeighbor(header->originatorAddress))
    return; 

  for(std::list<HNAEntry>::iterator it = message->hnaEntryList.begin();
      it!=message->hnaEntryList.end(); it++)
    
    {
      HNATuple* hnaTuple;
      if(!(hnaTuple=hnaAssociationSet.findFirst_HNA
	   (header->originatorAddress,it->address,it->addressMask)))
	{
	  hnaTuple= new HNATuple;
	  hnaTuple->A_gateway_addr=header->originatorAddress;
	  hnaTuple->A_network_addr=it->address;
	  hnaTuple->A_netmask=it->addressMask;
	  hnaTuple->A_time=currentTime + validityTime; 
	  hnaAssociationSet.add(hnaTuple);
	} else hnaTuple->A_time=currentTime + validityTime; 
      hnaTuple->update();
    }
}

//---------------------------------------------------------------------------
/// [HNABase] This method is called when an HNAMessage should
/// be generated.

void Node::eventHNAGeneration()
{ 
  updateCurrentTime();
  preEvent("gen-hna");
  // reschedule  XXX: refs
  double minDelay = protocolConfig->HNA_INTERVAL - protocolConfig->MAXJITTER;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->HNA_INTERVAL,
		     &Node::eventHNAGeneration, "hna-generation");


  if (!advertisedHNAList.empty()) { // @@XXX
    HNAMessage* hnaMessage= new HNAMessage;
    HNAEntry*   hnaEntry= new HNAEntry;

    for(std::list< std::pair<Address,Address> >::iterator 
	  it = advertisedHNAList.begin(); it != advertisedHNAList.end(); it++) 
      {
	hnaEntry->address=it->first;
	hnaEntry->addressMask=it->second;
	hnaMessage->hnaEntryList.push_back((*hnaEntry));
      }
    Message* message = new Message
      (HNA_MESSAGE, 
       toMantissaExponentByte(protocolConfig->HNA_HOLD_TIME), 
       getMainAddress(), // Originator 
       MaxTTL, // ttl, 
       0); // hop vcount, 
    
    message->content = hnaMessage;
    message->maxTime = getCurrentTime();
    
    packetManager->sendMessageToAll(message);
  }
  postEvent("gen-hna");
}

//---------------------------------------------------------------------------

void HNASet::notifyRemoval(HNATuple* tuple)
{ node->shouldRecomputeRoute = true; }

void HNASet::notifyAddition(HNATuple* tuple)
{ node->shouldRecomputeRoute = true; }

//---------------------------------------------------------------------------

