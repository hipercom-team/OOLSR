//---------------------------------------------------------------------------
//                             OOLSR
//              Yasser Toor, projet Hipercom, INRIA Rocquencourt
//      Nicolas Grzeskowiak, projet Hipercom, INRIA Rocquencourt
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Cygwin
//---------------------------------------------------------------------------

#if 0
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h> // XXX: for windows
#include <iptypes.h>
#include <iphlpapi.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h> //+
#include <sys/types.h>
//#include <netdb.h>
//#include <net/if.h>
//#include "linux
//#include <sys/select.h>

#include <arpa/inet.h> // inet_pton

#include <errno.h>

#include "general.h"
#include "address.h"
#include "network_generic.h"
//#include "network_linux.h"
#include "scheduler_simulation.h"
#include "scheduler_unix.h"


//---------------------------------------------------------------------------

extern void cygwinGetIfaceByName(string name, 
				 ProtocolConfig* protocolConfig, 
				 IfaceConfig* ifaceConfig,
				 sockaddr_in& ifaceAddress, 
				 int& ifaceIndex);

extern void cygwinAddRoute(ISystemIface* iface, sockaddr_in& destIpAddress,
			   sockaddr_in& gatewayAddress, 
			   Address netMaskAddress, 
			   int metric);
  
extern void cygwinRemoveRoute(ISystemIface* iface, sockaddr_in& destIpAddress,
			      sockaddr_in& gatewayAddress, 
			      Address netMaskAddress, 
			      int metric);

//---------------------------------------------------------------------------

// XXX: why in this file ?
#ifdef WITH_HTTPSERVER // XXX: this is a hack

#include "http_support.h"

#include "html_support.cc" // XXX:  rename


IHTTPServer* httpServer = NULL;
extern IHTTPServer* makeHTTPServer();

#include "node.h" // XXX
void startHTTPServer(IOScheduler* scheduler, Node* node)
{
  httpServer = makeHTTPServer();
  httpServer->open(scheduler, node->getProtocolConfig()->httpAdminPort,
		   new ProtocolHTTPVisitor(node) /*XXX: leak*/);
}
#else // !WITH_HTTPSERVER
void startHTTPServer(IOScheduler* scheduler, Node* node)
{ /* do nothing */ }
#endif // WITH_HTTPSERVER

//---------------------------------------------------------------------------


//
// See also:
// http://www.ietf.org/rfc/rfc3542.txt
//

//---------------------------------------------------------------------------

class CygwinLowLevel
{
public:
  static void setSocketReuseAddr(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char*)&on, /* was void* */
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_REUSEADDR: " << strerror(errno));
  }

  static void setSocketBroadcast(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_BROADCAST, (char*)&on,
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_BROADCAST: " << strerror(errno));
  }
};

#define STR_IP_BROADCAST "255.255.255.255" // XXX: defined twice

//---------------------------------------------------------------------------

class CygwinIPv4LowLevel : public CygwinLowLevel
{
public:
  static const int AddressSize = 4; // XXX: correct one

  //  &ipv6Address.sin6_addr

  typedef sockaddr_in SystemAddress;

  static void* systemAddressToRawAddress(SystemAddress& systemAddress) {
    assert( systemAddress.sin_family == AF_INET );
    assert( sizeof(systemAddress.sin_addr) == AddressSize );
    return &systemAddress.sin_addr;
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin_family = AF_INET;
    memcpy(&resultAddress.sin_addr, rawAddress, AddressSize);
  }

  static void reprAddress(SystemAddress& address, char* result)
  { 
    //inet_ntop(AF_INET, &address.sin_addr, result, 4096 /*XXX!*/); 
    strcpy(result, inet_ntoa(address.sin_addr));
  }

  static int makeUDPSocket()
  {
    int sd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(SystemAddress& sockAddress, char* strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin_family = AF_INET;

    if (strGroupAddress == NULL)
      sockAddress.sin_addr.s_addr = INADDR_ANY; // XXX
    else sockAddress.sin_addr.s_addr = inet_addr(strGroupAddress); 
  }

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin_port = htons(udpPort); }

  static void joinMulticastGroup(int sd, int ifaceIndex /* unused */, 
				 SystemAddress& ifaceAddress,
				 char* strGroupAddress)
  {
    if ( string(strGroupAddress) == STR_IP_BROADCAST) {
      // we don't actually "join" in this case
      setSocketBroadcast(sd);
      //char* tmpIfaceName = strdup(ifaceName.c_str());
      //      setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, tmpIfaceName,
      //	 strlen(tmpIfaceName)+1);
      //free(tmpIfaceName);

      return; 
    }


    //XXX: use ip_mreq_source and imr_address for IGMPv3
    struct ip_mreq mreq; // not mreqn




    memset (&mreq, 0, sizeof (mreq));
    //inet_pton(AF_INET, strGroupAddress, &mreq.imr_multiaddr);
    mreq.imr_multiaddr.s_addr = inet_addr(strGroupAddress);
    mreq.imr_interface = ifaceAddress.sin_addr;

    
    if(setsockopt(sd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal(" setsockopt IP_ADD_MEMBERSHIP: " << strerror(errno) );
  }

  // http://www.tldp.org/HOWTO/Multicast-HOWTO-6.html
  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    if (setsockopt(sd, IPPROTO_IP, IP_MULTICAST_IF, 
		   (char*)&ifaceAddress.sin_addr,
		   sizeof(ifaceAddress.sin_addr)) < 0)
      Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );
  }

  //XXX: redundant with IPv6, should be templatized
  static void socketBind(int sd, SystemAddress& address)
  {
    address.sin_addr.s_addr = INADDR_ANY; // XXX!! kludge
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, (char*)buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }

  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, (char*)data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Fatal(" sendto: " << strerror(errno) );// XXX: not fatal
  }
};

//---------------------------------------------------------------------------

template <class LowLevel>
class LinuxAddressFactory : public AddressFactory
{
public:

  typedef typename LowLevel::SystemAddress SystemAddress;

  LinuxAddressFactory() : AddressFactory(LowLevel::AddressSize)
  {}

  Address makeAddress(SystemAddress& systemAddress) 
  { return Address(this, LowLevel::systemAddressToRawAddress(systemAddress)); }

  void makeSystemAddress(Address address, SystemAddress& result)
  { LowLevel::rawAddressToSystemAddress(address.getRawAddress(), result); }

  virtual void write(ostream& out, const Address& address)
  {
    typename LowLevel::SystemAddress systemAddress;
    LowLevel::rawAddressToSystemAddress(address.getRawAddress(),
					systemAddress);
    char strAddress[4096]; // XXX
    LowLevel::reprAddress(systemAddress, strAddress);
    out << strAddress;
  }
};

typedef LinuxAddressFactory<CygwinIPv4LowLevel> CygwinIPv4AddressFactory;

//---------------------------------------------------------------------------

#define OLSR_PORT 698 // XXX: not really

template<class LowLevel>
class CygwinSystemIface : public ISystemIface, public IFdHandler
{
public:
  Address address;
  IPacketReceiver* packetReceiver;
  IOScheduler* scheduler;
  LinuxAddressFactory<LowLevel>* addressFactory;
  char* strOutputAddress;

  CygwinSystemIface(char* aIfaceName, Address aAddress, int aIfaceIndex,
		   IOScheduler* aScheduler,
		   LinuxAddressFactory<LowLevel>* aFactory,
		   char* aStrOutputAddress, IfaceConfig* aIfaceConfig)
    : address(aAddress), packetReceiver(NULL), scheduler(aScheduler),
      addressFactory(aFactory), ifaceIndex(aIfaceIndex), name(aIfaceName)
  {
    ifaceSocket = -1;
    associatedIface = NULL;
    strOutputAddress = strdup(aStrOutputAddress);
    ifaceConfig = aIfaceConfig; // from ISystemIface
  }

  virtual void openSocket(IPacketReceiver* aPacketReceiver)
  {
    packetReceiver = aPacketReceiver;
    // Create output socket.
    ifaceSocket = LowLevel::makeUDPSocket(); //ipv6MakeUDPSocket();
    typename LowLevel::SystemAddress ifaceSystemAddress;
    addressFactory->makeSystemAddress(address, ifaceSystemAddress);

    // XXX: Windows: must bind before joining multicast group
    typename LowLevel::SystemAddress anyOLSRPortAddress;
    addressFactory->makeSystemAddress(address, anyOLSRPortAddress);
    //LowLevel::strToAddress(anyOLSRPortAddress, NULL);
    LowLevel::setAddressPort(anyOLSRPortAddress, OLSR_PORT);
    LowLevel::socketBind(ifaceSocket, anyOLSRPortAddress);


    LowLevel::setSocketReuseAddr(ifaceSocket);
    LowLevel::setSocketMulticastDefaultIface(ifaceSocket, ifaceIndex, 
					     ifaceSystemAddress);
    LowLevel::joinMulticastGroup(ifaceSocket, ifaceIndex, ifaceSystemAddress,
				 strOutputAddress);
    LowLevel::strToAddress(sendSystemAddress, strOutputAddress);
    LowLevel::setAddressPort(sendSystemAddress, OLSR_PORT);


    scheduler->addFdHandler(this, NULL);
  }
  
  virtual void sendPacket(MemoryBlock* packet) 
  {
    LowLevel::socketSend(ifaceSocket, packet->data, packet->size, 
			 sendSystemAddress);
    delete packet; // XXX: check memory is freed
  }

  virtual int getMTU()
  { return ifaceConfig->mtu; }

  virtual Address getAddress()
  { return address; }


  // IFdHandler
  virtual FileDescriptor getFileDescriptor() { return ifaceSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; } // XXX:  check
  virtual void handleInput()
  {
    const int MaxBufferSize = 65536;
    octet* buffer = new octet[MaxBufferSize]; // XXX: not inline
    typename LowLevel::SystemAddress recvAddress;
    int maxSize = MaxBufferSize;
    int status = LowLevel::socketRecv(ifaceSocket, buffer, 
				      maxSize, recvAddress);
    if(status > 0) { // XXX: what if == 0, closed?
      MemoryBlock* packet = new MemoryBlock(buffer, status, true);
      packetReceiver->evReceivePacket
	(packet, addressFactory->makeAddress(recvAddress), 
	 this->associatedIface);
    }
    delete buffer;
  }

  virtual void handleOutput() { Fatal("Impossible call"); }
  virtual void handleExcept() { Fatal("Impossible call"); }

  // borrowed
  char* getName() { return name; }

  int getIfaceIndex() { return ifaceIndex; }

protected:
  typename LowLevel::SystemAddress sendSystemAddress;

  int ifaceSocket;
  int ifaceIndex;
  char* name; // system name of the interface
};


int getCygwinIfaceIndex(ISystemIface* iface)
{
  CygwinSystemIface<CygwinIPv4LowLevel>* ipv4Iface 
    = (CygwinSystemIface<CygwinIPv4LowLevel>*) iface;
  return ipv4Iface->getIfaceIndex();
}

//---------------------------------------------------------------------------

#if 0
void
int on;
  on=6;
  if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &on, sizeof (on)) < 0)
    Fatal("setsockopt SO_PRIORITY: " << strerror(errno));

#endif

//---------------------------------------------------------------------------


class CygwinIPv4NetworkConfigurator : public INetworkConfigurator
{
public:

  CygwinIPv4NetworkConfigurator(CygwinIPv4AddressFactory* aAddressFactory)
    : addressFactory(aAddressFactory) { }


  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  { 
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);

    cygwinAddRoute(iface, destSysAddr, gatewaySysAddr, netMaskAddress,
		   metric); 
  }

  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  { 

   sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    cygwinRemoveRoute(iface, destSysAddr, gatewaySysAddr, netMaskAddress,
		   metric); 
  }


  /// Add one route in the kernel
  
  CygwinIPv4AddressFactory* addressFactory;
};

//---------------------------------------------------------------------------

extern void startWinSock2(void); // XXX

class CygwinIPv4SystemFactory : public ISystemFactory
{
public:
  int skfd;

  CygwinIPv4SystemFactory() 
  {
    startWinSock2();
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new CygwinIPv4NetworkConfigurator(&addressFactory);
  }

  virtual ~CygwinIPv4SystemFactory() {}

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(ProtocolConfig* protocolConfig, 
				       string name, IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }
  
  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }

protected:
  CygwinIPv4AddressFactory addressFactory;
  CygwinIPv4NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
};

ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return new CygwinIPv4SystemFactory; }

ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }

//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

//typedef LinuxAddressFactory<LinuxIPv4LowLevel> LinuxIPv4AddressFactory;

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#if 0
  // XXX! should be in a helper module
  //turn ip forwarding on
  if (!initialized ) {
    memset(&Overlapped,0, sizeof(OVERLAPPED));
    Overlapped.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (EnableRouter(&Handle, &Overlapped) != ERROR_IO_PENDING) 
      printf("Error: Could not turn IP forwarding on\n");
    initialized = 1;
  }
  if (GetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
  lstats.dwForwarding = MIB_IP_FORWARDING; //start forwarding
  if (SetIpStatistics(&lstats) != NO_ERROR) 
    printf("Error: Could not turn IP forwarding on\n");
#endif

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#define MAX_INTERFACES	100

ISystemIface* CygwinIPv4SystemFactory::getIfaceByName
(ProtocolConfig* protocolConfig, string name, IfaceConfig* ifaceConfig)
{

  int ifaceIndex;
  sockaddr_in tmpAddress;
  cygwinGetIfaceByName(name, protocolConfig, ifaceConfig, tmpAddress,
		       ifaceIndex);
  Address ifaceAddress = addressFactory.makeAddress(tmpAddress);
  return new 
    CygwinSystemIface<CygwinIPv4LowLevel>
    ( (char*)/*XXX*/name.c_str(), ifaceAddress,
      ifaceIndex,
      scheduler, &addressFactory,
      (char*)/*XXX*/protocolConfig->ipv4MulticastAddress.c_str(),
      ifaceConfig);
}

//---------------------------------------------------------------------------

ISystemFactory* getSystemFactory()
{ return new CygwinIPv4SystemFactory; }

//---------------------------------------------------------------------------
