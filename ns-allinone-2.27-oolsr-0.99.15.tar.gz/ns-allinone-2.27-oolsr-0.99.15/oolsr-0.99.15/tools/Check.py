#---------------------------------------------------------------------------
#                       OOLSR (from pyOLSR)
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003-2004 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# $Id: Check.py,v 1.15 2004/08/05 08:10:08 adjih Exp $
#---------------------------------------------------------------------------
# Check.py: implements some extensive checking of tables in static
# configurations (based on the actual topology)
# Based on pyOLSR Check.py, adapted to new log files.
#---------------------------------------------------------------------------

import sys

#from Constant import *
#import NeighborSensing, TopologyDiscovery, RoutingTable, PacketManager
#import IfaceAssociationBase

#---------------------------------------------------------------------------

class Graph:
    def __init__(self):
        self.nodeList = []
        self.linkTable = {}
        self.ifaceToNode = {}
        self.ifaceListTable = {}
        self.unwillingList = []

    def recordNode(self, src):
        return
        #src = self.ifaceToNode[src]
        if src not in self.nodeList:
            self.nodeList.append(src)

    def addLink(self, src, dst):
        self.recordNode(src)
        self.recordNode(dst)
        self.linkTable[(src,dst)] = True
        self.linkTable[src] = self.linkTable.get(src, []) + [dst]
        self.routeUpToDate = False

    def removeLink(self, src, dst):
        del self.linkTable[(src,dst)] 
        self.linkTable[src].remove(dst)
        self.routeUpToDate = False

    def hasLinkTo(self, srcIface, dstIface):
        return self.linkTable.has_key((srcIface,dstIface))

    def hasSymLink(self, iface1, iface2):
        return self.hasLinkTo(iface1,iface2) and self.hasLinkTo(iface2, iface1)

    def isSymNeighbor(self, node1, node2):
        for iface1 in self.ifaceListTable[node1]:
            for iface2 in self.ifaceListTable[node2]:
                if self.hasSymLink(iface1, iface2): return True
        return False

    def getTwoHop(self, nodeName, strict = False):
        result = {}
        if strict: excludedList = self.getOneHop(nodeName)
        else: excludedList = []
        for oneHop in self.getOneHop(nodeName):
            if strict and oneHop in self.unwillingList:
                continue
            result[oneHop] = []
            for twoHop in self.getOneHop(oneHop):
                if twoHop != nodeName and twoHop not in excludedList:
                    result[oneHop].append(twoHop)
        return result

    def getOneHop(self, nodeName):
        result = {}
        for iface1 in self.ifaceListTable[nodeName]:
            for iface2 in self.linkTable.get(iface1, []):
                if self.linkTable.has_key((iface2,iface1)): # Sym
                    otherNodeName = self.ifaceToNode[iface2]
                    result[otherNodeName] = True
        return result.keys()

    def hasOneLinkTo(self, node1, node2):
        for iface1 in self.ifaceListTable[node1]:
            for iface2 in self.ifaceListTable[node2]:
                if self.hasLinkTo(iface1, iface2): return True
        return False

    def setNodeIfaceList(self, nodeName, ifaceList):
        self.ifaceListTable[nodeName] = ifaceList
        for iface in ifaceList:
            self.ifaceToNode[iface] = nodeName

#---------------------------------------------------------------------------

class Checker(Graph):
    def __init__(self):
        Graph.__init__(self)
        self.nodeInfoTable = {}
        self.routeUpToDate = False

    def setNodeInfo(self, nodeName, nodeInfo):
        #self.recordNode(nodeName)
        self.nodeList.append(nodeName)
        self.nodeInfoTable[nodeName] = nodeInfo
        #if (nodeInfo.config != None
        #    and nodeInfo.config["willingness"] == 0):
        #    self.unwillingList.append(nodeName)
        if int(nodeInfo.config["willingness"]) == 0:
            self.unwillingList.append(nodeName)

    def prepareCheck(self):
        self.prepared = True
        # Remove links to one self
        for info in self.linkTable.keys()[:]:
            if type(info) == type( ("t","uple") ):
                src,dst = info
                if self.ifaceToNode[src] == self.ifaceToNode[dst]:
                    self.removeLink(src, dst)

    def checkNode(self, nodeName, checkInfo):
        assert self.prepared
        errorList = (  self._checkNeighbor(nodeName)
                     + self._checkTwoHopNeighbor(nodeName)
                     + self._checkMPRSet(nodeName) # XXX name consistency
                     + self._checkMPRSelector(nodeName)
                     + self._checkTopology(nodeName)
                     + self._checkRoutingTable(nodeName)
                     + self._checkDuplicateTable(nodeName)
                     + self._checkIfaceAssociation(nodeName))
        #if errorList != []:
        #    print "-" * 50
        #    print checkInfo
        #    print self.linkTable
        #    print errorList
        return errorList

    def _checkNeighbor(self, nodeName):
        errorList = []
        
        nodeInfo = self.nodeInfoTable[nodeName]
        neighborSet = nodeInfo.neighborSet
        linkSet = nodeInfo.linkSet

        def isExpired(clock): return clock<nodeInfo.clock
       
        # Rule 1: all real links must be present in the link set
        #   that if A -> B, then:
        #   1.1) B must have a link tuple with A which is not expired
        #   1.2) if A <-> B, the link must have status symmetrical
        #        elif A -> B only, the link must have status asymmetrical
        for otherNodeName in self.nodeList:
            if otherNodeName == nodeName: continue
            for srcIface in self.ifaceListTable[otherNodeName]:
                for dstIface in self.linkTable.get(srcIface, []):
                    if dstIface not in self.ifaceListTable[nodeName]: continue
                    t = linkSet.findFirst(
                        lambda x: x.L_local_iface_addr == dstIface
                        and x.L_neighbor_iface_addr == srcIface)
                    if t == None or isExpired(t.L_time):
                        errorList.append(
                            ("missing link", nodeInfo.clock,
                             nodeName, linkSet, (srcIface, dstIface)))
                    else:
                        isSym =  self.hasLinkTo(dstIface, srcIface)
                        if ((isSym and t.status != SYM_LINK)
                            or (not isSym and t.status != ASYM_LINK)):
                            errorList.append(
                                ("bad link status", nodeInfo.clock,
                                 nodeName, linkSet, (srcIface, dstIface), t))
       
        # Rule 2: all link presents in the link set must be real links,
        #   that is:
        #   if link with status == ASYM in A, then there must be B -> A
        #   else if link with status == SYM in A, then there must be B <-> A
        # Rule 3: all neighbors with a valid link must be in neighbor set
        for t in linkSet.iter():
            if t.status == LOST_LINK or isExpired(t.L_time): continue
            dstIface = t.L_local_iface_addr
            srcIface = t.L_neighbor_iface_addr

            if not self.hasLinkTo(srcIface, dstIface):
                errorList.append( ("inexistant link", nodeInfo.clock,
                                   nodeName, linkSet, (srcIface, dstIface), t))

            assert t.status == SYM_LINK or t.status == ASYM_LINK
            isSym = (t.status == SYM_LINK)
            if ((isSym and not self.hasSymLink(srcIface, dstIface))
                 or (not isSym and self.hasLinkTo(dstIface, srcIface))):
                errorList.append( ("bad link status", nodeInfo.clock,
                                   nodeName, linkSet, (srcIface, dstIface), t))

            # (rule3)
            srcNode = self.ifaceToNode[srcIface]
            nt = neighborSet.findFirst(
                lambda x: x.N_neighbor_main_addr == srcNode)
            if nt == None:
                errorList.append( ("missing neighbor tuple", nodeInfo.clock,
                                   nodeName, linkSet, (srcIface, dstIface), t,
                                   srcNode) )
                
        # Rule 4: all neighbors must be such as
        #   4.1) there is at least one link
        #   4.2) the status is SYM iff there is one symetrical link
        for t in neighborSet.iter():
            hasLink = linkSet.findFirst(lambda x: x.neighborTuple == t)
            #if not self.hasOneLinkTo(t.N_neighbor_main_addr, nodeName):
            if not hasLink:
                errorList.append( ("inexistant neighbor", nodeInfo.clock,
                                   nodeName, linkSet, t) )
                continue
            isSym = self.isSymNeighbor(t.N_neighbor_main_addr, nodeName)
            assert t.N_status == SYM or t.N_status == NOT_SYM
            if ((isSym and t.N_status == NOT_SYM)
                or (not isSym and t.N_status == SYM)):
                errorList.append( ("bad neighbor status", nodeInfo.clock,
                                   nodeName, linkSet, t) )
                
        return errorList

    def _checkTwoHopNeighbor(self, nodeName):
        # The check is performed the following way
        # 1) Find all the two hop real neighbors and record
        #    for each a tuple (oneHop, twoHop)
        # 2) Find all the two hop neighbors in the two hop neighbor set
        #    and for each, record a tuple (oneHop,twoHop)
        # 3) Check that the set of the tuples of 1) is exactly the same
        #    as the set of tuples of 2). Any difference is an error.
        errorList = []
        
        nodeInfo = self.nodeInfoTable[nodeName]
        twoHopNeighborSet = nodeInfo.twoHopNeighborSet

        def isExpired(clock): return clock<nodeInfo.clock

        def flatten(table):
            l = [ [(x,y) for y in table[x]] for x in table.keys() ]
            return reduce(lambda x,y: x+y, l, [])

        twoHopTable = self.getTwoHop(nodeName)
        otherTwoHopTable = {}
        for t in nodeInfo.twoHopNeighborSet.iter():
            if isExpired(t.N_time): continue
            oneHop = t.N_neighbor_main_addr
            twoHop = t.N_2hop_addr
            otherTwoHopTable[oneHop] = (otherTwoHopTable.get(oneHop, [])
                                        + [twoHop])
            
        twoHopTable = flatten(twoHopTable)
        otherTwoHopTable = flatten(otherTwoHopTable)
        for table1, table2,m in [(twoHopTable, otherTwoHopTable, "missing"),
                       (otherTwoHopTable, twoHopTable, "inexistant")]:
            for t in table1 :
                if t not in table2:
                    print nodeInfo, self.getTwoHop(nodeName)
                    errorList.append( (m+" two hop tuple", nodeInfo.clock,
                                       nodeName, twoHopNeighborSet, t) )
        return errorList

    def _checkMPRSet(self, nodeName):
        # The check is performed the following way:
        # - the coverage of all MPR in the MPR set is compared to the
        # two hop neighborhood. Any difference is an error.
        errorList = []

        nodeInfo = self.nodeInfoTable[nodeName]
        # XXX!: should not take into account nodes via oneHop WILL_NEVER
        
        twoHopSet = {}
        twoHopTable = self.getTwoHop(nodeName, True)
        for nodeTwoHopList in twoHopTable.values():
            # XXX!
            for twoHop in nodeTwoHopList:
                twoHopSet[twoHop] = True
        twoHopList = twoHopSet.keys()

        coveredTwoHopSet = {}
        for t in nodeInfo.mprList:
            for twoHop in twoHopTable.get(t, []):
                coveredTwoHopSet[twoHop] = True
        coveredTwoHopList = coveredTwoHopSet.keys()

        for t in twoHopList:
            if t not in coveredTwoHopList:
                errorList.append( ("two hop neighbor not covered by MPR",
                                   nodeInfo.clock, nodeName, twoHopTable,
                                   nodeInfo.mprList, t) )
        return errorList

    def _checkMPRSelector(self, nodeName):
        # The check is performed the following way:
        # 1) each MPR X of a node Y, must have Y in its MPR selector set
        # 2) each MPR selector X of a node Y, must have X in its MPR list
        errorList = []

        def isExpired(clock): return clock<nodeInfo.clock
        
        nodeInfo = self.nodeInfoTable[nodeName]
        for mpr in nodeInfo.mprList:
            mprNodeInfo = self.nodeInfoTable[mpr]            
            t = mprNodeInfo.mprSelectorSet.findFirst(
                lambda x: x.MS_addr == nodeName)
            if t == None or isExpired(t.MS_time):
                errorList.append( ("X, mpr of Y, has not Y as MPR selector",
                                   nodeInfo.clock, nodeName, mpr,
                                   nodeInfo.mprList, mprNodeInfo))

        for t in nodeInfo.mprSelectorSet.iter():
            if isExpired(t.MS_time): continue
            mprNodeInfo = self.nodeInfoTable[t.MS_addr]
            if nodeName not in mprNodeInfo.mprList:
                errorList.append( ("X, in mpr selector set of Y, has not Y "
                                   +"in its MPR set", nodeInfo.clock,
                                   nodeName, t, mprNodeInfo.mprList,
                                   mprNodeInfo))
        return errorList

    def _checkTopology(self, nodeName):
        # The check is performed the following way: (XXX: update)
        # 1) each MPR selector X of a node Y, must be in all the topology table
        #    of all the other nodes which can be reached from Y
        # 2) each topology entry X => Y of a node, must be such that Y is
        #    mpr of X (according to mprList of X)
        # XXX! this is much more strict than standard compliance
        errorList = []
        self._ensureRouteUpToDate()
        def isExpired(clock): return clock<nodeInfo.clock
        nodeInfo = self.nodeInfoTable[nodeName]

        for t in nodeInfo.mprSelectorSet.iter():
            for otherNodeName in self.nodeList:
                if otherNodeName == nodeName: continue
                canReach = self.canReach(nodeName, otherNodeName)
                otherNodeInfo = self.nodeInfoTable[otherNodeName]
                tt = otherNodeInfo.topologySet.findFirst(
                    lambda x: x.T_dest_addr == t.MS_addr
                    and x.T_last_addr == nodeName)
                hasTopologyTuple = not (tt == None or isExpired(tt.T_time))
                if ((not hasTopologyTuple and canReach)
                    or (hasTopologyTuple and not canReach)):
                    errorList.append(
                        ("X is MPR selector of Y, but topology "
                         +"tuple Y@X is missing/existing in node Z",
                         nodeInfo.clock, nodeName, t, t.MS_addr,
                         otherNodeName, otherNodeInfo.topologySet))
        
        for t in nodeInfo.topologySet.iter():
            if isExpired(t.T_time): continue
            destNodeInfo = self.nodeInfoTable[t.T_dest_addr]
            # XXX: check canReach
            if t.T_last_addr not in destNodeInfo.mprList:
                errorList.append( ("X->Y in topology set of Z but "
                                   +"Y is not MPR of X", nodeInfo.clock,
                                   nodeName, t, destNodeInfo.mprList))
            
        return errorList

    def _checkRoutingTable(self, nodeName):
        # The check is performed the following way:
        # 1) Each routing table entry must have a reachable destination
        #    with correct distance and [iface : next_hop_iface] must be
        #    a symetrical link.
        # 2) Each reachable node must have at least one routing table entry.

        errorList = []
        self._ensureRouteUpToDate()
        nodeInfo = self.nodeInfoTable[nodeName]        

        for t in nodeInfo.routingTable.iter():
            mainDest = self.ifaceToNode[t.R_dest_addr]
            if not self.routeTable[nodeName].has_key(mainDest):
                errorList.append(("Route to an unreachable node",
                                  nodeInfo.clock, nodeName, t))
                continue
            next,distance = self.routeTable[nodeName][mainDest]
            if distance != t.R_dist:
                errorList.append(("Route with an incorrect distance",
                                  nodeInfo.clock, nodeName, t, distance))
                continue
            if t.R_iface_addr not in self.ifaceListTable[nodeName]:
                errorList.append(("Route with an incorrect iface address",
                                  nodeInfo.clock, nodeName, t,
                                  self.ifaceToNode[nodeName]))
                continue
            if not self.hasSymLink(t.R_iface_addr, t.R_next_addr):
                errorList.append(("Route with incorrect link: next hop iface "
                                  +"address has not symmetrical link",
                                  nodeInfo.clock, nodeName, t,
                                  self.ifaceToNode[nodeName]))

        for otherNodeName in self.nodeList:
            if self.canReach(nodeName, otherNodeName):
                t = nodeInfo.routingTable.findFirst(
                    lambda x: self.ifaceToNode[x.R_dest_addr] == otherNodeName)
                if t == None:
                    errorList.append(("No route to reachable node",
                                      nodeInfo.clock, nodeName, otherNodeName))
                
        return errorList

    def _checkDuplicateTable(self, nodeName):
        # No checks are performed on duplicate table
        return []

    def _checkIfaceAssociation(self, nodeName):
        # XXX: implement iface association set
        errorList = []
        
        return errorList


    def canReach(self, node1, node2):
        return self.routeTable[node1].has_key(node2)

    def _ensureRouteUpToDate(self):
        if self.routeUpToDate: return
        routeTable = {}        
        finished = False

        # Route computation:
        for nodeName in self.nodeList: routeTable[nodeName] = {}
        
        changedDistanceList = [ (x,x,0) for x in self.nodeList[:] ]
        while len(changedDistanceList)>0:
            newChangedDistanceList = []
            for nodeName in self.nodeList:
                for next, dst, distance in changedDistanceList:
                    if dst == nodeName: continue
                    if next!=dst and next in self.unwillingList: continue
                    if self.isSymNeighbor(nodeName, next):
                        if (not routeTable[nodeName].has_key(dst)
                            or routeTable[nodeName][dst][1]> distance+1):
                            routeTable[nodeName][dst] = (next, distance+1)
                            newChangedDistanceList.append(
                                (nodeName, dst, distance+1) )
            changedDistanceList = newChangedDistanceList
            
        self.routeTable = routeTable

#---------------------------------------------------------------------------

class TupleSet:
    def __init__(self):
        self.content = []
        
    def add(self, tuple):
        self.content.append(tuple)
        
    def findFirst(self, f):
        for x in self.content:
            if f(x): return x
        return None

    def iter(self): return iter(self.content)

    def __repr__(self): return repr(self.__dict__)

class Tuple:
    def __init__(self):
        pass
    def addLink(self, whatever): pass
    def __repr__(self): return repr(self.__dict__)

#---------------------------------------------------------------------------

class NodeInfo:
    def __init__(self, nodeName):
        self.name = nodeName
        self.neighborSet = TupleSet() #NeighborSensing.NeighborSet(None)
        self.linkSet = TupleSet() #NeighborSensing.LinkSet(None)
        self.routingTable = TupleSet() #RoutingTable.RoutingTable(None)
        self.duplicateSet = TupleSet() #PacketManager.DuplicateSet(None)
        self.topologySet = TupleSet() #TopologyDiscovery.TopologySet(None)
        self.twoHopNeighborSet = TupleSet() #NeighborSensing.TwoHopNeighborSet(None)
        self.mprSelectorSet = TupleSet() #TopologyDiscovery.MPRSelectorSet(None)
        self.mprList = []
        (self.ifaceAssociationSet
         ) = TupleSet() #IfaceAssociationBase.IfaceAssociationSet(None)
        
    def __repr__(self):
        return "<<Node %s>>" % self.name


SYM = "SYM"
NOT_SYM = "NOT_SYM"

SYM_LINK = "SYM_LINK"
ASYM_LINK = "ASYM_LINK"
LOST_LINK = "LOST_LINK"

def parseState(f, expectedNodeName):
    nodeInfo = NodeInfo(expectedNodeName)
    lastClock = None
    while 1:
        line = f.readline().strip()
        data = line.split(" ")
        clock = float(data[0])
        name = data[1]
        nodeName = data[2]

        assert lastClock == clock or lastClock == None
        lastClock = clock
        nodeInfo.clock = clock

        if name == "[state-end]":
            return nodeInfo
        elif name == "[state-begin]": pass
        elif name == "[table-route]":

            if len(data)<=3: continue

            nodeName = data[2].strip(":")
            assert nodeName == expectedNodeName
            for routeInfo in data[3].split(";"):
                src,next,dst = routeInfo.split("->")
                dst = dst.split("(")
                distance = int(dst[1].strip(")"))
                dst = dst[0]
                t = Tuple() #RoutingTable.RoutingTuple()
                t.R_dest_addr = dst
                t.R_next_addr = next
                t.R_dist = distance
                t.R_iface_addr = src
                nodeInfo.routingTable.add(t)
                    
        elif name == "[table-mid]":
            if len(data)<=3: continue

            for midInfo in (" ".join(data[3:])).split(";"):
                midInfo = midInfo.split(" ")

                clockInfo = midInfo[1].split("\\")
                unused, expireTime = clockInfo[0].split("/")
                expireTime = float(expireTime)

                t = Tuple()
                mainAddr,ifaceAddr = midInfo[0].split("@")
                t.I_iface_addr = ifaceAddr
                t.I_main_addr = mainAddr
                t.I_time = expireTime

                nodeInfo.ifaceAssociationSet.add(t)

        elif name == "[table-hna]":
            if len(data)<=3: continue

            for hnaInfo in (" ".join(data[3:])).split(";"):
                WHATEVER
                midInfo = midInfo.split(" ")

                clockInfo = midInfo[1].split("\\")
                unused, expireTime = clockInfo[0].split("/")
                expireTime = float(expireTime)

                t = IfaceAssociationBase.IfaceAssociationTuple()
                mainAddr,ifaceAddr = midInfo[0].split("@")
                print midInfo
                t.I_iface_addr = ifaceAddr
                t.I_main_addr = mainAddr
                t.I_time = expireTime

                nodeInfo.ifaceAssociationSet.add(t)
            
        elif name == "[table-neighbor]":
            
            if len(data)<=3: continue
                
            nodeName = data[2].strip(":")
            assert nodeName == expectedNodeName
            for neighborInfo in (" ".join(data[3:])).split(";"):
                assert neighborInfo.endswith("]")
                neighborInfo, linkInfo = neighborInfo[:-1].split("[")
                neighborInfo = neighborInfo.split(" ")
                t = Tuple() #NeighborSensing.NeighborTuple(None)
                t.N_neighbor_main_addr = neighborInfo[0]
                if neighborInfo[1] == "sym": t.N_status = SYM
                elif neighborInfo[1] == "not-sym": t.N_status = NOT_SYM
                else: raise FatalError, neighborInfo
                t.N_willingness = None # XXX! should be implemented
                for linkInfo in linkInfo.split(","):
                    lt = Tuple() #NeighborSensing.LinkTuple()
                    linkInfo = linkInfo.split(" ")
                    dstAddress,ifaceAddress = linkInfo[0].split("@")
                    lastLinkInfo = linkInfo[1].split("\\")
                    expired,expireTime = lastLinkInfo[0].split("/")
                    expireTime = float(expireTime)

                    lt.L_local_iface_addr = ifaceAddress
                    lt.L_neighbor_iface_addr = dstAddress
                    lt.L_time = expireTime
                    lt.neighborTuple = t
                    if linkInfo[2] == "sym": lt.status = SYM_LINK
                    elif linkInfo[2] == "asym": lt.status = ASYM_LINK
                    elif linkInfo[2] == "lost": lt.status = LOST_LINK
                    else: raise "IMPOSSIBLE", linkInfo

                    t.addLink(lt)
                    nodeInfo.linkSet.add(lt)
                    
                nodeInfo.neighborSet.add(t)
                    
        elif name == "[table-duplicate]":

            if len(data)<=3: continue
            if 0:
                #XXX: implement back
                for duplicateInfo in (" ".join(data[3:])).split(";"):
                    t = PacketManager.DuplicateTuple()
                    duplicateInfo = duplicateInfo.split(" ")
                    srcAddress,seqNum = duplicateInfo[0].split(":")
                    t.D_addr = srcAddress
                    t.D_seq_num = int(seqNum)
                    t.D_iface_list = duplicateInfo[1].split(",")
                    t.D_retransmitted = bool(duplicateInfo[2])
                    nodeInfo.duplicateSet.add(t)
        
        elif name == "[table-mpr]":

            if len(data)<=3: nodeInfo.mprList = []
            else: nodeInfo.mprList = data[3].split(";")
            
        elif name == "[table-topology]":

            if len(data)<=3: continue
            for topologyInfo in (" ".join(data[3:])).split(";"):
                topologyInfo = topologyInfo.split(" ")
                srcAddress, dstAddress = topologyInfo[0].split("->")
                clockInfo = linkInfo[1].split("\\")
                unusedSymbol, expireTime = clockInfo[0].split("/")
                expireTime = float(expireTime)
                t = Tuple() #TopologyDiscovery.TopologyTuple()
                t.T_last_addr = srcAddress
                t.T_dest_addr = dstAddress
                t.T_seq = None # XXX! unimplemented
                t.T_time = expireTime
                if len(clockInfo)>1: t.event = int(clockInfo[1])
                else: t.event = None
                nodeInfo.topologySet.add(t)
        
        elif name == "[table-two-hop]":

            if len(data)<=3: continue
            for twoHopInfo in (" ".join(data[3:])).split(";"):
                twoHopInfo = twoHopInfo.split(" ")
                clockInfo = twoHopInfo[1].split("\\")
                unused, expireTime = clockInfo[0].split("/")
                expireTime = float(expireTime)
                t = Tuple() #NeighborSensing.TwoHopNeighborTuple()
                (t.N_neighbor_main_addr,
                 t.N_2hop_addr ) = twoHopInfo[0].split("->")
                t.N_time = expireTime
                t.neighborTuple = None # XXX! fix this
                if len(clockInfo)>1: t.event = int(clockInfo[1])
                else: t.event = None                
                nodeInfo.twoHopNeighborSet.add(t)
            
        elif name == "[table-mpr-selector]":

            if len(data)<=3: continue
            for mprInfo in (" ".join(data[3:])).split(";"):
                mprInfo = mprInfo.split(" ")
                clockInfo = mprInfo[1].split("\\")                
                unused,expireTime = clockInfo[0].split("/")
                expireTime = float(expireTime)
                t = Tuple() #TopologyDiscovery.MPRSelectorTuple()
                t.MS_addr = mprInfo[0]
                t.MS_time = expireTime
                if len(clockInfo)>1: t.event = int(clockInfo[1])
                else: t.event = None                
                nodeInfo.mprSelectorSet.add(t)
            
	elif name == "[table-link]": pass
		
        else: raise "IMPOSSIBLE", name

    IMPOSSIBLE

#---------------------------------------------------------------------------

def parseAndCheck(fileName):
    """XXX: old and unused code"""
    f = open(fileName)
    checker = Checker()
    fIter = iter(f.xreadlines())
    for line in fIter:
        line = line.strip()
        data = line.split(" ")
        clock = float(data[0])
        name = data[1]
        if name == "[begin]":
            
            nodeName = data[2]
            infoName = data[3]
            if infoName == "check":
                checkInfo = eval(" ".join(data[4:]))
                print "Checking node '%s'" % nodeName
                errorList = checker.checkNode(nodeName, checkInfo)
            elif infoName == "snapshot":
                nodeInfo = parseState(fIter, nodeName)
                checker.setNodeInfo(nodeName, nodeInfo)
                #print eval(" ".join(data[4:]))
            elif infoName == "node":
                ifaceList = data[4].split(" ")
                checker.setNodeIfaceList(nodeName, ifaceList)
            else: raise "Impossible", data
                
        elif name == "[link]":
            
            event = data[2]
            if event == "-": checker.removeLink(data[3], data[4])
            elif event == "+": checker.addLink(data[3], data[4])
            else: raise Impossible, line
            
        else: pass
        #XXX print line

#---------------------------------------------------------------------------
#
# nodeInfo:
#     .neighborSet
#     .linkSet
#     .twoHopNeighborSet
#     .mprList
#
#---------------------------------------------------------------------------

import re
rName = re.compile("N([0-9]+)I([0-9]+)")

def canonize(name):
    mName = rName.match(name)
    if mName != None and int(mName.group(1)) < 26:
        return chr(ord('A')+int(mName.group(1))) + mName.group(2)
    else: return name

class NodeConfig:
    def __init__(self):
        self.misc = []
        self.config = {}
    def __getitem__(self, key):
        if key == "misc": return getattr(self, "misc")
        else: return getattr(self,"config")[key]

def parseConfig(data):
    result = NodeConfig()
    for info in data.split(";"):
        info = info.strip()
        infoList = info.split(" ")
        if len(infoList) == 2:
            result.config[infoList[0]] = infoList[1]
    return result

def parseCheckPoint(checker, f, g, forceCheck):
    graphStr = f.readline().strip()
    shouldCheck = True
    if graphStr == "output":
        shouldCheck = False
        graphStr = f.readline().strip()
    elif graphStr == "check":
        graphStr = f.readline().strip()
    assert graphStr.startswith("[graph]")
    # Parse graph string
    if graphStr.find(" ")>0:
        graphStr = graphStr[graphStr.find(" ")+1:]
        for linkStr in graphStr.split(" "):
            src,dst = linkStr.split("->")
            src = canonize(src)
            dst = canonize(dst)
            checker.addLink(src, dst)
    else: pass # empty graph

    nodeNameList = []
    while True:
        line = f.readline().strip()
        #if line == "": break
        if line == "[end-check-point]": break
        
        # Parse node and check it
        assert line.startswith("[node]")
        nodeName = line.split(" ")[1]
        pos = line.find(" ",line.find(" ")+1)
        if pos>0:
            nodeConfig = parseConfig(line[pos+1:])
        else: nodeConfig = Node

        # (parse iface list)
        line = f.readline().strip()
        assert line.startswith("[node-iface]")
        checker.setNodeIfaceList(nodeName, line.split(" ")[1:])

        # (parse state)
        nodeInfo = parseState(f, nodeName)
        nodeInfo.config = nodeConfig
        lastClock = nodeInfo.clock
        checker.setNodeInfo(nodeName, nodeInfo)
        nodeNameList.append( nodeName )

    errorCount = 0
    if shouldCheck or forceCheck:
        shouldCheck = True
        hasWrittenCheckPointHeader = False
        checker.prepareCheck()
        for nodeName in nodeNameList:
            errorList = checker.checkNode(nodeName, "node %s" % nodeName)
            errorCount += len(errorList)
            if len(errorList)>0:
                if not hasWrittenCheckPointHeader:
                    hasWrittenCheckPointHeader = True
                    g.write("-"*20+" Errors in checkpoint at: %s\n" %lastClock)
                g.write("-"*5+" %s errors in node: %s\n" %
                        (len(errorList), nodeName))
                for errorInfo in errorList:
                    g.write("%s: %s\n" % (errorInfo[0], errorInfo[1:]))
    return errorCount, shouldCheck
    

def parseAndCheck(fileName, outputFileName, forceCheck):
    errorCount = 0
    checkCount = 0
    f = open(fileName)
    g = open(outputFileName, "w")
    while True:
        line = f.readline().strip()
        if line == "": break
        if line == "[begin-check-point]":
            checker = Checker()
            thisErrorCount,wasChecked  = parseCheckPoint(checker, f, g,
                                                         forceCheck)
            errorCount += thisErrorCount
            checkCount += {False:0, True:1}[wasChecked]
        else:
            raise "File parsing error:", line
    g.write("TotalErrors: %s\n" % errorCount)        
    f.close()
    g.close()
    return errorCount, checkCount

#---------------------------------------------------------------------------

if __name__ == "__main__":
    #dirName = "Result-checkLine4"
    fileName = sys.argv[1]
    outputFileName = sys.argv[2]
    errorCount, checkCount = parseAndCheck(fileName, outputFileName)
    if errorCount > 0:
        #print "Checks found %d errors" % errorCount
        sys.exit(1)
    else: sys.exit(0)

#---------------------------------------------------------------------------
