//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _LOG_H
#define _LOG_H

//---------------------------------------------------------------------------

#include <sstream>

#include "general.h"
#include "protocol_config.h"
#include "gen_protocol_config.h"

//---------------------------------------------------------------------------

/// Fatal error
#define Fatal(x) \
   BeginMacro \
       std::ostringstream out; \
       out << "FATAL(function=" << __func__ << ", " \
           << __FILE__ <<":" << __LINE__  << "):"; \
       out <<  x; \
       out << std::endl; \
       Dg(lTrue, out.str()); \
       std::cerr << out.str(); \
       abort(); \
       exit(EXIT_FAILURE); \
   EndMacro 

#if 1 // XXX! for now
/// Warning
#define Warn(x) \
   BeginMacro \
       std::cerr << "WARNING(function=" << __func__ << ", " \
                 << __FILE__ <<":" << __LINE__  << "):"; \
       std::cerr << x; \
       std::cerr << std::endl; \
   EndMacro 
#else
#define Warn(x) BeginMacro EndMacro
#endif


/// Notice
#define Notice(x) \
   BeginMacro \
       std::cerr << "NOTICE(function=" << __func__ << "," \
                 << __FILE__ <<":" << __LINE__  << "):"; \
       cerr << x; \
       exit(EXIT_FAILURE); \
   EndMacro 

//---------------------------------------------------------------------------

class Log : public GeneratedLog
{
public:
#if 0
  // Now inherited
  bool lWarning;

  bool lEvent;
  bool lEventStrategy;
  bool lPacket;
  bool lPacketContent;
  bool lState;
  bool lPacketProcessing;
  bool lExpiration;
  bool lConfig;
  bool lTrue;


  Log() : lWarning(false), lEvent(true), lEventStrategy(true), 
	  lPacket(true), lPacketContent(true),
	  lState(true),  lPacketProcessing(true), lExpiration(true),
	  lConfig(true), lTrue(true), out(NULL) {}
#endif

  bool lTrue;

  Log() : lTrue(true), out(NULL)
  { }

  std::ostream* out;
};

#if !defined(NOLOG)

#define D(l, cond, output) \
   BeginMacro \
     if ((l).cond && (l).out !=NULL) { \
        (*((l).out)) << output; \
     } \
   EndMacro

#define Dcond(log, cond, something) \
   BeginMacro \
     if ((log).cond && (log).out !=NULL) { \
        something \
     } \
   EndMacro

#else /* defined(NOLOG) */

#define D(l, cond, output) BeginMacro EndMacro
#define Dcond(log, cond, output) BeginMacro EndMacro

#endif /* defined(NOLOG) */

#define Dg(cond, output) \
    BeginMacro \
      if ((globalLog)!=NULL) \
        D(*globalLog, cond, output); \
     EndMacro

#define Dgcond(cond, output) \
    BeginMacro \
      if ((globalLog)!=NULL) \
        Dcond(*globalLog, cond, output); \
    EndMacro

extern Log* globalLog;

//---------------------------------------------------------------------------

#endif /* _LOG_H */
