//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             , projet Hipercom, INRIA Rocquencourt
//  Copyright 2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

//XXX: should be removed

#ifdef WITH_LINUX
#ifndef _NETWORK_LINUX_H
#define _NETWORK_LINUX_H

//---------------------------------------------------------------------------

/// An interface used for OLSR.
/// It performs whatever system calls are necessary to receive and send
/// packets
class LinuxIface
{
public:
  IfaceInfo info;

  /// Open the send/receive socket(s) and register oneself in the proper
  /// IOScheduler.
  void openSocket();

  /// Send a packet to an interface (packet is owned).
  void sendPacket(MemoryBlock* packet);


  /// Return the maximum packet that the interface can send without IP
  /// fragmentation
  int getMTU();

protected:
  /// The higher level interface associated to this system interface
  /// used when calling 
  OLSRIface* associatedIface;

  IPacketReceiver* receiver;
};

//---------------------------------------------------------------------------

/// Limited network configurator
class LinuxNetworkConfigurator
{
public:
  /// Add one route in the kernel
  void addRoute(LinuxIface* iface, Address destIpAddress,
		Address gatewayAddress, Address netMaskAddress, 
		int metric);

  /// Remove one route from the kernel
  void removeRoute(LinuxIface* iface, Address destIpAddress,
		   Address gatewayAddress, Address netMaskAddress, 
		   int metric);
};

//---------------------------------------------------------------------------

SystemIface* findIfaceByName(char* name);

//---------------------------------------------------------------------------

#endif // _NETWORK_LINUX_H
#endif // WITH_LINUX
