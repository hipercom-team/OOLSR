//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NETWORK_PLUGIN_H
#define _NETWORK_PLUGIN_H

//---------------------------------------------------------------------------

#include "scheduler_generic.h"
#include "network_generic.h"

#include "general_plugin.h"

//---------------------------------------------------------------------------

/// An interface used for OLSR.
/// It performs whatever system calls are necessary to receive and send
/// packets
class PluginIface : public ISystemIface
{
public:
  PluginIface(IScheduler* aScheduler, PPA_PlugeeNode aPlugeeNode,
	      IPacketReceiver* aReceiver, Address aAddress, int aMtu,
	      IfaceConfig* aIfaceConfig)
    : address(aAddress), plugeeNode(aPlugeeNode)
  { scheduler = aScheduler; receiver = aReceiver;
  mtu = aMtu; associatedIface = NULL; ifaceConfig = aIfaceConfig; }

  virtual void openSocket(IPacketReceiver* packetReceiver)
  { /* nothing to do */ }

  /// Send a packet to an interface ([mmr] the packet must be freed afterwise).
  virtual void sendPacket(MemoryBlock* packet);

  /// Return the maximum packet that the interface can send without IP
  /// fragmentation
  virtual int getMTU() { return mtu; }

#ifdef LINK_MONITORING
  virtual int getSignalLevel(Address txAddress)
  { return 0; }
#endif

  /// Receive a packet (packet is owned).
  void receivePacket(MemoryBlock* packet, Address sendIfaceAddress);


  virtual Address getAddress() 
  { return address; }


  void addDestination(PluginIface* destinationIface)
  { destinationIfaceList.push_back(destinationIface); }

protected:
  /// The address of this interface
  Address address;

  /// The higher level interface associated to this system interface
  /// used when calling 
  OLSRIface* associatedIface;

  /// A scheduler
  IScheduler* scheduler;

  /// The list of ifaces this interface sends to
  std::vector<PluginIface*> destinationIfaceList;

  /// The object which 
  IPacketReceiver* receiver;

  // The MTU of the interface
  int mtu;

  // The plugee node
  PPA_PlugeeNode plugeeNode;
};

//---------------------------------------------------------------------------

/// Limited network configurator
class PluginNetworkConfigurator : public INetworkConfigurator
{
public:

  PluginNetworkConfigurator(PPA_PlugeeNode aNode, PPA_PlugeeApi* aPlugeeApi)
    : plugeeNode(aNode), plugeeApi(aPlugeeApi) { }

  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric);
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric);
protected:
  PPA_PlugeeNode plugeeNode;
  PPA_PlugeeApi* plugeeApi;
};

//---------------------------------------------------------------------------

#endif // _NETWORK_PLUGIN_H
