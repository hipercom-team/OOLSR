//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//               Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: node_link_monitoring.h,v 1.4 2004/07/30 15:12:24 plakoo Exp $
//---------------------------------------------------------------------------
// The classes and structures used in MPR computation
//---------------------------------------------------------------------------

#ifndef _NODE_LINK_MONITORING_H
#define _NODE_LINK_MONITORING_H

#include "tuple.h"

//---------------------------------------------------------------------------

/**
 * \class HeardIfaceTuple
 * \brief This class implements a link hysteresis algorithm and use 
 *        a signal/noise information if some measure of the signal/noise
 *        level on a received message is available, to describe the quality 
 *	  of the link.
 *        The pending attribut is updated according to the last received 
 *        packet's information.
 *        
 * \author Adokoe
 */

class Node;

class HeardIfaceTuple : public ITuple
{
public:
  struct MonitoringInfo {
    double linkQuality;
    bool   linkPending;
    Time   lostTime;
    bool   stateChanged;

    MonitoringInfo() 
    {
      linkQuality = 0;
      linkPending = true;
      lostTime = 0;
      stateChanged = false;
    }
  };

  Address        H_remonte_iface_addr;
  Address        H_local_iface_addr;
  int            H_last_packetSequenceNumber;

  HeardIfaceTuple(Node* aNode, Address txAddress, Address rxAddress,
		  int sequenceNumber = 0) :
    node(aNode), H_remonte_iface_addr(txAddress), 
    H_local_iface_addr(rxAddress), H_last_packetSequenceNumber(sequenceNumber) 
    { }

  /**
   * This method implememts two different strategies to enhance the robustness
   * of the link sensing mechanism : 
   * 1) The link hysteresis strategy detects the loss of OLSR 
   *    packet by tracking the missing Packet Sequence Numbers.
   *    A missed packet is detected when the next packet is received.
   *    It works out the link quality and updates the class attribut
   *    H_hysteresisMonitoringInfo.
   * 2) A signal/noise strategy is used if some measure of the signal/noise 
   *    level on a received message is available. This modifies the attributs
   *    H_signalMonitoringInfo.
   * If the pending states change, update the corresponding linkTuple 
   * in linkSet.
   * The attribut H_last_packetSequenceNumber is set to the new value of 
   * the packet sequence number if the new value is greater than the previous 
   * one.
   */
  void  setLinkQuality(int currentPacketSequenceNumber);

  /**
   * Return True if the link is not yet considered established.
   */
  bool getLinkPending();

  Time getLostTime();
  
  // HeardIfaceTuple never expire: they are removed when the corresponding 
  // LinkTuple in LinkSet expire.
  virtual Time getExpireTime() { return TimeNever; }

   /**
    * Update the corresponding linkTuple of this tuple in linkSet. 
    */  
  void updateAssociatedLinkTuple();

  virtual void update() { /* nothing to do */ }

protected:
  Node* node;
  MonitoringInfo H_hysteresisMonitoringInfo;
  MonitoringInfo H_signalMonitoringInfo;

  void setLinkQualityByHysteresis(int currentPacketSequenceNumber);
  void setLinkQualityBySignal();
};

//-----------------------------------------------------------------------------

class HeardIfaceSet : public BasicTupleSet<HeardIfaceTuple>
{
public:

  HeardIfaceTuple* findThisLink(Address txAddress, Address rxAddress)
    { 
      Search(HeardIfaceTuple, (current->H_remonte_iface_addr == txAddress &&
			       current->H_local_iface_addr == rxAddress) );
    }

protected:
  virtual void notifyRemoval(HeardIfaceTuple* tuple)
  { /* nothing to do */ }
  virtual void notifyAddition(HeardIfaceTuple* tuple)
  { /* nothing to do */ }
  virtual void write(std::ostream& out)   { /* Todo */}
};

#endif // _NODE_LINK_MONITORING_H
