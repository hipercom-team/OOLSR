//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// <GENERATED>
// Template: <TEMPLATE>
// Date: <DATE>
// User: <USER>
// Command: <COMMAND>
//---------------------------------------------------------------------------
// <NOMOD>
//---------------------------------------------------------------------------

#ifndef _GEN_PROTOCOL_CONFIG_H
#define _GEN_PROTOCOL_CONFIG_H

//---------------------------------------------------------------------------

using std::string;

#include <map>
#include <string>
#include <vector>
#include <sstream>
#include <list>

//#include "address.h"
#include "general.h"

//---------------------------------------------------------------------------

class ParseError
{
public: 
  ParseError(string aError) : error(aError) {}
  string error;
};

#define ThrowParseError(x) \
    BeginMacro \
      std::ostringstream message; \
      message << x; \
      throw (ParseError(message.str())); \
    EndMacro

static inline bool parseBool(string data)
{ return atoi(data.c_str())>0; }

static inline string parseString(string data)
{ return data; }

static inline int parseInt(string data)
{ 
  char* info=NULL;
  int result = strtol(data.c_str(), &info, 0);
  if (*info != '\0')
    ThrowParseError("Cannot parse integer: " << data);
  else return result;
}
//{ return atoi(data.c_str()); }

static inline double parseFloat(string data)
{ return atof(data.c_str()); /* XXX: error handling */ }

extern std::vector<string> stringSplit(string& aLine, string& charSet);

static inline std::list< std::pair<string,string> > parseHNAList(string data)
{ 
  std::list< std::pair<string,string> > result;
  string dashSeparator = "/";
  string semiColonSeparator = ";";

  std::vector<string> hnaStrList = stringSplit(data, semiColonSeparator);
  for (std::vector<string>::iterator it = hnaStrList.begin();
       it != hnaStrList.end();it++) {
    std::vector<string> oneHNA = stringSplit((*it), dashSeparator);
    assert (oneHNA.size() == 2);
    result.push_back( std::pair<string,string> (oneHNA[0], oneHNA[1]) );
  }
  return result;
}

static inline std::ostream& operator << 
  (std::ostream& out, std::list< std::pair< string, string> > data)
{
  
}
					 

//--------------------------------------------------

class GeneratedLog
{
public:
<GEN_LOG_FIELD>

  GeneratedLog() { setDefaultValue(); }

  void setDefaultValue() {
<GEN_LOG_DEFAULT>
  }

  void setAllDefaultValue(bool value) {
<GEN_LOG_ALL_DEFAULT>
  }

  void write(std::ostream& out) const
  {
    out <GEN_LOG_OUTPUT>;
  }
};

//--------------------------------------------------

class GeneratedIfaceConfig
{
public:
  GeneratedIfaceConfig() { setDefaultValue(); }

<GEN_IFACE_CONF_FIELD>

  void setDefaultValue() {
<GEN_IFACE_DEFAULT>
  }

  string parseData(std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    <GEN_IFACE_CONF_PARSE_CODE> else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(std::ostream& out) const
  {
    out <GEN_IFACE_OUTPUT>;
  }
};

class GeneratedProtocolConfig
{
public:
  GeneratedProtocolConfig() { setDefaultValue(); }

<GEN_CONF_FIELD>

  void setDefaultValue() {
<GEN_CONF_DEFAULT>
  }

  string parseData(GeneratedLog& log, std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    <GEN_CONF_PARSE_CODE> else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(std::ostream& out) const
  {
    out <GEN_CONF_OUTPUT>;
  }

  std::map<string,GeneratedIfaceConfig*> ifaceConfig;
};

//---------------------------------------------------------------------------

#endif /*_GEN_PROTOCOL_CONFIG_H*/

