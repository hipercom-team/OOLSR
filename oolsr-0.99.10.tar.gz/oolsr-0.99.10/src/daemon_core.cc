//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// The main OLSR daemon
//---------------------------------------------------------------------------

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include <iostream>
#include <vector>

#include <unistd.h> // for fork (XXX: move to system_linux.cc)
#include <errno.h> // ... ditto

//---------------------------------------------------------------------------

#include "log.h"
#include "scheduler_unix.h"
#include "node.h"
#include "network_generic.h"
#include "network_linux.h"
#include "protocol_config.h"

//---------------------------------------------------------------------------

extern ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig);
extern ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig);

int main(int argc, char** argv)
{
  int i;
  int nbIface = argc-1;

  std::cerr.precision(15);
  std::cout.precision(15);

  if(argc <= 1) {
    std::cerr << "Syntax: " << argv[0] 
	      << " [options...] with options:" << std::endl;
    std::cerr << " -f <config file>: reads a configuration file " << std::endl;
    std::cerr << " -i <iface name>: use interface <iface name> (repeat if there are several ifaces)" << std::endl;
    std::cerr << " --use-ipv4 1 : use IPv4" << std::endl;
    std::cerr << " --use-ipv6 1 : use IPv6" << std::endl;
    std::cerr << " --<parameter name> <parameter value>" << std::endl;
    std::cerr << " --on <iface name> <iface parameter name>"
                 " <iface parameter value>" << std::endl;
    exit(EXIT_FAILURE);
  }

  ConfigParser parser;
  Log* log = new Log;
  ProtocolConfig* protocolConfig = new ProtocolConfig;
  parser.parseArgList(*protocolConfig, *log, argv+1, argc-1);

  if(protocolConfig->ipv4 && protocolConfig->ipv6) 
    protocolConfig->ipv4 = false; // IPv6 take precedence

  if (protocolConfig->onlyParseConfig) {
    std::cout << "# Configuration output:" << std::endl;
    exit(EXIT_SUCCESS);
  }

  //--------------------------------------------------

  ISystemFactory* systemFactory = NULL;

  if (protocolConfig->ipv6) {
    systemFactory = getIPv6SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Fatal("Cannot use IPv6, check that your binary supports it");
  } else if (protocolConfig->ipv4) {
    systemFactory = getIPv4SystemFactory(protocolConfig);
    if (systemFactory == NULL)
      Fatal("Cannot use IPv4, check that your binary supports it");
  } else Fatal("Neither ipv4 nor ipv6 are defined in configuration.");

  Node* node = new Node;
  PacketManager* packetManager = new PacketManager(node);

  std::list<ISystemIface*> systemIfaceList;

  typedef std::map<string,GeneratedIfaceConfig*> IfaceNameToConfig;
  for(IfaceNameToConfig::iterator it = protocolConfig->ifaceConfig.begin();
      it != protocolConfig->ifaceConfig.end(); it++) {
    string ifaceName = (*it).first;
    GeneratedIfaceConfig* ifaceConfig = (*it).second;
    ISystemIface* systemIface = 
      systemFactory->getIfaceByName(ifaceName.c_str(), ifaceConfig);
    if(systemIface == NULL)
      Fatal("Cannot find a usable interface with name '" 
	    << ifaceName.c_str() 
	    << "' (check you have site-local address when using ipv6)\n");
    if (ifaceName != protocolConfig->mainIface)
      systemIfaceList.push_back(systemIface);
    else systemIfaceList.push_front(systemIface);
    systemIface->openSocket(node);
  }
  
  std::vector<ISystemIface*> systemIfaceVector;
  for (std::list<ISystemIface*>::iterator it = systemIfaceList.begin();
       it != systemIfaceList.end(); it++)
    systemIfaceVector.push_back(*it);

  if(protocolConfig->ifaceConfig.begin()
     == protocolConfig->ifaceConfig.end()) {
    Fatal("No interfaces have been given for running OOLSR");
  }

#ifndef NOLOG
  if(!protocolConfig->noLog) {
    if (globalLog == NULL) { // XXX: should be done elsewhere
      // XXX: not implemented
      //globalLog = new Log;
      //globalLog->out = createLogFile(protocolConfig->logFileName,
      //				     "global");
    }
    Address address = //Address(systemFactory->getAddressFactory(), 
      systemIfaceVector[0]->getAddress();
    log->out = createLogFile(protocolConfig->logFileName,
			     toText(address));
  }
#endif

  if(!protocolConfig->noFork) {
    // Daemonize (from olsrdv7)
    // XXX: not windows compatible
    pid_t childPid = fork();
    if (childPid < 0)  
      Fatal("Failure in fork(): " << strerror(errno));
    else if (childPid == 0) // Parent
      exit(EXIT_SUCCESS);
    close(0);
    close(1);
    close(2);
    setsid();
  }

  // Configure the node
  node->configure(systemFactory->getScheduler(),
		  systemFactory->getAddressFactory(),
		  packetManager, 
		  systemFactory->getNetworkConfigurator(),
		  protocolConfig,
		  systemIfaceVector,
		  log); // XXX: should be configured with protocolConfig
  
  node->start();
  systemFactory->visitNode(node);
  systemFactory->getScheduler()->runUntilNoEvent();

  exit(EXIT_SUCCESS);
}

//---------------------------------------------------------------------------
