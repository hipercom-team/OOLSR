//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <iomanip>
#include <iostream>
#include <fstream>

#include <sys/stat.h>
#include <sys/types.h>

#include "general.h"
#include "log.h"

//---------------------------------------------------------------------------

const double C = 1.0/16.0; // @@3502

void debugMe()
{
  // 
  std::cout << "debug point" << std::endl;
}

int toMantissaExponentByte(Time value)
{
  assert( C <= value && value <= fromMantissaExponentByte(0xff) );
  int b=0;
  while( (value/C) >= (1<<(b+1)) ) // @@3595
    b++;

  double aFloat = 16*(value/(C*(1<<b))-1); // @@3597
  int a = (int)aFloat; // @@3598
  if(a<aFloat) a++;

  if(a==16) { // @@3600
    b++;
    a=0;
  }

  assert(0<=a && a<=15 && 0<=b && b<=15); // @@3602
  return a*16+b; // @@3603
}


Time fromMantissaExponentByte(int valueAsByte)
{
  int a = (valueAsByte>>4); // @@3571-3572
  int b = (valueAsByte&0xf); // @@3572-3573
  return C*((16+a)<<b)/16.0; // @@3569
}

//---------------------------------------------------------------------------

//MemoryBlock::MemoryBlock(void* initialData, int initialSize, bool aOwned)
//{ Fatal("XXX: not implemented"); }


MemoryBlock::MemoryBlock(int initialSize)
{
  data = new octet[initialSize];
  size = initialSize;
}

MemoryBlock* MemoryBlock::clone()
{
  MemoryBlock* result = new MemoryBlock(size);
  memcpy(result->data, data, size);
  return result;
}

MemoryBlock::~MemoryBlock()
{ delete [] data; data = NULL; }

std::ostream& operator << (std::ostream& out, MemoryBlock& block)
{
  if(block.size != 0) {
    out << std::hex;
    for(int i=0;i<block.size;i++)
      out << (i>0&&(i%4)==0?"_":"") << std::setw(2) << std::setfill('0') 
	  << (unsigned int)block.data[i];
    out << std::dec;
  } else out << "<empty>";
}

//---------------------------------------------------------------------------

string strReplace(string data, string before, string after)
{
  string result = data;
  string::size_type previousPos = 0;
  for(;;) {
    string::size_type pos = result.find(before, previousPos);
    if (pos == string::npos) 
      return result;
    result.replace(pos, before.length(), after);
    previousPos = pos + before.length();
    if (previousPos >= result.length())
      return result;
  }
}

string format3UInt(void* data)
{
  std::ostringstream result;
  unsigned int* info = (unsigned int*)data;
  result << info[0] << "," << info[1] << "," << info[2];
  return result.str();
}

//---------------------------------------------------------------------------

Log* globalLog = NULL;

std::ostream* createLogFile(string fileTemplate, string infix) 
{
  if (fileTemplate == "-")
    return new std::ofstream("/proc/self/fd/1");
  if (fileTemplate == "")
    return new std::ofstream("/dev/null");
  string::size_type pos = fileTemplate.find('/');
  if (pos != string::npos && pos != 0) {
    string dirName = fileTemplate.substr(0, pos);
    (void)mkdir(dirName.c_str(), 0700); // XXX! not Windows compatible?
  }
  string name = strReplace(fileTemplate, "%s", infix);
  if (fileTemplate == name && infix == "global") {
    name += "." + infix;
  }
  return new std::ofstream(name.c_str()); // XXX! when close? 

#if 0
  char name[1024]; // XXX! hack
  (void)mkdir("./tmp", 0700); // XXX! not Windows compatible?
  strcpy(name, "./tmp/olsr.log");

  for(int i=0;i<simulatorApi->addressSize;i++) {
    strcat(name, ".");
    char substr[1024];
    sprintf(substr, "%d", (((unsigned char*)address)[i]));
    strcat(name, substr);
  }
  return new std::ofstream(name); // XXX! when close?
#endif
}

//---------------------------------------------------------------------------
