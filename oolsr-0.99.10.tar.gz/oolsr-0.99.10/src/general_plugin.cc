//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Wrapper around OOLSR classes to match the plugin interface
//---------------------------------------------------------------------------

using namespace std;

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/stat.h>
#include <sys/types.h>

//#include <stl.h>
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>

//--------------------------------------------------

#include <protocol-plugin-api.h>

//--------------------------------------------------

#include "general.h"
#include "log.h"
#include "scheduler_generic.h"
#include "scheduler_plugin.h"
#include "node.h"

#include "general_plugin.h"
#include "network_plugin.h"
#include "packet.h"

//---------------------------------------------------------------------------

PPA_PluginApi pluginProtocolApi;
PPA_PlugeeApi* simulatorApi = NULL;
int pluginAddressSize = -1;

class PluginScheduler;
PluginScheduler* pluginScheduler = NULL;


//---------------------------------------------------------------------------

void pluginSchedulerCallBack(void* data1, void* data2, void* data3)
{
  assert(data3 == NULL);
  ((IEvent*)data1)->handleEvent(data2);
  delete (IEvent*)data1;
}

//---------------------------------------------------------------------------

static PPA_Address simBroadcastAddress = NULL; // [Design Pattern] singleton
void* getBroadcastAddress() 
{
  if (simBroadcastAddress == NULL) {
    simBroadcastAddress = new octet[simulatorApi->addressSize];
    simulatorApi->getBroadcastAddressFunction(simBroadcastAddress);
  }
  return simBroadcastAddress;
}

void PluginIface::sendPacket(MemoryBlock* packet)
{
  PPA_Packet ppaPacket;
  ppaPacket.size = packet->size;
  ppaPacket.data = malloc(packet->size); // (allocated by malloc, not new)
  memcpy(ppaPacket.data, packet->data, packet->size);
  simulatorApi->sendPacketFunction(plugeeNode, 
				   address.getRawAddress(),
				   getBroadcastAddress(), ppaPacket);
  delete packet;
}

//---------------------------------------------------------------------------

void* createNode(PPA_PlugeeNode simNode,
		 int nbIface,
		 /* borrowed: */ void** ifaceAddressArray,
		 int* mtuArray,
		 void* configData, int configSize)
{
  // XXX: check how to free all this.
  Node* node = new Node;
  PacketManager* packetManager = new PacketManager(node);
  ProtocolConfig* protocolConfig = new ProtocolConfig;
  Log* log = new Log;

  ConfigParser configParser;
  string configString = (char*)configData; // XXX: configSize
  configParser.parse(*protocolConfig, *log, configString);

  //SystemConfig* systemConfig = new SystemConfig;
  INetworkConfigurator* netConfig 
    = new PluginNetworkConfigurator(simNode, simulatorApi);
  std::vector<ISystemIface*> ifaceList;
  AddressFactory* addressFactory = 
    new AddressFactory(simulatorApi->addressSize);
  addressFactory->setAddressType("plugin-address");

#ifndef NOLOG
  if(!protocolConfig->noLog) {
    if (globalLog == NULL) { // XXX: should be done elsewhere
      globalLog = new Log;
      globalLog->out = createLogFile(protocolConfig->logFileName,
				     "global");
    }
    Address address = Address(addressFactory, ifaceAddressArray[0]);
    log->out = createLogFile(protocolConfig->logFileName,
			     toText(address));
  }
#endif

  for (int j=0;j<nbIface;j++) {
    // Create the j-th interface
    Address address = Address(addressFactory, ifaceAddressArray[j]);
    string ifaceName = "I0";
    ifaceName[1] = '0' + j; // ifaceName is I0, I1, I2, ...

    if (protocolConfig->ifaceConfig.count(ifaceName) == 0)
      protocolConfig->ifaceConfig[ifaceName] = new IfaceConfig;

    IfaceConfig* ifaceConfig = protocolConfig->ifaceConfig[ifaceName];
    ISystemIface* iface = new PluginIface
      (pluginScheduler,
       simNode, dynamic_cast<IPacketReceiver*>(node), 
       address, mtuArray[j], ifaceConfig);
    ifaceList.push_back(iface);
  }
  // Configure the node
  node->configure(dynamic_cast<IScheduler*>(pluginScheduler),
		  addressFactory, packetManager, 
		  netConfig,
		  protocolConfig,
		  ifaceList, log);

#ifdef WITH_MULTICAST_ENCAPSULATION
  if (protocolConfig->multicastType >= 0) {
    // XXX: should check it is different from HELLO etc...
    node->addMessageHandler(protocolConfig->multicastType,
			    new EMMessageHandler(node, simNode));
  }
#endif /* WITH_MULTICAST_ENCAPSULATION */

  return (void*)node;
}

void nodeStart(PPA_PluginNode protocolNode)
{ ((Node*)protocolNode)->start(); }

void nodeReceive(PPA_PluginNode protocolNode,
		 PPA_Address ppaSenderAddress,
		 PPA_Address ppaReceiverAddress,
		 PPA_Packet ppaPacket /* owned*/)
{
  Node* node = (Node*)protocolNode;
  MemoryBlock* packet = new MemoryBlock((octet*)ppaPacket.data, 
					ppaPacket.size, true);
  Address senderAddress(node->getAddressFactory(), ppaSenderAddress);
  Address receiverAddress(node->getAddressFactory(), ppaReceiverAddress);
  OLSRIface* iface = node->getIfaceByAddress(receiverAddress);
  assert( iface != NULL );
  node->evReceivePacket(packet, senderAddress, iface);
  free(ppaPacket.data); // (erased with free, not delete)
}


//---------------------------------------------------------------------------

void nodeWrite(PPA_PluginNode pluginNode, char** result)
{
  Node* node = (Node*)pluginNode;
  std::ostringstream* out = new std::ostringstream;
  (*out) << "[node] " << node->getMainAddress() << " ";
  (*out) << (*node->getProtocolConfig()) << std::endl;
  node->writeIfaceList(*out);
  node->logState(*out);
  out->flush();
  *result = strdup(out->str().c_str());
  delete out;
}

void nodeOutput(PPA_PluginNode pluginNode, char* fileName)
{
  Node* node = (Node*)pluginNode;
  std::ostream* out;
  if (!strcmp(fileName, "stdout") || !strcmp(fileName, "-")) {
    out = &std::cout;
  } else {
    out = new std::ofstream(fileName,
#ifdef NEW			   
			    std::ios_base::app | std::ios_base::out
#else
			    std::ios::app | std::ios::out
#endif
			    );
  }
  (*out) << "[node] " << node->getMainAddress() << " ";
  (*out) << (*node->getProtocolConfig()) << std::endl;
  node->writeIfaceList(*out);
  node->logState(*out);
  out->flush();
  if (out != &(std::cout)) {
    delete out;
  }
}

//---------------------------------------------------------------------------

extern "C" int protocolPluginApiInit
(int major, int minor, 
 PPA_PlugeeApi* aSimulatorApi, 
 PPA_PluginApi** resultPluginApi)
{
  if(major != PPA_VERSION_MAJOR) {
    fprintf(stderr, "Plugin failure: implementing API v%d.%d while API %d.%d "
	    "is used", PPA_VERSION_MAJOR, PPA_VERSION_MINOR,
	    major, minor);
    return PPA_FAILURE;
  }

  simulatorApi = aSimulatorApi;
  //pluginProtocolApi._private = XXX;
  pluginProtocolApi.createNodeFunction = createNode;
  pluginProtocolApi.nodeStartFunction = nodeStart;
  pluginProtocolApi.nodeReceiveFunction = nodeReceive;
  pluginProtocolApi.nodeWriteFunction = nodeWrite;
  pluginProtocolApi.nodeOutputFunction = nodeOutput;
#ifdef WITH_MULTICAST_ENCAPSULATION
  pluginProtocolApi.nodeMulticastEncapsulateFunction 
  = nodeMulticastEncapsulate;
#else
  pluginProtocolApi.nodeMulticastEncapsulateFunction = NULL;
#endif
  *resultPluginApi = &pluginProtocolApi;

  pluginAddressSize = simulatorApi->addressSize;

  pluginScheduler = new PluginScheduler;

  return PPA_OK;
}

//---------------------------------------------------------------------------
