//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "general.h"
#include "address.h"
#include "protocol_tuple.h"
#include "packet.h"
#include "node.h"
#include "node_link_monitoring.h"

//---------------------------------------------------------------------------

const int SequenceNumberLimit = (1<<16); // 16 bits: XXX draft reference

//---------------------------------------------------------------------------

bool DuplicateTuple::isInIfaceList(Address ifaceAddress) {
  for(std::list<Address>::iterator it = D_iface_list.begin();
      it != D_iface_list.end();it++)
    if (*it == ifaceAddress) return true;
  return false;
}

//---------------------------------------------------------------------------

// XXX! redefined elsewhere
std::ostream& operator << (std::ostream& out, DuplicateTuple& t)
{
  out << t.D_addr << " seq=" << t.D_seq_num << " retrans=" 
      << t.D_retransmitted << " iface=(";
  bool isFirst = true;
  for(std::list<Address>::iterator it = t.D_iface_list.begin();
      it != t.D_iface_list.end(); it++) {
    if (!isFirst) out <<",";
    else isFirst = false;
    out << (*it);
  }
  out << ") " << t.D_time;
}

//---------------------------------------------------------------------------

Message* Message::clone(bool withContent)
{
  Message* result = new Message(messageType, vtime, 
				originatorAddress, 
				timeToLive, hopCount);
  result->messageSequenceNumber = messageSequenceNumber;
  result->sendIfaceAddress = sendIfaceAddress;
  result->recvIfaceAddress = recvIfaceAddress;
  result->origin = origin;
  result->messageSize = messageSize;
  result->minMessageSize = minMessageSize;
  result->maxTime = maxTime;
  if(packedContent != NULL) // XXX!! check --(looks ok)
    result->packedContent = packedContent->clone();
  if(content != NULL && withContent)
    result->content = content->clone(); // XXX!! check --(looks ok)
  return result;
}

//---------------------------------------------------------------------------

void HelloMessageHandler::adjustMessageSize(IMessageContent* message)
{
  HelloMessage* m = dynamic_cast<HelloMessage*>(message);
  m->header->messageSize = internalGetMessageSize(m ,NULL);
  int addressSize = node->getAddressFactory()->getAddressSize();
  m->header->minMessageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + HelloHeaderSize // hello header. And assuming non-empty HELLO:
    + HelloLinkMessageHeaderSize + addressSize; // at least one address
  if(m->header->messageSize < m->header->minMessageSize)
    m->header->minMessageSize = m->header->messageSize; // was an empty HELLO
}


void HelloMessageHandler::processMessage(Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  HelloMessage* helloMessage = dynamic_cast<HelloMessage*>(messageContent);
  D(*node->log, lMessage, node->getRealTime() 
    << " [process-message] " << node->getMainAddress() << " " 
    << (*message) << std::endl);
  node->processHelloMessage(helloMessage);
}

IMessageContent* HelloMessageHandler::parseMessageContent(Message* message)
{
  HelloMessage* result = new HelloMessage;
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  // @@1690-1691
  result->reserved = buffer.popUInt16(); // @@1523
  result->htime = buffer.popUInt8(); // @@1523
  result->willingness = buffer.popUInt8(); // @@1523
  while(buffer.size()>0) {
    int linkCode = buffer.popUInt8(); // @@1525
    int reserved2 = buffer.popUInt8(); // @@1525 - unused
    int size = buffer.popUInt16(); // @@1525
    
    size -= buffer.sizeUInt8()+buffer.sizeUInt8()
      +buffer.sizeUInt16(); // @@1602-1605
    PacketBuffer rawLinkMessage;
    buffer.popSubBuffer(size, rawLinkMessage);
    if (linkCode >= 15) // @@1598,1613
      continue;

    NeighborType neighborType = linkCodeToNeighborType(linkCode);
    LinkType linkType = linkCodeToLinkType(linkCode);
    if ((neighborType != NOT_NEIGH)
	&& (neighborType != SYM_NEIGH)
	&& (neighborType != MPR_NEIGH))
      continue; // @@1668-1671
    if (linkType == SYM_LINK && neighborType == NOT_NEIGH)
      continue; // @@1659-1666

    while(rawLinkMessage.size()>0) { // @@1600-1695
      LinkEntry entry; 
      entry.neighborType = neighborType;
      entry.linkType = linkType;
      entry.address = rawLinkMessage.popAddress(); // @@1607-1609

      result->linkList.push_back(entry);
    }
  }
  delete message->packedContent;
  message->packedContent = NULL;
  message->content = result;
  result->header = message;
  return result;
}


void HelloMessageHandler::packMessageContent
(IMessageContent* message, 
 int maximumMessageSize,
 MemoryBlock*& blockResult,
 IMessageContent*& messageRemainingResult)
{
  HelloMessage* m = dynamic_cast<HelloMessage*>(message);


  PacketBuffer buffer;
  int initialPos = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);

  buffer.pushUInt16(m->reserved); // @@XXX
  buffer.pushUInt8(m->htime); // @@XXX
  buffer.pushUInt8(m->willingness); // @@XXX
  
  std::list<Address> linkAddressList[LinkCodeLimit];

  int addressSize = node->getAddressFactory()->getAddressSize();

  int messageSize = internalGetMessageSize(m, linkAddressList);

  int addressListCount = -1; /*XXX!*/
  bool mustSplitMessage = false;
  for(int i=0;i<LinkCodeLimit;i++) {
    int linkCode = LinkCodeLimit-1 -i; // reverse: important codes first
    if(linkAddressList[linkCode].empty())
      continue;
    int freeSpace = maximumMessageSize - buffer.getSizeFrom(initialPos);
    if(freeSpace >=  HelloLinkMessageHeaderSize + addressSize ) {
      freeSpace -= HelloLinkMessageHeaderSize;
      /*int*/ addressListCount = linkAddressList[linkCode].size();
      if(freeSpace < addressSize * addressListCount) {
	addressListCount = freeSpace / addressSize;
	mustSplitMessage = true;
      }
      buffer.pushUInt8(linkCode); // @@1525
      buffer.pushUInt8(0); // @@XXX
      buffer.pushUInt16( addressListCount*addressSize 
			 +HelloLinkMessageHeaderSize ); 
      std::list<Address>::iterator it = linkAddressList[linkCode].begin();
      for (int j=0; j<addressListCount; j++) {
	assert( it != linkAddressList[linkCode].end() );
	std::list<Address>::iterator next = it;
	next++;

	buffer.packAddress(*it);

	linkAddressList[linkCode].erase(it);
	it = next;
      }
    } else mustSplitMessage = true;
  }

  if(!
     ((mustSplitMessage && messageSize > maximumMessageSize)
      || (!mustSplitMessage && messageSize <= maximumMessageSize))) {
    // XXX! debug stuff to be removed
    extern void debugMe();
    debugMe();
    std::cerr << "Fatal error: " << node->getMainAddress() <<
      " evt=" << node->eventCounter << " ms=" << mustSplitMessage << " "
	      << messageSize << " mms=" << maximumMessageSize << " alc"
	      << addressListCount << " lals" << linkAddressList->size()
	      << std::endl;
  }

  assert( (mustSplitMessage && messageSize > maximumMessageSize)
	  || (!mustSplitMessage && messageSize <= maximumMessageSize));
  if (mustSplitMessage) {
    HelloMessage* newHello = dynamic_cast<HelloMessage*>(message->clone());
    messageRemainingResult = newHello;
    newHello->linkList.clear();
    newHello->header->messageSize = -1; // because no longer valid
    newHello->header->minMessageSize = -1;
    for(int i=0;i<LinkCodeLimit;i++) {
      for(std::list<Address>::iterator it = linkAddressList[i].begin();
	  it != linkAddressList[i].end(); it++) {
	LinkEntry entry;

	entry.linkType = linkCodeToLinkType(i);
	entry.neighborType = linkCodeToNeighborType(i);
	entry.address = (*it);
	newHello->linkList.push_back(entry);
      }
    }
  } else messageRemainingResult = NULL;

  // XXX:! delete message ?

  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  blockResult = buffer.getContent();
}

int HelloMessageHandler::internalGetMessageSize(HelloMessage* m,
					std::list<Address>* resultList)
{
  // First count the different link types
  int linkCodeCount[LinkCodeLimit];
  for(int i=0;i<LinkCodeLimit;i++)
    linkCodeCount[i] =0;
  
  for(std::list<LinkEntry>::iterator it = m->linkList.begin();
      it != m->linkList.end(); it++) {
    int linkCode = linkAndNeighborToCode((*it).linkType, (*it).neighborType);
    linkCodeCount[linkCode] ++;
    if(resultList != NULL) 
      resultList[linkCode].push_back((*it).address);
  }

  int addressSize = node->getAddressFactory()->getAddressSize();

  // Now compute message size
  int messageSize = MessageHeaderWithoutAddressSize
    + addressSize + HelloHeaderSize;
  for(int i=0;i<LinkCodeLimit;i++)
    if(linkCodeCount[i]>0)
      messageSize += HelloLinkMessageHeaderSize 
	+ addressSize * linkCodeCount[i];

  return messageSize;
}

//---------------------------------------------------------------------------

template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>
::adjustMessageSize(IMessageContent* message)
{
  MessageContent* m = dynamic_cast<MessageContent*>(message);
  int addressSize = node->getAddressFactory()->getAddressSize();
  int itemSize = MessageSpecification::getItemSize(addressSize);

  m->header->messageSize =
    MessageHeaderWithoutAddressSize + addressSize // message header
    + MessageSpecification::getContentHeaderSize() // content header
    + itemSize * MessageSpecification::getList(m).size(); // content
  
  m->header->minMessageSize = 
    MessageHeaderWithoutAddressSize + addressSize // message header
    + HelloHeaderSize // hello header. And assuming non-empty TC:
    + HelloLinkMessageHeaderSize + itemSize; // at least one item
  
  if(m->header->messageSize < m->header->minMessageSize)
    m->header->minMessageSize = m->header->messageSize; // was an empty mes.
}

template <class MessageSpecification>
void 
GenericMessageHandler<MessageSpecification>::processMessage(Message* message)
{
  IMessageContent* messageContent = parseMessageContent(message);
  MessageContent* fullMessage = dynamic_cast<MessageContent*>(messageContent);
  D(*node->log, lMessage, node->getRealTime() 
    << " [process-message] " << node->getMainAddress() << " " 
    << (fullMessage) << std::endl);
  MessageSpecification::process(node, fullMessage);
  delete fullMessage; // XXX: check why deleted here and not in HELLOs
  // (answer?: fullMessage->header is a clone of message->result here
  // while message is made to point to helloMessage in HELLOs?)
}

template <class MessageSpecification>
IMessageContent* GenericMessageHandler<MessageSpecification>
::parseMessageContent(Message* message)
{
  MessageContent* result = new MessageContent;
  PacketBuffer buffer(*message->packedContent, node->getAddressFactory());
  MessageSpecification::parseMessageContentHeader(result, buffer);
  while (buffer.size() > 0)
    MessageSpecification::parseMessageItem(result, buffer);
  result->header = message->clone(false);
  return result;
}

template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>::packMessageContent
(IMessageContent* message, 
 int maximumMessageSize,
 MemoryBlock*& blockResult,
 IMessageContent*& messageRemainingResult)
{
  MessageContent* m = dynamic_cast<MessageContent*>(message);
  MessageContent* newTC = NULL;
  int addressSize = node->getAddressFactory()->getAddressSize();
  int itemSize = MessageSpecification::getItemSize(addressSize);

  if(maximumMessageSize < m->header->messageSize) {
    newTC = dynamic_cast<MessageContent*>( m->clone() );
    MessageSpecification::getList(newTC).clear(); // XXX: inefficient
    newTC->header->messageSize = -1; // because no longer valid
    newTC->header->minMessageSize = -1;
  } else newTC = NULL;
  messageRemainingResult = newTC;

  PacketBuffer buffer;
  int initialPosition = buffer.getPosition();
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message->header);
  
  MessageSpecification::packMessageContentHeader(m, buffer);
  
  MessageItemList& itemList = MessageSpecification::getList(m);
  MessageItemList* newItemList = (newTC == NULL) ? NULL
    : &(MessageSpecification::getList(newTC));
  for(typename MessageItemList::iterator it = itemList.begin(); 
      it != itemList.end(); it++)
    if (buffer.getSizeFrom(initialPosition) + itemSize < maximumMessageSize)
      MessageSpecification::packMessageItem(*it, buffer);
    else { assert(newItemList != NULL); newItemList->push_back(*it); }

  assert( (newTC == NULL) || newItemList->size()>0 );

  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  blockResult = buffer.getContent(); //buffer.popBlock(buffer.size());
}

//---------------------------------------------------------------------------

#if 0
void MIDMessageHandler::considerForwardMessage(Message* message, 
					       string& info)
{ node->getPacketManager()->defaultForwardingMessage(message, info); } // @@XXX
#endif

template <class MessageSpecification>
void GenericMessageHandler<MessageSpecification>
::considerForwardMessage(Message* message, string& info)
{ node->getPacketManager()->defaultForwardingMessage(message, info); } // @@XXX

void TCSpecification::process(Node* node, MessageContent* m)
{ node->processTCMessage(m); }

void MIDSpecification::process(Node* node, MessageContent* m)
{ node->processMIDMessage(m); }

void HNASpecification::process(Node* node, MessageContent* m)
{ node->processHNAMessage(m); }

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

PacketManager::PacketManager(Node* aNode) : node(aNode)
{
  for(int i=0;i<MessageTypeLimit;i++)
    messageHandler[i] = NULL;

  messageHandler[HELLO_MESSAGE] = new HelloMessageHandler(node);
  messageHandler[TC_MESSAGE]    = new TCMessageHandler(node);
  messageHandler[MID_MESSAGE]   = new MIDMessageHandler(node);
  messageHandler[HNA_MESSAGE]   = new HNAMessageHandler(node);

  nextMessageSequenceNumber = 0; // XXX: can be random

  queue = new std::list<MessageAndIface>;
}

void PacketManager::addMessageHandler(unsigned int messageType,
				      IMessageHandler* handler)
{
  assert( inrange(0u, messageType, (unsigned int)MessageTypeLimit) );
  messageHandler[messageType] = handler;
}

int PacketManager::getMessageHeaderSize()
{ return MessageHeaderWithoutAddressSize 
    + node->getAddressFactory()->getAddressSize(); }


const int MessageSequenceNumberLimit =(1<<16);

int PacketManager::allocateMessageSequenceNumber()
{
  int result = nextMessageSequenceNumber;
  nextMessageSequenceNumber++;
  if(nextMessageSequenceNumber>= MessageSequenceNumberLimit)
    nextMessageSequenceNumber = 0;
  return result;
}

// Macro to keep detailed informations about the packet/MPR flooding process:
// result in the following possible information (not all at the same time)
// not-sym,sym,already-retransmitted,in-iface-list,from-mpr,retransmit,
// from-other-iface
#define PktD(l, collect, m, output) \
    BeginMacro \
      if ( ( (l).lPacketProcessing || \
             ((l).lMulticast && \
              m->messageType == node->getProtocolConfig()->multicastType) ) \
          && (l).out != NULL) { \
        std::ostringstream out; out << output; \
        collect += out.str(); \
      } \
    EndMacro

#define PktDEnd(l, collect, m, output) \
    BeginMacro \
      if ( ( (l).lPacketProcessing || \
             ((l).lMulticast && \
              m->messageType == node->getProtocolConfig()->multicastType) ) \
          && (l).out != NULL) { \
         (*(l).out) << collect.c_str() << output; \
      } \
    EndMacro


void PacketManager::processPacket(Address sendIfaceAddress,
				  Address recvIfaceAddress,
				  MemoryBlock* rawPacket)
{
  PacketBuffer packet(*rawPacket, node->getAddressFactory());
  delete rawPacket; rawPacket = NULL;
  std::list<Message*> messageList;
  int packetSequenceNumber;

  try { 

    parsePacket(packet, messageList, packetSequenceNumber,
		sendIfaceAddress, recvIfaceAddress); 

    // Link monitoring
#ifdef LINK_MONITORING
    if (node->getProtocolConfig()->useSignalMonitoring ||
	node->getProtocolConfig()->useHysteresisMonitoring)

      processLinkMonitoring(sendIfaceAddress, recvIfaceAddress, 
			    packetSequenceNumber);
#endif

    int messageIndex = -1;
    for(std::list<Message*>::iterator it=messageList.begin();
	it!=messageList.end();it++) {
      Message* m = *it;
      messageIndex++;


      //--- Only for logging purposes:
      string info = "";
#ifndef NOLOG
      if ((node->log->lMulticast) && node->log->out != NULL 
	  && m->messageType == node->getProtocolConfig()->multicastType) {
	std::ostringstream strHeader;
	writeMessage(strHeader, *m, false);
	PktD(*node->log, info, m, node->getRealTime()
	     << " [received-message] " << node->getMainAddress() << " " 
	     << strHeader.str().c_str()
	     << " content=" << format3UInt(m->packedContent->data) << " ");
      } else if (node->log->lPacketProcessing) {
	PktD(*node->log, info, m, node->getRealTime()
	     << " [received-message] "
	     << node->getMainAddress() << " "
	     << *m << " ");
      }
#endif
      //---

      // Processing - step 2 - @@928-932
      if(m->timeToLive <= 0 // @@928-929
	 || m->originatorAddress == node->getMainAddress()) { // @@929-931
	PktDEnd(*node->log, info, m, std::endl);
	delete m;
	continue; // @@931-932
      }

      D(*node->log, lMessage, node->getRealTime() 
	<< " [message] " << node->getMainAddress() << " #" << messageIndex
	<< " "<< (*m) << std::endl);

      // Extra implementation related step
      assert(0<=m->messageType && m->messageType<MessageTypeLimit);
      IMessageHandler* handler = messageHandler[m->messageType];

      PktD(*node->log, info, m,
	   //m->originatorAddress << "#" << m->messageSequenceNumber << " "<<
	   "handler=" << (handler != NULL) << " ");

      // Processing - step 3 - XXX@@
      DuplicateTuple* duplicateTuple = 
	node->duplicateSet.findFirst_Address_MessageSequenceNumber
	(m->originatorAddress, m->messageSequenceNumber); // @@936-940
      if (duplicateTuple == NULL) {
	PktD(*node->log, info, m, " no-duplicate-tuple ");
	if (handler != NULL) {
	  handler->processMessage(m); // step 3.2 - @@945-947
	} else { /* do nothing */ } // a message we don't know how to process
      } else { 
	// do nothing - step 3.1 - @@942-943
	PktD(*node->log, info, m, " duplicate=[" << (*duplicateTuple) << "] ");
      } 

      // Processing - step 4 - XXX@@

      if (duplicateTuple != NULL  // step 4.1 - @@961-969
	  && duplicateTuple->isInIfaceList(m->recvIfaceAddress)) {
	/* do nothing */ // @@971-972
	PktD(*node->log, info, m, " already-processed ");
      } else {
	if (handler != NULL) // step 4.2.1 - @@976-980
	  handler->considerForwardMessage(m, info);
	else defaultForwardingMessage(m, info);// step 4.2.2 - @@
      }
      PktDEnd(*node->log, info, m, std::endl);
      delete m;
    }


  } catch(PacketFormatError& error) { 

    //Fatal("XXX: packet format error!");
    // this need to be covered
    for(std::list<Message*>::iterator it = messageList.begin();
	it!=messageList.end();it++)
      delete (*it);
    return; /* XXX: output warning */ 

  }  
}

void PacketManager::defaultForwardingMessage(Message* m, string& info)
{
  // Default forwarding algorithm - step 1 - @@992-995
  if (!node->isSymmetricNeighbor(node->ifaceToMainAddress
				 (m->sendIfaceAddress))) {
    PktD(*node->log, info, m, "not-sym");
    return; // @@992-995
  }
  PktD(*node->log, info, m, "sym");

  // Default forwarding algorithm - step 2 - @@997-1016
  DuplicateTuple* duplicateTuple = 
    node->duplicateSet.findFirst_Address_MessageSequenceNumber
    (m->originatorAddress, m->messageSequenceNumber); // @@999-1001
  if (duplicateTuple != NULL) {
    if (!duplicateTuple->D_retransmitted // @@1003-1016
	&& duplicateTuple->isInIfaceList(m->recvIfaceAddress))
      { /* do nothing yet: will consider for forwarding */ }
    else {
      if (duplicateTuple->D_retransmitted)
	{ PktD(*node->log, info, m, ",already-retransmitted"); }
      if (duplicateTuple->isInIfaceList(m->recvIfaceAddress))
	{ PktD(*node->log, info, m, ",in-iface-list"); }
      return; // stop processing - @@1003-1004
    } 
  } else { /* do nothing */ } // step 3 - @@1018-1019


  // Default forwarding algorithm - step 4 - @@1026-1029
  bool fromMPRSelector = node->isMPRSelector
    (node->ifaceToMainAddress(m->sendIfaceAddress));
  bool willRetransmit =  fromMPRSelector && m->timeToLive > 1;
  

  if (fromMPRSelector) 
    { PktD(*node->log, info, m, ",from-mpr"); }

  // Default forwarding algorithm - step 5 - @@
  if (duplicateTuple != NULL) { // @@1031

    duplicateTuple->D_time = node->getCurrentTime() 
      + node->getProtocolConfig()->DUP_HOLD_TIME; // @@1035
    duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress); // @@1037-1038
    if (willRetransmit) // @@1040=1041
      duplicateTuple->D_retransmitted = true; 
    duplicateTuple->update();

    PktD(*node->log, info, m, ",from-other-iface");

  } else { // @@1043

    duplicateTuple = new DuplicateTuple;
    duplicateTuple->D_addr = m->originatorAddress; // @@1045
    duplicateTuple->D_seq_num = m->messageSequenceNumber; // @@1047
    duplicateTuple->D_time = node->getCurrentTime()
      + node->getProtocolConfig()->DUP_HOLD_TIME; // @@1049
    duplicateTuple->D_iface_list.push_back(m->recvIfaceAddress); // @@1051
    duplicateTuple->D_retransmitted = willRetransmit; // @@1053-1054
    node->duplicateSet.add(duplicateTuple);

  }

  if (!willRetransmit)
    return; // @@1056-1057

  PktD(*node->log, info, m, ",retransmit");

  Message* newMessage = m->clone();
  m->timeToLive --; // @@1059
  m->hopCount ++; // @@1061
  sendPackedMessageToAll(newMessage); // @@1071-1073
}

void PacketManager::parsePacket(PacketBuffer& packet,
				std::list<Message*>& messageList,
				int& packetSequenceNumber,
				Address sendIfaceAddress,
				Address recvIfaceAddress)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  int packetSizeLimit = MessageHeaderWithoutAddressSize
    + addressSize;
  if (packet.size()<packetSizeLimit) {
    packet.raiseWarning("packet absolutly too short");
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " packet dropped, size "
      << packet.size() << " lower than minimum " << packetSizeLimit
      << std::endl);
    return; // @@921-923
  }
  int packetLength = packet.popUInt16(); // @@743
  packetSequenceNumber = packet.popUInt16(); // @@743

  packetLength -= PacketHeaderSize;
  // XXX!!! what do we do if there is a size mismatch, Mr RFC ?
  if(packetLength > packet.size()) {
    packet.raiseError("packet too short, field "
		      "'Packet Length' > actual packet size");
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " packet dropped, size "
      << packet.size() << " different from advertised length " << packetLength
      << std::endl);
    return;
  }
  if(packetLength < packet.size()) {
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " cropped packet too long, size "
      << packet.size() << " greater than advertised length " << packetLength
      << std::endl);
    packet.raiseWarning("packet too long, field 'Packet Length'"
			" < actual packet size");
    packet.crop(packetLength);
  }

  bool finished = false;
  while(packet.size() > 0 && !finished) {
    Message* message = popMessage(packet, sendIfaceAddress, recvIfaceAddress);
    if(message == NULL)
      finished = true; /// XXX: might still return the first messages
    else messageList.push_back(message);
  }
}

#ifdef LINK_MONITORING

void PacketManager::processLinkMonitoring(Address sendIfaceAddress,
					  Address recvIfaceAddress, 
					  int packetSequenceNumber)
{
  HeardIfaceTuple* heardIfaceTuple = 
    node->heardIfaceSet.findThisLink(sendIfaceAddress, recvIfaceAddress); 

  bool shouldAdd = false;
  if (heardIfaceTuple == NULL)
    {
      heardIfaceTuple = new HeardIfaceTuple(node, sendIfaceAddress,
					    recvIfaceAddress, 
					    packetSequenceNumber);
      shouldAdd = true;
    }

  heardIfaceTuple->setLinkQuality(packetSequenceNumber);
  if (shouldAdd) node->heardIfaceSet.add(heardIfaceTuple);
}
#endif


Message* PacketManager::popMessage(PacketBuffer& packet,
				   Address sendIfaceAddress,
				   Address recvIfaceAddress)
{
  int addressSize = node->getAddressFactory()->getAddressSize();
  int messageHeaderSize = MessageHeaderWithoutAddressSize + addressSize;

  int messageType = packet.popUInt8(); // @@745
  int vtime = packet.popUInt8(); // @@745
  int messageSize = packet.popUInt16(); // @@745

  Address originatorAddress = packet.popAddress(); // @@747

  int timeToLive = packet.popUInt8(); // @@749
  int hopCount = packet.popUInt8(); // @@749
  int messageSequenceNumber = packet.popUInt16(); // @@749

  if (messageSize < messageHeaderSize) {
    D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
      << node->getMainAddress() << " message dropped, size "
      << messageSize << " lower than minimum " << messageHeaderSize
      << std::endl);
    packet.raiseError("impossible message size: too small");
    return NULL;
  } 

  MemoryBlock* packedContent = 
    packet.popBlock(messageSize - messageHeaderSize);
  Message* result = new Message((MessageType)messageType, vtime, 
				originatorAddress, 
				timeToLive, hopCount);
  result->messageSequenceNumber = messageSequenceNumber;
  result->origin = ReceivedMessage;
  result->packedContent = packedContent;
  result->messageSize = messageSize;
  result->minMessageSize = messageSize;
  result->sendIfaceAddress = sendIfaceAddress;
  result->recvIfaceAddress = recvIfaceAddress;
  return result;
}

//---------------------------------------------------------------------------

// Strategy: send all the messages which demand to be sent, in a
// FIFO way.
void PacketManager::sendUpToTime(Time limitTime)
{
  // Get message limit (in the FIFO queue)
  std::list<MessageAndIface>::iterator limitIt = queue->end();
  for(std::list<MessageAndIface>::iterator it = queue->begin();
      it != queue->end(); it++) {
    if ((*it).message->maxTime <= limitTime )
      limitIt = it;
  }
  if(limitIt == queue->end()) //possible only if limitIt wasn't changed in loop
    return; // no message to send

  // Be sure that all interfaces have a packet buffer (XXX: move)
  // XXX! ensureIfaceWithBuffer();  --(looks ok, they all have now I think)

  // Get minimum MTU
  int minMTU = getIfaceMinMTU();
  
  std::list<MessageAndIface>::iterator it = queue->begin();
  bool finished = false;
  do {
    OLSRIface* iface = (*it).iface;
    Message* message =(*it).message;
    finished = (it == limitIt);
    std::list<MessageAndIface>::iterator last = it;
    it++;
    queue->erase(last);

    assert( message->minMessageSize > 0 );
    assert( message->messageSize > 0 );

    if (iface == NULL) {
      // note: NULL means "all interfaces"
      if (message->minMessageSize > minMTU) {
	// The message cannot go on at least one iface: dropped on all ifaces.
	Warn("Message dropped, min possible size greater than min MTU");
	D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
	  << node->getMainAddress() << " message dropped, min possible size "
	  << message->minMessageSize << "greater than min MTU " << minMTU
	  << std::endl);
	delete message;
      } else genericAppendMessage(NULL, message, minMTU);

    } else {
      int ifaceMTU = iface->getMTU();
      if (message->minMessageSize > ifaceMTU) {
	// The message cannot go on the iface
	Warn("Message dropped, min possible size greater than iface MTU");
	D(*node->log, lWarning, node->getRealTime() << " [WARNING] "
	  << node->getMainAddress() << " message dropped, min possible size "
	  << message->minMessageSize << "greater than iface MTU " << ifaceMTU
	  << std::endl);
	delete message;
      } else genericAppendMessage(iface, message, ifaceMTU);
    }
  } while(!finished);

  // Now send all the pending packets on the interfaces.
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    (*it)->flushPacket();
}


void PacketManager::genericAppendMessage(OLSRIface* iface,
					 Message* message, int minMTU)
{
  if(message->packedContent != NULL) {
    // Message was already packed
    appendPackedMessage(iface, message);
    return;
  }

  ProtocolConfig* protocolConfig = node->getProtocolConfig();
  int freeSpace = (iface == NULL) 
    ? getIfaceMinFreeSpace()
    : iface->getFreeSpace();
  double proportionLimit = (iface == NULL)
    ? protocolConfig->globalSplittingProportionLimit
    : iface->getConfig()->localSplittingProportionLimit;

  MemoryBlock* newBlock = NULL;
  Message* newMessage = NULL;
  
  if( message->messageSize > freeSpace ) {
    // too big - now consider splitting...
    bool canSplit = message->minMessageSize <= freeSpace;
    canSplit = canSplit &&
      ((minMTU * protocolConfig->freeSpaceSplittingProportionLimit)
       <= freeSpace); // must be enough room
    // packet must be big enough (to worth it):
    canSplit = canSplit &&((minMTU * proportionLimit) <= message->messageSize);

    if(canSplit) {
      // "canSplit to match free space", that is
      packMessage(message, freeSpace, newBlock, newMessage);
    } else {
      // split only using minMTU
      packMessage(message, minMTU, newBlock, newMessage);
    }
	 
  } else {
    packMessage(message, freeSpace, newBlock, newMessage);
    assert(newMessage == NULL);
  }

  delete message;
  message = NULL;

  if (newBlock != NULL) {
    if (iface == NULL)
      appendBlockOnAllIface(newBlock);
    else iface->appendBlock(newBlock);
    delete newBlock;
  } else {
    Warn("Packet packing (splitting) failed");
  }

  if (newMessage !=NULL)
    genericAppendMessage(iface, newMessage, minMTU); 
    //appendBlockOnAllIface(iface, newMessage->packedContent);
}

void PacketManager::appendBlockOnAllIface(MemoryBlock* block) // borrowed
{
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    (*it)->appendBlock(block);
}

// Design note: here, when a packet is forwarded, the message header
// is rewritten, but not the content.
void PacketManager::appendPackedMessage(OLSRIface* iface, Message* message)
{
  assert(message->content == NULL);
  assert(message->packedContent != NULL);

  // Pack and prepend message header, to already packed message content
  PacketBuffer buffer; 
  PacketManager::PositionInfo info 
    = node->getPacketManager()->packMessageHeader(buffer, message);
  buffer.packBlock(message->packedContent);
  node->getPacketManager()->adjustPackedMessageSize(buffer, info);
  buffer.rewind();
  MemoryBlock* blockResult = buffer.getContent(); 

  // now send it.
  if(iface == NULL)
    appendBlockOnAllIface(blockResult);
  else iface->appendBlock(blockResult);
  delete blockResult;
  delete message;
}

int PacketManager::getIfaceMinMTU()
{
  int minMTU = -1;
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    if((*it)->getMTU() < minMTU || minMTU<0)
      minMTU = (*it)->getMTU();
  return minMTU;
}

int PacketManager::getIfaceMinFreeSpace()
{
  int minMTU = -1;
  std::list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    if((*it)->getMTU() < minMTU || minMTU<0)
      minMTU = (*it)->getMTU();
  return minMTU;
}

void PacketManager::packMessage(Message* message, int maximumMessageSize,
				MemoryBlock*& newBlock, 
				Message*& newMessage)
{
  assert(message->content != NULL);
  assert(message->packedContent == NULL);
  IMessageHandler* handler = messageHandler[message->messageType];
  assert(handler != NULL);
  
  IMessageContent* newMessageContent = NULL;
  handler->packMessageContent(message->content, maximumMessageSize,
			      newBlock, newMessageContent);
  if(newMessageContent != NULL) {
    newMessage = newMessageContent->header;
    handler->adjustMessageSize(newMessage->content);
  } else newMessage = NULL;
}

void PacketManager::sendMessage(OLSRIface* iface, Message* message)
{
  assert(message->content != NULL);
  if(!node->isRunning()) {
    delete message;
    return;
  }

  message->content->header = message; // 

  IMessageHandler* handler = messageHandler[message->messageType];
  assert(handler != NULL);  
  handler->adjustMessageSize(message->content);

  message->origin = GeneratedMessage;

  MessageAndIface messageAndIface;
  messageAndIface.message = message;
  messageAndIface.iface = iface;
  D(*node->log, lPacketProcessing, node->getRealTime() << " [queued-message] " 
    << node->getMainAddress() << " ");
  if (iface != NULL) { D(*node->log, lPacketProcessing, iface->getAddress()); }
  else { D(*node->log, lPacketProcessing, "<all iface>"); }
  D( *node->log, lPacketProcessing, 
     " " << messageTypeToString(message->messageType));
  D(*node->log, lPacketProcessing, " " << (*message) << std::endl);
  queue->push_back(messageAndIface);
}

//---------------------------------------------------------------------------

Address OLSRIface::getAddress()
{ return iface->getAddress(); }

int OLSRIface::getMTU()
{ return iface->getMTU(); }

void OLSRIface::sendPacket(MemoryBlock* packet)
{ iface->sendPacket(packet); }

void OLSRIface::flushPacket()
{
  if (buffer == NULL) 
    prepareBuffer();
  buffer->rewind();
  if (buffer->size() == PacketHeaderSize)
    return; // empty packet (non-valid to send in any case @@XXX)
  int size = buffer->size(); // - PacketHeaderSize;
  int packetSequenceNumber = allocateSequenceNumber();
  buffer->pushUInt16(size);
  buffer->pushUInt16(packetSequenceNumber);
  buffer->rewind();
  MemoryBlock* packet = buffer->popBlock(buffer->size());
#if 1
  D(*(node->log), lPacketProcessing, node->getRealTime() << " [send-packet] "
    << node->getMainAddress() << " " << iface->getAddress() << " " 
    << packetSequenceNumber << " " << size << " " << (*packet) << std::endl);
#else
  if((node->log->lPacketProcessing) && (node->log->out)!=NULL) {
    (*(node->log->out)) << node->getRealTime() << " [send-packet] "
    << node->getMainAddress() << " " << iface->getAddress() << " " 
    << packetSequenceNumber << " " << size << " " << (*packet) << std::endl;
  }
#endif // XXX! why didn't 1st work?? (XXX: maybe missing -fPIC??)
  sendPacket(packet);
  delete buffer;
  buffer = NULL;
}

//---------------------------------------------------------------------------

void PacketManager::notifyMessageQueuing()
{
  if (node->getProtocolConfig()->immediateMessageTransmission)
    sendUpToTime(TimeNever);
}

//---------------------------------------------------------------------------

void IMessageContent::destroy(bool deleteHeader)
{
  if(deleteHeader && header != NULL) {
    header->content = NULL; // avoid delete loop
    delete header;
  }
  header = NULL;
}

//---------------------------------------------------------------------------
