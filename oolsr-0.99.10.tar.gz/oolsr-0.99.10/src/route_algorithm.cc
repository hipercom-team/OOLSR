//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements route calculation algorithms
//---------------------------------------------------------------------------

#include <list>
//#include <pair>
#include <vector>

using std::list;
using std::pair;
using std::vector;

//---------------------------------------------------------------------------

#if 0

template <typename Key, typename Value, typename HashType, class HashFunction>
class HashTable
{
public:
  typedef pair<Key, Value> Cell;
  typedef list<Cell> CellList;

  int nbBucket;

  HashTable(int aNbBucket) : nbBucket(aNbBucket)
  { 
    bucketArray.reserve(nbBucket);
  }

  CellList& getBucket(Key& key)
  {
    HashFunction hashFunction;
    HashType hashValue = hashFunction(key);
    return bucketArray[hashValue % nbBucket];
  }

  bool findCell(Key& key, typename CellList::iterator& resultIt)
  {
    CellList& cellList = getBucket(key);
    typename CellList::iterator it = cellList.begin();
    while (it != cellList.end()) {
      if (*it.first == key) {
	resultIt = it;
	return true;
      }
      it++;
    }
    return false;
  }

  Cell* findCell(Key& key)
  {
    typename CellList::iterator it;
    if (findCell(key, it))
      return &(*it);
    else return NULL;
  }

  Value* find(Key& key)
  {
    Cell* cell = findCell(key);
    if (cell == NULL) return NULL;
    else return &(cell->value);
  }

  void remove(Key& key)
  {
    typename CellList::iterator it;
    bool found = findCell(key, it);
    assert( found );
    it.remove();
  }

  void insert(Key& key, Value& value)
  {
    Cell* cell = findCell(key);
    if (cell == NULL) {
      CellList& cellList = getBucket(key);
      Cell newCell(key, value);
      cellList.push_back(newCell);
    } else {
      cell->value = value;
    }
  }

protected:
  vector<CellList> bucketArray;
};

//---------------------------------------------------------------------------


template <typename Value>
struct Identity {
  Value& operator() (Value& value) { return value; }
};

template <typename Value>
class IntHashTable 
  : public HashTable<int, Value, unsigned int, Identity<unsigned int> >
{};

#endif

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

const int MaxDistance = (1<<30);
//const int GrayDistance = MaxDistance - 1;

class GraphNode
{
public:
  //GraphNode() : neighb {}

  int distance;
  int nextHop[2];
  list<int> neighborList;
  void* data;
};

//---------------------------------------------------------------------------

class RouteAlgorithm
{
public:
  RouteAlgorithm() : nbNode(0) { }

  int addNode(void* data)
  { 
    int result = nbNode; 
    nbNode++; 
    //nodeInfoArray.resize(nbNode); 
    //nodeInfoArray[result].neighborList.clear();
    //GraphNode newGraphNode;
    //GraphNode* graphNode = new GraphNode;
    GraphNode graphNode;
    graphNode.data = data;
    nodeInfoArray.push_back(graphNode);
    //nodeInfoArray[result]->neighborList = new list<int>; // XXX: leak
    assert( nodeInfoArray.size() == result+1 );
    return result;
  }

  void addLink(int nodeIdx, int anotherNodeIdx, bool bothWays = false)
  { 
    assert( inrange(0, nodeIdx, nbNode) );
    assert( inrange(0, anotherNodeIdx, nbNode) );
    GraphNode* nodeInfo = &nodeInfoArray[nodeIdx];
    nodeInfo->neighborList.push_back(anotherNodeIdx);
    if (bothWays)
      addLink(anotherNodeIdx, nodeIdx, false);
  }

  void addStartingNode(int nodeIdx)
  { 
    //GraphNode& nodeInfo = nodeInfoArray[nodeIdx];
    //nodeInfo.distance = 0;
    assert( inrange(0, nodeIdx, nbNode) );
    startingNodeList.push_back(nodeIdx);
  }
  
  //void removeNode(string Address);
  //void removeLink(string Address);

  //void computeRouteTable();
  void breadthFirst();

  list<int> startingNodeList;
  
  //vector<  > neighborListArray;
  vector< GraphNode > nodeInfoArray;

  bool isReached(int nodeIdx) { 
    assert( inrange(0, nodeIdx, nbNode) );
    return nodeInfoArray[nodeIdx].distance != MaxDistance;
  }

  ~RouteAlgorithm()
  { 
    assert( nodeInfoArray.size() == nbNode );
#if 0
    for (int i=0;i<nbNode;i++) {
      if (nodeInfoArray[i] != NULL)
	delete nodeInfoArray[i];
      nodeInfoArray[i] = NULL;
    }
#endif
  }
    
  int nbNode;
};

//---------------------------------------------------------------------------

void RouteAlgorithm::breadthFirst()
{
  list<int> grayNodeList = startingNodeList;
  
  for(int i=0; i<nbNode;i++) {
    nodeInfoArray[i].distance = MaxDistance;
  }

  int currentDistance = 0;
  while (!grayNodeList.empty()) {
    list<int> newGrayNodeList;

    for (list<int>::iterator it = grayNodeList.begin(); 
	it != grayNodeList.end(); it++) {

      int nodeIdx = *it;
      assert( inrange(0, *it, nbNode) );
      GraphNode& nodeInfo = (nodeInfoArray[nodeIdx]);

      nodeInfo.distance = currentDistance;

      //if (nodeInfo->neighborList.empty() == 0) continue; //XXX
      list<int>& neighborList = (nodeInfo.neighborList);
      if (neighborList.empty()) continue; // XXX
      for (list<int>::iterator otherIt = neighborList.begin();
	   otherIt != neighborList.end(); otherIt++) {
	int otherIdx = *otherIt;
	assert( inrange(0, otherIdx, nbNode) );
	if (!isReached(otherIdx)) {
	  GraphNode& otherNodeInfo = (nodeInfoArray[otherIdx]);

	  for (int i=0;i<std::min(2,currentDistance);i++)
	    otherNodeInfo.nextHop[i] = nodeInfo.nextHop[i];
	  if (currentDistance < 2)
	    otherNodeInfo.nextHop[currentDistance] = nodeIdx;
	  if (currentDistance == 0)
	    otherNodeInfo.nextHop[1] = otherIdx;

	  otherNodeInfo.distance = currentDistance+1;
	  newGrayNodeList.push_back(otherIdx);
	}
      }
    }
    currentDistance ++;
    grayNodeList = newGrayNodeList;
  }
}

//---------------------------------------------------------------------------
