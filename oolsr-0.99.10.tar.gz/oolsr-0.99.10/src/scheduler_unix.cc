//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// See also: olsrdv5/main/unix_io_scheduler.c
//---------------------------------------------------------------------------

#ifndef SYSTEMcygwin
#  include <sys/select.h>
#else // SYSTEM == cygwin
#  include <windows.h>
#  include <winsock2.h>
#endif // SYSTEM

#include <errno.h>

#include <sys/signal.h> // for cygwin

#include "log.h"
#include "scheduler_generic.h"
#include "scheduler_unix.h"

//---------------------------------------------------------------------------

typedef std::pair<IFdHandler*,void*> HandlerInfo;
typedef  std::list< HandlerInfo > HandlerList;

#include <sys/time.h> // for gettimeofday, not portable
#include <time.h> 
#include <map>

Time IOScheduler::getTime()
{ 
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
} 

void IOScheduler::addFdHandler(IFdHandler* fdHandler, void* data)
{ handlerList.push_back( HandlerInfo(fdHandler, data) ); }

void IOScheduler::write(std::ostream& out)
{ scheduler->write(out); }

void IOScheduler::waitForIO(Time maxTime)
{
  int i,j;
  fd_set fdSet[3]; // (note: in cygwin/winsock2, this is not a bitmap)
  int maxFD = -1;
  int status;
  sigset_t sigset;
  //struct { IFdHandler* handler; } handlerTable [FD_SETSIZE][3];
  std::map<FileDescriptor, IFdHandler*> handlerTable[3];

  const int Input = 0, Output = 1, Except = 2;

  // update the "lastFD"

#define ADD_HANDLER(x,h) do { \
       FileDescriptor fd = h->getFileDescriptor(); \
       if(fd>maxFD) maxFD = fd; \
       FD_SET(fd, &(fdSet[x])); \
   handlerTable[x].insert(std::pair<FileDescriptor, IFdHandler*>(fd, h)); \
    } while(0)

  // set fd_set/s 
  maxFD = 0;
  for(j=0;j<3;j++) {
    FD_ZERO(&(fdSet[j]));
    for(HandlerList::iterator it = handlerList.begin();
	it!= handlerList.end(); it++) 
      {
	IFdHandler* handler = (*it).first;
	if (j == Input) {
	  if (handler->waitingForInput())
	    ADD_HANDLER(Input, handler);
	} else if (j == Output) {
	  if (handler->waitingForOutput()) 
	    ADD_HANDLER(Output, handler);
	} else if (j == Except) {
	  if (handler->waitingForExcept())
	    ADD_HANDLER(Except, handler);
	} else Fatal("Impossible select set index");
      }
  }

  /* select */
  struct timeval tv;
  tv.tv_sec = (unsigned int)maxTime;
  tv.tv_usec = (unsigned int) ((maxTime - tv.tv_sec)*(1e6 - 1));
  assert( tv.tv_usec < 1000000 );
  status = select(maxFD+1, fdSet+0, fdSet+1, fdSet+2, &tv);

  if (status < 0) {
    if (errno != EINTR) // XXX: check for cygwin/Windows
      Warn("select");
  } else if (status > 0) {
    for(j=0;j<3;j++) {
      for(std::map<FileDescriptor, IFdHandler*>::iterator it 
	    = handlerTable[j].begin(); it != handlerTable[j].end(); it++) {
	//for(i=0;i<FD_SETSIZE;i++) { // XXX: not optimized
	if(FD_ISSET((*it).first, &(fdSet[j]))) {
	  IFdHandler* handler = (*it).second;
          assert( handler != NULL );
	  if(j == Input) handler->handleInput();
	  else if (j == Output) handler->handleOutput();
	  else if (j == Except) handler->handleExcept();
	  else Fatal("Impossible select set index");
          FD_CLR((*it).first, &(fdSet[j]));
        }
      }
    }
  }
  //return status != 0; /* time out */
}

//---------------------------------------------------------------------------
