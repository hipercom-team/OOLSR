//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Run a simulation based on a topology file
//---------------------------------------------------------------------------

#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <list>
#include <iostream>
#include <fstream>
#include <string>

//---------------------------------------------------------------------------

#include "log.h"
#include "simulation-api.h"

//---------------------------------------------------------------------------

using std::string;

void fatalUsage(char* progName)
{
  std::cerr << "Usage: " << progName << " --topology <file>" << std::endl;
  std::cerr << "  or " << progName << " <nbNode> <nbIface> <minRange> <maxRange> <maxSpeed>" << std::endl;
  exit(EXIT_FAILURE);
}

//---------------------------------------------------------------------------

#include "simul_world.cc"

const int MTU = 1000;

// XXX: put elsewhere
static int nodeStrToIdx(string nodeString)
{
  assert(nodeString.length() >= 1);
  if (nodeString.length() == 1) {
    int result = nodeString[0] - (int)'A';
    assert( inrange(0, result, 26) );
    return result;
  }
  assert( nodeString[0] == 'N' );
  nodeString.erase(0, 1);
  return atoi(nodeString.c_str()); // XXX:aton
}

//---------------------------------------------------------------------------

typedef struct {
  double clock;
  int isUp;
  int srcNodeIdx;
  int srcIfaceIdx;
  int dstNodeIdx;
  int dstIfaceIdx;
} UnidirLink;

class NodeInfo
{
public:
  NodeInfo(int aNodeIdx, int aMaxIface, string aConfig) :
    nodeIdx(aNodeIdx), maxIface(aMaxIface), config(aConfig) { }

  int nodeIdx;
  int maxIface;
  string config;
};

typedef std::list< NodeInfo > NodeInfoList;

class CheckPointData
{
public:
  CheckPointData(char* aFileName, char* aMessage)
    : fileName(aFileName), message(aMessage) {}
  CheckPointData(double aClock, bool aShouldCheck) 
    : clock(aClock), shouldCheck(aShouldCheck) {}

  double clock;
  bool shouldCheck;
  char* fileName;
  char* message;
};

static bool dumpTopology = false; // set by command line argument parser.

void parseTopologyFile(char* fileName, bool noLog, int& limitNodeIdx, 
		       NodeInfoList& nodeInfoList,
		       std::list< UnidirLink >& linkList,
		       std::list< CheckPointData* >& checkPointList)
{
  int nbNode, nbLink, nbCheckPoint;
  std::ifstream input(fileName);
  if (input.bad()) {
    std::cerr << "Cannot open topology file '" << fileName << "'." <<std::endl;
    exit(EXIT_FAILURE);
  }
  input >> limitNodeIdx >> nbNode >> nbLink >> nbCheckPoint;

  if (input.bad()) {
    std::cerr << "Syntax error: cannot read: <bound node id> "
          "<nb nodes> <nb links> <nb checkpoints>" <<std::endl;
    exit(EXIT_FAILURE);
  }

  for(int i=0; i<nbNode; i++) {
    int limitIfaceIdx;
    int nodeIdx;
    input >> nodeIdx >> limitIfaceIdx;
    string configData = ""; 
    for(;;) {
      char c;
      input.get(c);
      if (input.good() && c!='\n')
	configData += c;
      else break;
    }
    if(noLog) configData += "\n# --no-log argument\nno-log true\n";
    if (input.bad()) {
      std::cerr << "Syntax error: cannot read: <node id> <bound iface id>"
	" [<config>]" << std::endl;
      exit(EXIT_FAILURE);
    }
    
    nodeInfoList.push_back( NodeInfo(nodeIdx, limitIfaceIdx, configData) );
    if (dumpTopology)
      std::cerr << "Node: " << nodeIdx << " (" << limitIfaceIdx 
		<< " iface(s))\n";
  }

  for (int i=0; i<nbLink; i++) {
    UnidirLink link;
    input >> link.srcNodeIdx >> link.srcIfaceIdx 
	  >> link.dstNodeIdx >> link.dstIfaceIdx
	  >> link.clock >> link.isUp;
    if (input.bad()) {
      std::cerr << "Syntax error: cannot read link" << std::endl;
      exit(EXIT_FAILURE);
    }
    linkList.push_back(link);
    if (dumpTopology)
      std::cerr << "Link: " << link.srcNodeIdx << "/" << link.srcIfaceIdx
		<< "->" << link.dstNodeIdx << "/" << link.dstIfaceIdx
		<< (link.isUp ? " up at " : " down at ") << link.clock << "\n";
  }

  for (int i=0; i<nbCheckPoint; i++) {
    double clock;
    int shouldCheck;
    input >> clock >> shouldCheck;
    if (input.bad()) {
      std::cerr << "Syntax error: cannot read checkpoint" << std::endl;
      exit(EXIT_FAILURE);      
    }
    checkPointList.push_back(new CheckPointData(clock, shouldCheck!=0));
    if (dumpTopology)
      std::cerr << "Checkpoint at " << clock << std::endl;
  }
}

void checkPointEvent(void* data, void* unused2, void* unused3)
{
  CheckPointData* info = (CheckPointData*) data;
  char* message = (char*) (info->shouldCheck 
			   ? "check\n" : "output\n"); //XXX:cast
  writeState(info->fileName, message);
  delete info;
}

void linkEvent(void* data, void* unused1, void* unused2)
{
  UnidirLink& link = *(UnidirLink*)data;
  if (link.isUp) {
    addNodeLink( link.srcNodeIdx, link.srcIfaceIdx, 
		 link.dstNodeIdx, link.dstIfaceIdx );

  } else {
    removeNodeLink( link.srcNodeIdx, link.srcIfaceIdx, 
		    link.dstNodeIdx, link.dstIfaceIdx );
  }
}

void createSimulationFromTopologyFile(char* topologyFileName, int nbNode,
				      double& endClock, char* outputFileName)
{
  NodeInfoList nodeInfoList;
  std::list<UnidirLink>& linkList = *(new std::list<UnidirLink>); // XXX:leak
  std::list<CheckPointData*> checkPointList; // XXX:leak

  parseTopologyFile(topologyFileName, true, nbNode, 
		    nodeInfoList, linkList, checkPointList);

  initSimulation(NULL, nbNode);

  for(NodeInfoList::iterator it = nodeInfoList.begin(); 
      it != nodeInfoList.end(); it++) {
    addNode( (*it).nodeIdx, (*it).maxIface, MTU,
	     (char*)((*it).config.c_str()), (*it).config.length() );
  }
  
  for (std::list<UnidirLink>::iterator it = linkList.begin();
       it != linkList.end(); it++) {
    UnidirLink& link = *it;
    if (link.clock <= 0.0 && link.isUp)
      addNodeLink( link.srcNodeIdx, link.srcIfaceIdx, 
		   link.dstNodeIdx, link.dstIfaceIdx );
    else scheduleFunctionAt(link.clock, linkEvent, (void*)&link);
  }
  
  for(std::list<CheckPointData*>::iterator it = checkPointList.begin();
      it != checkPointList.end(); it++) {
    (*it)->fileName  = outputFileName;
    (*it)->message = NULL;
    scheduleFunctionAt((*it)->clock, checkPointEvent, *it);
    if( (*it)->clock > endClock)
      endClock = (*it)->clock + 0.01;
  }
}

//---------------------------------------------------------------------------

static World* world;

int idxToIfaceIdx(int idx, int nbNode) { return idx/nbNode; }
int idxToNodeIdx(int idx, int nbNode) { return idx%nbNode; }
int nodeIfaceToIdx(int nodeIdx, int ifaceIdx, int nbNode)
{ return nodeIdx+ifaceIdx*nbNode; }

static int totalNbNode = -1;

void getDynamicLink(void* data,
		    int srcNodeIdx, int srcIfaceIdx,
		    int* resultCount,
		    int** nodeIdxList, 
		    int** ifaceIdxList)
{
  std::list<int> infoList;
  world->getReceiverList(nodeIfaceToIdx(srcNodeIdx, srcIfaceIdx, totalNbNode),
			 getSimulationTime(), infoList);
  *resultCount = infoList.size();
  *nodeIdxList = (int*) malloc( *resultCount * sizeof(int) );
  *ifaceIdxList = (int*) malloc( *resultCount * sizeof(int) );
  int current = 0;
  for(std::list<int>::iterator it = infoList.begin(); 
      it != infoList.end(); it++) {
    (*nodeIdxList)[current] = idxToNodeIdx(*it, totalNbNode);
    (*ifaceIdxList)[current] = idxToIfaceIdx(*it, totalNbNode);
    current ++;
  }
}

void createSimulationBilliard(int nbNode, int nbIface,
			      double areaWidth, double areaHeight,
			      double minRange, double maxRange,
			      double maxSpeed, string defaultConfig)
{
  totalNbNode = nbNode;
  initSimulation(NULL, nbNode);
  
  world = new World(nbNode*nbIface, areaWidth, areaHeight,
		    minRange, maxRange, maxSpeed);
  
  for(int i=0; i<nbNode; i++)
    addNode(i, nbIface, MTU, (void*)defaultConfig.c_str(), 
	    defaultConfig.length());
  
#if 0
  for(int i=0; i<nbNode; i++) {
    for (int j=0; j<nbIface; j++) {
      int nextNode = (i+1+j); //% nbNode;
      if (nextNode<nbNode && nextNode != i)
	addNodeLink(i, j, nextNode, j);
    }
    addNodeLink(i, 0, (i+nbNode-1)%nbNode, 0);
  }
#endif

  for(int i=0; i<nbNode; i++) {
    for (int j=0; j<nbIface; j++) {
      world->create(nodeIfaceToIdx(i, j,totalNbNode));
      addDynamicLink(i, j, getDynamicLink, NULL);
    }
  }
}

//---------------------------------------------------------------------------

// XXX: unused, remove
#ifdef XXX_TODO

#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sched.h>

#include <sys/time.h>
#include <stdio.h>


volatile bool isFinished = false;

void outputStat2(std::ostream& out)
{   
  char* data; int dataSize;
  getSimulationStat(&data, &dataSize);
  assert(strlen(data) == dataSize-1);
  out << getSimulationTime() << "/ " << data;;
  free(data);
  out.flush();
}

double getTime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
}


int displayThread(void* data)
{
  double displayInterval  = *(double*)data;
  std::ofstream out("/proc/self/fd/1");
  double startTime = getTime();
  for(;;) {
    usleep((unsigned int)(displayInterval*1e6));
    if (isFinished)
      abort(); // XXX!: don't want a clean return because of profile .da writing?
    out << (getTime() - startTime) << "|";
    outputStat(out);
  }
  return EXIT_FAILURE; // never reached
}

#endif

extern void outputStat(std::ostream& out);

bool startsWith(char* a, char* b)
{ return strncmp(a,b,strlen(b)) == 0; }

//---------------------------------------------------------------------------

int main(int argc, char** argv)
{
  int argCount = argc-1;
  char* progName = argv[0];
  char** argList = argv+1;

  bool withTopologyFile = false;
  char* topologyFileName = NULL;
  char* pluginFileName = NULL;

  char* outputFileName = "-";

  int nbNode;
  int nbIface;
  double areaWidth = 1.0;
  double areaHeight = 1.0;

  double endClock = 30.0;

  bool noLog = false; // XXX: not implemented
  double displayInterval = 0.0;
  bool quiet = false;

  string argConfigStr;

  while(argCount > 0) {

    if (!strcmp(argList[0], "--topology")) {
      withTopologyFile = true;
      if (argCount < 2) {
	fprintf(stderr, "%s: missing topology filename\n", progName);
	fatalUsage(progName);
      }
      topologyFileName = argList[1];
      argCount -= 2;
      argList += 2;

    } else if (!strcmp(argList[0], "--dump-topology")) {
      dumpTopology = true;
      argCount -= 1;
      argList += 1;

    } else if (!strcmp(argList[0], "--height")) {
      areaHeight = atof(argList[1]); // XXXatof
      argCount -= 2;
      argList += 2;

    } else if (!strcmp(argList[0], "--display")) {
      displayInterval = 10.0;
      argCount -= 1;
      argList += 1;

    } else if (!strcmp(argList[0], "--log-node")) { //XXX: not implemented
      dumpTopology = true;
      argCount -= 1;
      argList += 1; 

    } else if (!strcmp(argList[0], "--output")) {
      if (argCount < 2) {
	fprintf(stderr, "%s: missing output filename\n", progName);
	fatalUsage(progName);
      }
      outputFileName = argList[1];
      argCount -= 2;
      argList += 2;

    } else if (!strcmp(argList[0], "--duration")) {
      if (argCount < 2) {
	fprintf(stderr, "%s: missing duration\n", progName);
	fatalUsage(progName);
      }
      endClock = atof(argList[1]);
      argCount -= 2;
      argList += 2;

    } else if (!strcmp(argList[0], "--no-log")) {
      noLog = true;
      argCount -= 1;
      argList += 1; 

    } else if (!strcmp(argList[0], "--quiet")) {
      quiet = true;
      argCount -= 1;
      argList += 1; 


    } else if (!strcmp(argList[0], "--plugin")) {
      pluginFileName = argList[1];
      argCount -= 2;
      argList += 2; 

    } else if (!strcmp(argList[0], "--")) {
      argCount -= 1;
      argList += 1; 
      break;

    } else if (startsWith(argList[0], "--")) {
      int endArg = 1;
      string cfgOption = argList[0];
      cfgOption.erase(0, 2); // remove "--"
      while(endArg < argCount && !startsWith(argList[endArg], "--")) {
	cfgOption += " ";
	cfgOption += argList[endArg];
	endArg++;
      }
      
      argConfigStr += ("# From command line option: --" + cfgOption + "\n")
	+ (cfgOption + "\n");

      argCount -= endArg;
      argList += endArg;

    } else break; // No more parsed arguments
  }

  if (doesRequirePlugin() && pluginFileName == NULL) 
    Fatal("Plugin file required for this binary");
  assert( !doesRequirePlugin() ); // XXX No plugin supported in this version

  if (withTopologyFile) {
    createSimulationFromTopologyFile(topologyFileName, nbNode, endClock,
				     outputFileName);
  } else {
    if (argCount != 5)
      fatalUsage(progName);
    
    int nbNode = atoi(argList[0]);
    int nbIface = atoi(argList[1]);
    double minRange = atof(argList[2]);
    double maxRange = atof(argList[3]);
    double maxSpeed = atof(argList[4]);

    createSimulationBilliard(nbNode, nbIface, 1.0, areaHeight,
			     minRange, maxRange, maxSpeed,
			     argConfigStr);
  } 

#ifdef XXX_TODO
  DONTWORK
  int childPid = -1;
  std::cout.flush();
  if (displayInterval > 0.0) {
    int childPid = clone(displayThread, 
			 ((char*)malloc(10000))+9000 /*XXX: hack*/,
#ifdef CLONE_PARENT			 
			 CLONE_PARENT|CLONE_THREAD|
#endif			 
			 CLONE_VM,
			 (void*)&displayInterval);
    if (childPid < 0)
      Fatal("Cannot clone(.) process: " << strerror(errno));
  }
#endif

  runUntil(endClock);
  if (strcmp(outputFileName, "/dev/null") != 0)
    writeState(outputFileName, "output\n");


#ifndef XXX_TODO
  //isFinished = true;
  //kill(childPid, SIGTERM); // Why is this killing randomly processes?

  //if (!quiet && displayInterval > 0.0)
  //  outputStat(std::cout);
#endif
  
  exit(EXIT_SUCCESS);
}

//---------------------------------------------------------------------------
