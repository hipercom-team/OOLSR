//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//             Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Linux
//---------------------------------------------------------------------------
// For IPv6, see for instance documentation:
//   http://www.gsp.com/cgi-bin/man.cgi?section=4&topic=ip6
//   misc. RFC, http://www.ietf.org/rfc/rfc3542.txt, ...
//---------------------------------------------------------------------------

// IPv6 is the default
#if !defined(WITH_IPV4) && !defined(WITH_IPV6)
#define WITH_IPV6
#endif

//---------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>
//#include "linux

#include <errno.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#ifdef WITH_IPV6
#include <ifaddrs.h>
#endif // WITH_IPV6

#include <arpa/inet.h> // inet_pton

#include <string>
#include <vector>

using std::string;
using std::vector;

#include "general.h"
#include "address.h"
#include "network_generic.h"
//#include "network_linux.h"
#include "scheduler_simulation.h"
#include "scheduler_unix.h"

#include "http_support.h"

#include "html_support.cc" // XXX:  rename

//---------------------------------------------------------------------------

class LinuxLowLevel
{
public:
  static void setSocketReuseAddr(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (void*)&on,
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_REUSEADDR: " << strerror(errno));
  }

  static void setSocketBroadcast(int sd)
  {
    int on = 1;
    if (setsockopt(sd, SOL_SOCKET, SO_BROADCAST, (void*)&on,
		   sizeof (on)) < 0)
      Fatal(" setsockopt SO_BROADCAST: " << strerror(errno));
  }

  static void addRoute(int family, int ifaceIndex, Address destIpAddress,
		Address gatewayAddress, Address netMaskAddress, 
		int metric, bool notFatal)
  {
    //    modifyRoute(RTM_NEWROUTE,NLM_F_REPLACE|NLM_F_CREATE|NLM_F_ACK, family, 
    //		ifaceIndex, destIpAddress, gatewayAddress, netMaskAddress,
    //		metric);
    modifyRoute(RTM_NEWROUTE,NLM_F_CREATE|NLM_F_ACK, family, 
		ifaceIndex, destIpAddress, gatewayAddress, netMaskAddress,
		metric, notFatal);
  }

  static void removeRoute(int family, int ifaceIndex, Address destIpAddress,
		   Address gatewayAddress, Address netMaskAddress, 
		   int metric, bool notFatal)
  {
    modifyRoute(RTM_DELROUTE, NLM_F_ACK, family, ifaceIndex,
		destIpAddress, gatewayAddress, netMaskAddress, metric, 
		notFatal);
  }

protected:

  static int modifyRoute( int action, int flags, int family, int ifaceIndex,
			  Address destIpAddress,
			  Address gatewayAddress, Address netMaskAddress, 
			  int metric, bool notFatal)
  {
    int sock;
    struct
    {
      struct nlmsghdr  nlh;
      struct rtmsg routeMsg;
      char   attrbuf[1024];
    } req;
    int netFormatSize = destIpAddress.getNetSize();
    octet* netFormatAddress = new octet[netFormatSize];
    octet* netFormatAddress2 = new octet[netFormatSize];

    int index=ifaceIndex;
    int hops=metric;
    struct sockaddr_nl nladdr;
    static unsigned int seq;
    

    if((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0)
      {
	Fatal(" PF_NETLINK: error socket creation ");
	return -1;
      }
    
    memset(&nladdr,0,sizeof(nladdr));
    
    nladdr.nl_family= AF_NETLINK;
    
    req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
    req.nlh.nlmsg_type= action;   
    req.nlh.nlmsg_flags = NLM_F_REQUEST|flags;
    req.nlh.nlmsg_pid = 0;
    req.nlh.nlmsg_seq = ++seq;
    
    req.routeMsg.rtm_family=family;
    
    if (netMaskAddress.isNull()) {
      const int BITS_PER_OCTET = 8;
      req.routeMsg.rtm_dst_len = destIpAddress.getNetSize() * BITS_PER_OCTET;
    } else {
      netMaskAddress.toNet(netFormatAddress);
      req.routeMsg.rtm_dst_len = prefix_length(family, netFormatAddress);
    }
  
    req.routeMsg.rtm_src_len = 0;
    req.routeMsg.rtm_tos = 0;
    req.routeMsg.rtm_table = RT_TABLE_MAIN; //DEFAULT;
    req.routeMsg.rtm_protocol = 100;                     //XXX a verifier
    req.routeMsg.rtm_scope = RT_SCOPE_LINK; //RT_SCOPE_LINK;
    req.routeMsg.rtm_type = RTN_UNICAST;
    req.routeMsg.rtm_flags = 0;

    gatewayAddress.toNet(netFormatAddress);
    destIpAddress.toNet(netFormatAddress2);
    

    if(!(gatewayAddress==destIpAddress)){
    req.routeMsg.rtm_scope=RT_SCOPE_UNIVERSE;
      addattr(&req.nlh,RTA_GATEWAY,netFormatAddress,netFormatSize);
    }
    
    addattr(&req.nlh,RTA_DST,netFormatAddress2,netFormatSize);
    
    
   
    addattr(&req.nlh,RTA_OIF,&index,sizeof(index));
    addattr(&req.nlh,RTA_PRIORITY,&hops,sizeof(hops));

    delete [] netFormatAddress;
    delete [] netFormatAddress2;

    if(sendto(sock,&req,sizeof(req),0,NULL,0)<0)
      Fatal("Netlink sendto request to kernel error");
    else
      {	
	get_system_reply(sock,seq, notFatal);
      }
    return 0;
  }
  
  static int prefix_length(int family, void *anetmask)
  {
    int prefix=0;
    if(family== AF_INET)
      {
	unsigned int netmask;
	memcpy(&netmask,anetmask,sizeof(unsigned int));
	netmask=ntohl(netmask);
	//printf("netmask initialement: %d\n",netmask);
	while(netmask!=0)
        {
          netmask=netmask<<1;
          //printf("netmask : %d\n",netmask);
          prefix++;
          
        }
	//printf("prefix length is: %d\n",prefix);
	return prefix;
      }
    if(family== AF_INET6)
      {
	struct in6_addr netmask;
	unsigned int mask;
	int i;
	memcpy(&netmask,anetmask,sizeof(struct in6_addr));
	for(i=0;i<4;i++)
	  {
	    mask=ntohl(netmask.s6_addr32[i]);
	    while(mask!=0)
	      {
		mask=mask<<1;
		prefix++;
	      }
	  }
	return prefix;
      }
    return (-1);
  }
  
  static int get_system_reply(int sockFd, int seqNum, bool notFatal)
  {
#define NL_BUFSIZE 8192
    char buf[NL_BUFSIZE];
    struct sockaddr_nl nladdr;
    struct iovec iov = { buf,NL_BUFSIZE };
    struct nlmsghdr *h;
    struct nlmsgerr *m;
    struct rtattr *attr;
    
    
    int status,attrsize;
    
    
    
      
    struct msghdr msg = {(void*)&nladdr, sizeof(nladdr),&iov,   1, NULL, 0, 0};       
    status = recvmsg(sockFd, &msg, 0);        
    
    h = (struct nlmsghdr*)buf;
    while ( NLMSG_OK(h, status))
      {
	
	if (h->nlmsg_seq != seqNum)
	  {
	    Fatal(" Nlmsg error: bad sequence number ");
	    return -1;
	  }
	
	if (h->nlmsg_type == NLMSG_DONE)
	  {
	    fprintf(stderr,"Netlink call done \n");              
	    
	    return 0;
	  }
	
	if (h->nlmsg_type == NLMSG_ERROR)
	  {
	    m = (nlmsgerr*) NLMSG_DATA(h); // XXX: error: invalid conversion from `void*' to `nlmsgerr*'
	    
	    if(m->error < 0)
	      {
		int errorCode = -(m->error);
		if (errorCode == EEXIST) {
		  Warn("Nlmsg ACK: EEXIST, a route probably existed before");
		  return -1;
		} else if (errorCode == EPERM) {
		  if (notFatal) {
		    Warn("Nlmsg ACK: EPERM, probably don't have permission to"
			  " set routes");
		  } else {
		    Fatal("Nlmsg ACK: EPERM, probably don't have permission to"
			  " set routes");
		  }
		} else if (errorCode == EAGAIN || errorCode == EINTR) {
		  Warn("Nlmsg ACK: EAGAIN or EINTR, one route is probably"
		       " not correctly set now."); // XXX
		} else {
		  if (notFatal) {
		    Warn("Route config: Nlmsg ACK: "
			  << strerror(-(m->error))); 
		  } else {
		    Fatal("Route config: Nlmsg ACK: "
			  << strerror(-(m->error))); 
		  }

		}
		return -1;
	      }
	  }       
	h=NLMSG_NEXT(h,status);
      }
    return 0;  
  }
  
  
  static int addattr(struct nlmsghdr *header, int type, void *data, int alen)
  {
    struct rtattr *attr;
    int len = RTA_LENGTH(alen);
        
    attr = (struct rtattr*)(((char*)header) + NLMSG_ALIGN(header->nlmsg_len));
    attr->rta_type = type;
    attr->rta_len = len;
    memcpy(RTA_DATA(attr), data, alen);
    header->nlmsg_len = NLMSG_ALIGN(header->nlmsg_len) + len;
    return 0;
  }

};

//--------------------------------------------------

class LinuxIPv6LowLevel : public LinuxLowLevel
{
public:
  static const int AddressSize = 128/8; // in bytes, XXX: use #include

  typedef sockaddr_in6 SystemAddress;

  static void* systemAddressToRawAddress(SystemAddress& systemAddress)
  {
    assert( systemAddress.sin6_family == AF_INET6 );
    assert( sizeof(systemAddress.sin6_addr) == AddressSize );
    return &(systemAddress.sin6_addr);
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin6_family = AF_INET6;
    memcpy(&resultAddress.sin6_addr, rawAddress, AddressSize);
  }

  static int makeUDPSocket()
  {
    int sd = socket(AF_INET6, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(sockaddr_in6& sockAddress, char* strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin6_family = AF_INET6;

    if (strGroupAddress == NULL)
      sockAddress.sin6_addr = in6addr_any;
    else inet_pton(AF_INET6, strGroupAddress, &sockAddress.sin6_addr);
  }

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin6_port = htons(udpPort); }

  static void reprAddress(SystemAddress& address, char* result)
  { inet_ntop(AF_INET6, &address.sin6_addr, result, 4096 /*XXX!*/); }

  static void joinMulticastGroup(int sd, char* ifaceName, int ifaceIndex,
				 char* strGroupAddress)
  {
    struct ipv6_mreq mreq;
    memset (&mreq, 0, sizeof (mreq));
    inet_pton(AF_INET6, strGroupAddress, &mreq.ipv6mr_multiaddr);
    mreq.ipv6mr_interface = ifaceIndex;
    
    if(setsockopt(sd, IPPROTO_IPV6, IPV6_JOIN_GROUP, 
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal(" setsockopt IPV6_JOIN_GROUP: " << strerror(errno) );
  }

  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    if (setsockopt(sd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &ifaceIndex,
		   sizeof(ifaceIndex)) < 0)
      Fatal(" setsockopt IPV6_MULTICAST_IF: " << strerror(errno) );
  }

  static void socketBind(int sd, SystemAddress& address)
  {
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }

  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Fatal(" sendto: " << strerror(errno) );// XXX: not fatal
  }

};

//---------------------------------------------------------------------------

template <class LowLevel>
class LinuxAddressFactory : public AddressFactory
{
public:

  typedef typename LowLevel::SystemAddress SystemAddress;

  LinuxAddressFactory() : AddressFactory(LowLevel::AddressSize)
  {}

  Address makeAddress(SystemAddress& systemAddress) 
  { return Address(this, LowLevel::systemAddressToRawAddress(systemAddress)); }

  void makeSystemAddress(Address address, SystemAddress& result)
  { LowLevel::rawAddressToSystemAddress(address.getRawAddress(), result); }

  virtual Address parseAddress(char* textString) {
    SystemAddress systemAddress;
    LowLevel::strToAddress(systemAddress, textString);
    return makeAddress(systemAddress);
  }

  virtual void write(std::ostream& out, const Address& address)
  {
    typename LowLevel::SystemAddress systemAddress;
    LowLevel::rawAddressToSystemAddress(address.getRawAddress(),
					systemAddress);
    char strAddress[4096]; // XXX
    LowLevel::reprAddress(systemAddress, strAddress);
    out << strAddress;
  }
};

//---------------------------------------------------------------------------

template<class LowLevel>
class LinuxSystemIface : public ISystemIface, public IFdHandler
{
public:
  IOScheduler* scheduler;
  LinuxAddressFactory<LowLevel>* addressFactory;
  IPacketReceiver* packetReceiver;
  Address address;
  char* strOutputAddress;
  unsigned int port;
  unsigned int recvPort;

  LinuxSystemIface(char* aIfaceName, Address aAddress, int aIfaceIndex,
		   IOScheduler* aScheduler,
		   LinuxAddressFactory<LowLevel>* aFactory,
		   string aStrOutputAddress, 
		   IfaceConfig* aIfaceConfig, 
		   unsigned int aPort)
    : address(aAddress), packetReceiver(NULL), scheduler(aScheduler),
      addressFactory(aFactory), ifaceIndex(aIfaceIndex), name(aIfaceName),
      port(aPort), recvPort(0)

  {
    if (aIfaceIndex>=-100)
      recvPort = port;
    else recvPort = -aIfaceIndex;
    ifaceSocket = -1;
#ifdef LINK_MONITORING
    signalSocket = -1;
#endif
    associatedIface = NULL;
    strOutputAddress = strdup(aStrOutputAddress.c_str());
    ifaceConfig = aIfaceConfig;
  }

  virtual void openSocket(IPacketReceiver* aPacketReceiver)
  {
    packetReceiver = aPacketReceiver;
    // Create output socket.
    ifaceSocket = LowLevel::makeUDPSocket(); //ipv6MakeUDPSocket();
#ifdef LINK_MONITORING
    signalSocket = LowLevel::makeUDPSocket();
#endif
    typename LowLevel::SystemAddress ifaceSystemAddress;
    addressFactory->makeSystemAddress(address, ifaceSystemAddress);
    LowLevel::setSocketReuseAddr(ifaceSocket);
    LowLevel::setSocketMulticastDefaultIface(ifaceSocket, ifaceIndex, 
					     ifaceSystemAddress);
    LowLevel::joinMulticastGroup(ifaceSocket, name, ifaceIndex,
				 strOutputAddress);
    LowLevel::strToAddress(sendSystemAddress, strOutputAddress);
    LowLevel::setAddressPort(sendSystemAddress, port);

    typename LowLevel::SystemAddress anyOLSRPortAddress;
    addressFactory->makeSystemAddress(address, anyOLSRPortAddress);
    LowLevel::setAddressPort(anyOLSRPortAddress, recvPort);
    LowLevel::socketBind(ifaceSocket, anyOLSRPortAddress);

    scheduler->addFdHandler(this, NULL);
  }
  
  virtual void sendPacket(MemoryBlock* packet) 
  {
    // XXX! hack:
    if (ifaceIndex<-100) {
      unsigned char* newPacket = (unsigned char*) malloc(address.getNetSize() + packet->size);
      address.toNet(newPacket);
      memcpy(newPacket+address.getNetSize(), packet->data, packet->size);
      free(packet->data);
      packet->data = newPacket;
      packet->size += address.getNetSize();
    }

    LowLevel::socketSend(ifaceSocket, packet->data, packet->size, 
			 sendSystemAddress);
    delete packet; // XXX: check memory is freed
  }

#ifdef LINK_MONITORING
  int getSignalLevel(Address txAddress)
  {
    typename LowLevel::SystemAddress ifaceSystemAddress;
    addressFactory->makeSystemAddress(txAddress, ifaceSystemAddress);
    
    return LowLevel::recvSignalNoise(signalSocket,
				     associatedIface->getSystemIface(),
				     ifaceSystemAddress);
  }
#endif

  virtual int getMTU()
  { return ifaceConfig->mtu; }

  virtual Address getAddress()
  { return address; }


  // IFdHandler
  virtual FileDescriptor getFileDescriptor() { return ifaceSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; } // XXX:  check
  virtual void handleInput()
  {
    octet buffer[65536]; // XXX: not inline
    typename LowLevel::SystemAddress recvAddress;

    int maxSize = sizeof(buffer);
    int status = LowLevel::socketRecv(ifaceSocket, buffer, 
				      maxSize, recvAddress);
    if(status > 0) { // XXX: what if == 0, closed?
      MemoryBlock* packet = NULL;

      Address stdRecvAddress = addressFactory->makeAddress(recvAddress);

      // XXX! hack:
      if (ifaceIndex<-100) {
	stdRecvAddress = addressFactory->peekAddress(buffer);
	packet = new MemoryBlock(buffer+address.getNetSize(), 
				 status-address.getNetSize(), true);
      } else {
	packet = new MemoryBlock(buffer, status, true);
      }


      packetReceiver->evReceivePacket 
	(packet, stdRecvAddress, this->associatedIface);
    }
  }

  virtual void handleOutput() { Fatal("Impossible call"); }
  virtual void handleExcept() { Fatal("Impossible call"); }

  // borrowed
  char* getName() { return name; }

public:
  int ifaceIndex;

protected:
  typename LowLevel::SystemAddress sendSystemAddress;
  int ifaceSocket;
#ifdef LINK_MONITORING
  int signalSocket;
#endif
  char* name; // system name of the interface
};

//---------------------------------------------------------------------------

#if 0
void
int on;
  on=6;
  if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &on, sizeof (on)) < 0)
    Fatal("setsockopt SO_PRIORITY: " << strerror(errno));

#endif

//---------------------------------------------------------------------------

//#define USE_SYSTEM_IP_ROUTE // XXX: one bug still

class LinuxIPv6NetworkConfigurator : public INetworkConfigurator
{
public:
  typedef LinuxSystemIface<LinuxIPv6LowLevel> IPv6Iface;
  bool notFatal;

  LinuxIPv6NetworkConfigurator(LinuxAddressFactory<LinuxIPv6LowLevel>* 
			       aAddressFactory, bool aNotFatal)
    : addressFactory(aAddressFactory), notFatal(notFatal) { }

  LinuxAddressFactory<LinuxIPv6LowLevel>* addressFactory;

  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  {
#ifndef USE_SYSTEM_IP_ROUTE
    IPv6Iface* linuxIface = dynamic_cast<IPv6Iface*>(iface);
    LinuxIPv6LowLevel::addRoute(AF_INET6, linuxIface->ifaceIndex, 
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    actionRoute("add", iface, destIpAddress,
		gatewayAddress, netMaskAddress, metric);
#endif
  }
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric)
  {
#ifndef USE_SYSTEM_IP_ROUTE
    IPv6Iface* linuxIface = dynamic_cast<IPv6Iface*>(iface);
    LinuxIPv6LowLevel::removeRoute(AF_INET6, linuxIface->ifaceIndex, 
				   destIpAddress, gatewayAddress, 
				   netMaskAddress, metric, notFatal);
#else
    actionRoute("del", iface, destIpAddress,
		gatewayAddress, netMaskAddress, metric);
#endif
  }


  void actionRoute(char* actionName,
		   ISystemIface* iface, Address destIpAddress,
		   Address gatewayAddress, Address netMaskAddress, 
		   int metric)
  {
    Warn("XXX!: this is a hack");
    char command[4096]; // XXX!: check
    IPv6Iface* systemIface = 
      dynamic_cast<IPv6Iface*>(iface);

    struct sockaddr_in6 destIPv6Address;
    struct sockaddr_in6 gatewayIPv6Address;
    addressFactory->makeSystemAddress(destIpAddress, destIPv6Address);
    addressFactory->makeSystemAddress(gatewayAddress, gatewayIPv6Address);

    // XXX: another hack:
    char destStrAddress[4096]; // XXX
    char gatewayStrAddress[4096]; //XXX
    inet_ntop(AF_INET6, &destIPv6Address.sin6_addr, destStrAddress,
	      sizeof(destStrAddress));
    inet_ntop(AF_INET6, &gatewayIPv6Address.sin6_addr, gatewayStrAddress,
	      sizeof(gatewayStrAddress));

    if (metric == 1) {
      sprintf(command, "/bin/ip route %s %s metric %d dev %s", actionName,
	      destStrAddress, metric,
	      systemIface->getName());      
    } else {
      sprintf(command, "/bin/ip route %s %s via %s metric %d dev %s", 
	      actionName, destStrAddress, gatewayStrAddress, metric,
	      systemIface->getName());
    }

    //std::cerr << "addRoute: " << command << std::endl; // XXX!!
    system(command);
  }

};



void startHTTPServer(IOScheduler* scheduler, Node* node); // forward

#ifdef WITH_IPV6

class LinuxIPv6SystemFactory : public ISystemFactory
{
public:
  LinuxIPv6SystemFactory(ProtocolConfig* aProtocolConfig) 
    : protocolConfig(aProtocolConfig)
  {
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new LinuxIPv6NetworkConfigurator(&addressFactory,
        protocolConfig->ignoreRouteSetupError);
  }

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(const char* name, 
				       IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }
  
  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }

protected:
  LinuxAddressFactory<LinuxIPv6LowLevel> addressFactory;
  LinuxIPv6NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
  ProtocolConfig* protocolConfig;
};


//---------------------------------------------------------------------------

ISystemIface* LinuxIPv6SystemFactory::getIfaceByName(const char* name,
						     IfaceConfig* ifaceConfig)
{
  struct ifaddrs* ifap=NULL;
  char buf[BUFSIZ];
  
  memset(buf, 0, sizeof(buf));
  
  if (getifaddrs(&ifap) < 0) {
    return NULL;
  }

  for(struct ifaddrs* current = ifap;
      current != NULL; current = current->ifa_next) {
    if (current->ifa_addr == NULL)
      continue;
    
    if (current->ifa_addr->sa_family != AF_INET6)
      continue;
    if(strcmp(current->ifa_name, name) != 0)
      continue;

    char strAddress[NI_MAXHOST];
  
    if(getnameinfo(current->ifa_addr, sizeof(struct sockaddr_in6), strAddress,
		   sizeof(strAddress), NULL, 0, NI_NUMERICHOST) < 0)
      continue;

    if(strncmp(strAddress, "fec0:", strlen("fec0:")) != 0
       && strncmp(strAddress, "fd", strlen("fd")) != 0) // XXX
      continue;

    int resultIfaceIndex = if_nametoindex (name);
    Address ifaceAddress = addressFactory.makeAddress
      (*(sockaddr_in6*)current->ifa_addr);
    freeifaddrs(ifap);
    return new 
      LinuxSystemIface<LinuxIPv6LowLevel>
      ((char*)name, ifaceAddress,
       resultIfaceIndex,
       scheduler, &addressFactory,
       protocolConfig->ipv6MulticastAddress, ifaceConfig,
       protocolConfig->udpPort);
  }
  //current->ifa_addr;
  //current->ifa_netmask;
  //current->ifa_broadaddr;

  freeifaddrs(ifap);
  
  return NULL;
}

ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return new LinuxIPv6SystemFactory(protocolConfig); }

#else

ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }

#endif // WITH_IPV6

//---------------------------------------------------------------------------

#ifdef WITH_IPV4
#include "system_linux_ipv4_internal.h"
#endif

#define STR_IP_BROADCAST "255.255.255.255"

class LinuxIPv4LowLevel : public LinuxLowLevel
{
public:
  static const int AddressSize = 4; // XXX: correct one

  //  &ipv6Address.sin6_addr

  typedef sockaddr_in SystemAddress;

  static void* systemAddressToRawAddress(SystemAddress& systemAddress) {
    assert( systemAddress.sin_family == AF_INET );
    assert( sizeof(systemAddress.sin_addr) == AddressSize );
    return &systemAddress.sin_addr;
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin_family = AF_INET;
    memcpy(&resultAddress.sin_addr, rawAddress, AddressSize);
  }

  static void reprAddress(SystemAddress& address, char* result)
  { inet_ntop(AF_INET, &address.sin_addr, result, 4096 /*XXX!*/); }

  static int makeUDPSocket()
  {
    int sd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(SystemAddress& sockAddress, char* strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin_family = AF_INET;

    if (strGroupAddress == NULL)
      sockAddress.sin_addr.s_addr = INADDR_ANY; // XXX
    else inet_pton(AF_INET, strGroupAddress, &sockAddress.sin_addr);
  }

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin_port = htons(udpPort); }

  static void joinMulticastGroup(int sd, char* ifaceName, 
				 int ifaceIndex, char* strGroupAddress)
  {
    struct ip_mreqn mreq;
    if (!strcmp(strGroupAddress, STR_IP_BROADCAST)) {
      // we don't actually "join" in this case
      setSocketBroadcast(sd);
      char* tmpIfaceName = strdup(ifaceName);
      setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, tmpIfaceName,
		 strlen(tmpIfaceName)+1);
      free(tmpIfaceName);

      return; 
    }

    //XXX! hack
    if (ifaceIndex < -100)
      return;
	  	  
    memset (&mreq, 0, sizeof (mreq));
    inet_pton(AF_INET, strGroupAddress, &mreq.imr_multiaddr);
    mreq.imr_ifindex = ifaceIndex;
    //XXX: set imr_address
    
    if(setsockopt(sd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal(" setsockopt IP_ADD_MEMBERSHIP: " << strerror(errno) );
  }

  // http://www.tldp.org/HOWTO/Multicast-HOWTO-6.html
  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    // XXX: hack
    if (ifaceIndex < -100)
      return;

    if (setsockopt(sd, IPPROTO_IP, IP_MULTICAST_IF, &ifaceAddress.sin_addr,
		   sizeof(ifaceAddress.sin_addr)) < 0)
      Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );
  }

  //XXX: redundant with IPv6, should be templatized
  static void socketBind(int sd, SystemAddress& address)
  {
    address.sin_addr.s_addr = INADDR_ANY; // XXX!! kludge
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) { // XXX: warning
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }


  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Warn(" sendto: " << strerror(errno) );// XXX: not fatal
  }

#ifdef LINK_MONITORING
  static int recvSignalNoise(int sd, ISystemIface* iface,
			     SystemAddress txAddress)
  {
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;

    return get_interface_signal(sd, ipv4Iface->getName(), txAddress);
  }
#endif

};



typedef LinuxAddressFactory<LinuxIPv4LowLevel> LinuxIPv4AddressFactory;

#ifdef WITH_IPV4
class LinuxIPv4NetworkConfigurator : public INetworkConfigurator
{
public:
  int skfd; bool notFatal;

  typedef LinuxSystemIface<LinuxIPv4LowLevel> IPv4Iface;

  LinuxIPv4NetworkConfigurator(LinuxIPv4AddressFactory* aAddressFactory,
			       int aSkfd, bool aNotFatal) 
    : skfd(aSkfd), addressFactory(aAddressFactory), notFatal(aNotFatal) { }


  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric)
  {
#ifndef USE_KERN_ADD_ROUTE
    IPv4Iface* linuxIface = dynamic_cast<IPv4Iface*>(iface);
    LinuxIPv4LowLevel::addRoute(AF_INET, linuxIface->ifaceIndex,
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    int status = KERN_add_route_IPV4(skfd, 
				     &destSysAddr.sin_addr,
				     &gatewaySysAddr.sin_addr,
				     0, 
				     0, //0xffffffffu, // XXX! real mask
				     metric, ipv4Iface->getName());
    if (status < 0)
      Fatal("KERN_add_route: " << strerror(errno) ); // XXX: not fatal
#endif
  }
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric)
  {
#ifndef USE_KERN_ADD_ROUTE
    IPv4Iface* linuxIface = dynamic_cast<IPv4Iface*>(iface);
    LinuxIPv4LowLevel::removeRoute(AF_INET, linuxIface->ifaceIndex,
				destIpAddress, gatewayAddress, 
				netMaskAddress, metric, notFatal);
#else
    sockaddr_in destSysAddr;
    sockaddr_in gatewaySysAddr;
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;
    addressFactory->makeSystemAddress(destIpAddress, destSysAddr);
    addressFactory->makeSystemAddress(gatewayAddress, gatewaySysAddr);
    int status = KERN_del_route_IPV4(skfd, 
				     &destSysAddr.sin_addr,
				     &gatewaySysAddr.sin_addr,
				     0, 
				     0, //0xffffffffu, // XXX! real mask
				     metric, ipv4Iface->getName());
    if (status < 0)
      Fatal("KERN_del_route: "); // XXX: not fatal
#endif
  }

  LinuxIPv4AddressFactory* addressFactory;
};


class LinuxIPv4SystemFactory : public ISystemFactory
{
public:
  int skfd;

  LinuxIPv4SystemFactory(ProtocolConfig* aProtocolConfig) 
    : protocolConfig(aProtocolConfig)
  {
    skfd = LinuxIPv4LowLevel::makeUDPSocket();
    upd_interfaces(skfd);
    baseScheduler = new SimulationScheduler;
    scheduler = new IOScheduler(baseScheduler);
    baseScheduler->setTime(scheduler->getTime());
    networkConfigurator = new LinuxIPv4NetworkConfigurator
      (&addressFactory, skfd, protocolConfig->ignoreRouteSetupError);
  }

  virtual AddressFactory* getAddressFactory() 
  { return &addressFactory; }

  virtual ISystemIface* getIfaceByName(const char* name,
				       IfaceConfig* ifaceConfig);

  virtual INetworkConfigurator* getNetworkConfigurator()
  { return networkConfigurator; }

  virtual IScheduler* getScheduler()
  { return scheduler; }

  virtual void visitNode(Node* node)
  { startHTTPServer(scheduler, node); }
  
protected:
  LinuxIPv4AddressFactory addressFactory;
  LinuxIPv4NetworkConfigurator* networkConfigurator;
  IOScheduler* scheduler;
  SimulationScheduler* baseScheduler;
  ProtocolConfig* protocolConfig;
};

//ystemFactory* getSystemFactory()
//return new LinuxSystemFactory<LinuxIPv6LowLevel>; }

extern vector<string> stringSplit(string& aLine, string& charSet);

ISystemIface* LinuxIPv4SystemFactory::getIfaceByName(const char* name,
						     IfaceConfig* ifaceConfig)
{
  if (!strncmp("pseudo:", name, strlen("pseudo:"))) {

    string cxxname = name;
    cxxname.erase(0, strlen("pseudo:"));
    string comma = ",";
    vector<string> info = stringSplit(cxxname, comma);
    if (info.size() != 4)
      Fatal("Invalid pseudo interface name: " << name);
    //info[0];
    //int(info[1])
    string ifaceName = "pseudo:";
    ifaceName += info[0];
    ifaceName += ",";
    ifaceName += info[1];
      

    unsigned int srcPort = atoi(info[1].c_str());

    string destAddress = info[2];
    unsigned int destPort = atoi(info[3].c_str());

#ifdef WITH_IPV6
    sockaddr_in sockAddress;
    memset(&sockAddress, 0, sizeof(sockAddress));
    //sockAddress.sin6_family = AF_INET6;
    sockAddress.sin_family = AF_INET;
    inet_pton(AF_INET, info[0].c_str(), &sockAddress.sin_addr);
    Address ifaceAddress = addressFactory.makeAddress(sockAddress);

    return new
      LinuxSystemIface<LinuxIPv4LowLevel>((char*)ifaceName.c_str(), 
					  ifaceAddress,
					  -srcPort, // ifaceIndex - hack
					  scheduler, &addressFactory,
					  strdup(destAddress.c_str()),
					  ifaceConfig,
					  destPort);
#else
    Fatal("XXX: no pseudo interfaces");
#endif
  }

  int ifaceNum = interf_name_to_num((/*XXX*/char*)name); // XXX: check it linux
  if (ifaceNum<0) 
    Fatal("Cannot find interface index for iface "<<name);
  describe_interface* ifaceInfo = get_interf_by_num (ifaceNum, -1);
  int ifaceIndex = if_nametoindex (name);
    
  Address ifaceAddress = addressFactory.makeAddress(ifaceInfo->ip_addr);

  // interface index
  if (ifaceIndex<0) 
    Fatal("Cannot find interface index for iface "<<name);
  
  return new 
    LinuxSystemIface<LinuxIPv4LowLevel>((char*)name, ifaceAddress, ifaceIndex,
					scheduler, &addressFactory,
					protocolConfig->ipv4MulticastAddress,
					ifaceConfig,
					protocolConfig->udpPort);
}

ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return new LinuxIPv4SystemFactory(protocolConfig); }

#else

ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }

#endif // WITH_IPV4

//---------------------------------------------------------------------------

#ifdef WITH_HTTPSERVER // XXX: this is a hack
IHTTPServer* httpServer = NULL;
extern IHTTPServer* makeHTTPServer();

#include "node.h" // XXX
void startHTTPServer(IOScheduler* scheduler, Node* node)
{
  httpServer = makeHTTPServer();
  httpServer->open(scheduler, node->getProtocolConfig()->httpAdminPort,
		   new ProtocolHTTPVisitor(node) /*XXX: leak*/);
}
#else // !WITH_HTTPSERVER
void startHTTPServer(IOScheduler* scheduler, Node* node)
{ /* do nothing */ }
#endif // WITH_HTTPSERVER

//---------------------------------------------------------------------------
