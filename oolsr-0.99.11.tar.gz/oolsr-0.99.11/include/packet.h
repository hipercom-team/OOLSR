//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _PACKET_H
#define _PACKET_H

//---------------------------------------------------------------------------

#include <list>

#include "tuple.h"
#include "address.h"
#include "network_generic.h"
#include "protocol_config.h"

//---------------------------------------------------------------------------
/// The exception thrown when the packet is not correct.
class PacketFormatError
{ 
};

//---------------------------------------------------------------------------
/// Utility class to format packets: pack/unpack data.
class PacketBuffer
{
public:
  PacketBuffer() : data(NULL), first(0), count(0), capacity(0),
		   addressFactory(NULL) {}
  PacketBuffer(MemoryBlock& memoryBlock,
	       AddressFactory* aAddressFactory=NULL) 
    : data(NULL), first(0), count(0), capacity(0),
      addressFactory(aAddressFactory)
  {
    _realloc(memoryBlock.size);
    count = memoryBlock.size;
    memcpy(data, memoryBlock.data, count);
  }

  void rewind()
  { count += first; first = 0; }

  int size() { return count; }

  int sizeUInt8() { return 1; }
  int sizeUInt16() { return 2; }

  int popUInt16()
  { 
    int result=(int)data[first+1]+(((int)data[first])<<8); 
    consume(2); 
    return result;
  }

  void pushUInt16(int value)  
  { 
    assert( 0<=value && value<(1<<16) );
    _ensure(2);
    data[first] = value>>8;
    data[first+1] = value&0xff;     
    first += 2;
    if(count>0) 
      count -= std::min(count, 2);
  }

  int popUInt8()
  {
    int result=(int)data[first];
    consume(1);
    return result;
  }

  void pushUInt8(int value)
  {
    assert( 0<=value && value<(1<<8) );
    _ensure(1);
    data[first] = value;
    first++;
    if(count>0) 
      count--;
  }
   
  void popSubBuffer(int amount, PacketBuffer& result)
  {
    result._free();
    result._realloc(amount);
    result.first = 0;
    result.count = amount;
    result.addressFactory = addressFactory;
    memcpy(result.data, data+first, amount);
    consume(amount);
  }

  MemoryBlock* popBlock(int amount)
  {
    MemoryBlock* result = new MemoryBlock(data+first, amount, true);
    consume(amount);
    return result;
  }

  Address popAddress()
  { 
    Address result = addressFactory->peekAddress(data+first);
    consume(addressFactory->getAddressSize());
    return result;
  }

  void packAddress(Address address)
  {
    int addressSize = address.getNetSize();
    _ensure(addressSize);
    address.toNet(data+first);
    first += addressSize;
  }

  void consume(int byteCount)
  { 
    first += byteCount; 
    count -= byteCount;
    if (count<0)
      throw PacketFormatError();
  }

  void raiseWarning(char* message) { Warn("Warning:" << message); }
  void raiseError(char* message) { Warn("Error: " << message); }

  void crop(int newCount)
  {
    assert(newCount <= count);
    count = newCount;
  }

  int offset() { return first; }

  void packBlock(MemoryBlock* borrowedBlock)
  { packData(borrowedBlock->data, borrowedBlock->size); }

  void packData(void* moreData, int dataSize)
  {
    _ensure(dataSize);
    memcpy(data+first, moreData, dataSize);
    first += dataSize;
    if(count>0) 
      count -= std::min(count, dataSize);
  }

  int getPosition()
  { assert(count == 0); return first; }
  
  int getSizeFrom(int initialPosition)
  { assert(count == 0); return first - initialPosition; }

  void setPosition(int position)
  { count += (first - position); first = position; }

  MemoryBlock* getContent()
  { return new MemoryBlock(data+first, count, true); }

  ~PacketBuffer()
  { _free(); }

protected:
  
  PacketBuffer(const PacketBuffer& other)
  { Fatal("impossible"); }

  void _realloc(int newSize=-1)
  {
    if (newSize == -1) newSize=capacity*2+16;
    octet* newData = new octet [newSize];
    memcpy(newData, data, first+count);
    if (data!=NULL) delete [] data;
    data = newData;
    capacity = newSize;
  }
  
  void _free()
  {
    if(data!=NULL)
      delete [] data;
    data = NULL; 
    capacity=0;
  }

  void _ensure(int freeSpace)
  {
    while(first+freeSpace>capacity)
      _realloc();
  }
  
  octet* data;
  int first;
  int count;
  int capacity;  

  AddressFactory* addressFactory;
};

//---------------------------------------------------------------------------

class Message;

class IMessageContent
{
public:
  Message* header;

public:
  /// (internal) Makes a copy of the message.
  virtual IMessageContent* clone() = 0; 

  /// Get the base message
  virtual Message* getMessage() { return header; }

  /// Write the message content
  virtual void write(std::ostream& out) const = 0;



  virtual void destroy(bool deleteHeader);

  virtual ~IMessageContent() { destroy(true); }
};

typedef enum {
  ReceivedMessage,
  GeneratedMessage,
  NoOrigin
} MessageOrigin;

const int NoMessageSequenceNumber = -1;

/// An OLSR message.
/// XXX: this documentation was not reviewed/updated
/// Normally one and only one of the fields packedContent and content
/// will be not NULL and the other will be NULL. This corresponds 
/// to two different cases: when packedContent is not NULL, the packet
/// was usually received, and was not parsed yet ; this is used for
/// forwarding. The other case is a locally generated message, not yet
/// converted to network format (sequence of bytes). Usually, when
/// in the code, a message is expected to have a content != NULL,
/// a reference to a IMessageContent is used (and the message header
/// itself can be retrieved from getMessage()).
class Message
{
public:
  /// The fields of the OLSR message
  MessageType messageType;
  int vtime;
  int messageSize; // (filled by MessageHandler)
  Address originatorAddress;
  int timeToLive;
  int hopCount;
  int messageSequenceNumber;

  int minMessageSize; // (filled by MessageHandler)

  /// Additional field used when receiving: sender interface address
  Address sendIfaceAddress;
  ///  Additional field used when receiving: receiving interface address
  Address recvIfaceAddress;

  /// The message content in network form
  MemoryBlock*     packedContent;

  /// The message content in high level form (HelloMessage, etc...)
  IMessageContent* content;

public:
  /// Constructors
  Message() : messageSize(-1), minMessageSize(-1), packedContent(NULL),
	      content(NULL), maxTime(0) {}

  Message(MessageType aMessageType, int aVTime, 
	  Address aOriginatorAddress, 
	  int aTimeToLive, int aHopCount) //, int aMessageSequenceNumber)
    : messageType(aMessageType), vtime(aVTime),
      originatorAddress(aOriginatorAddress), timeToLive(aTimeToLive),
      hopCount(aHopCount), messageSequenceNumber(NoMessageSequenceNumber),
      messageSize(-1), minMessageSize(-1), origin(NoOrigin), 
      packedContent(NULL), content(NULL), maxTime(0) {}

  /// Destructor
  ~Message() 
  {
    if (content != NULL) {
      content->destroy(false);
      delete content;
      //content = NULL;
    }
    if (packedContent != NULL) {
      delete packedContent;
      //packedContent = NULL;
    }
  }

  /// Makes a copy of the message
  Message* clone(bool withPackedContent = true);



  /// Return the validity time, decoded from the 'vtime' attribute
  Time getValidityTime()
  { return fromMantissaExponentByte(vtime); }

  int getMessageSize()
  { 
    if(messageSize <0 && packedContent != NULL)
      messageSize = packedContent->size
	+ MessageHeaderWithoutAddressSize
	+ originatorAddress.getNetSize();
    assert(messageSize>=0);
    return messageSize;
  }

  //--------------------------------------------------

  MessageOrigin origin;

  /// The maximum acceptable time, before the message gets emitted
  Time maxTime;
};

inline std::ostream& operator << (std::ostream& out, const IMessageContent& m)
{ m.write(out); return out; }

inline void writeMessage(std::ostream& out, const Message& m, 
			 bool withContent = true)
{
  out << "MSG[type=" << messageTypeToString(m.messageType) << "(" 
      << m.messageType << ") vtime=" << fromMantissaExponentByte(m.vtime)
      << "(" << m.vtime << ") size=" << m.messageSize << " origin="
      << m.originatorAddress << " ttl=" << m.timeToLive 
      << " hop=" << m.hopCount
      << " mseq=" << m.messageSequenceNumber << " minSize=" << m.minMessageSize
      << " sendAddress="  << m.sendIfaceAddress << " recvAddress="
      << m.recvIfaceAddress;
  if (withContent) {
    if(m.content != NULL)
      out << " content=(" << *m.content <<")";
    else if (m.packedContent != NULL)
      out << " packedContent=(" << *m.packedContent << ")";
  }
  out << "]";
}

inline std::ostream& operator << (std::ostream& out, const Message& m)
{ 
  writeMessage(out, m);
  return out;
}

//---------------------------------------------------------------------------

class PacketManager;
class PacketBuffer;

/// A IMessageHandler as the responsibility of doing message-type specific
/// steps in message processing/handling. PacketManager is doing the 
/// message-independant processing.
/// In perticular, the PacketManager knows how to pack/parse the Message header
/// but not the content of the message (HELLO link lists, etc...)
class IMessageHandler
{
public:
  /// Process the message (the content). Normally will call the proper
  /// message handling method of Node. (message is borrowed)
  virtual void processMessage(/*borrowed*/ Message* message) = 0;

  // Send a message to each of the ifaceList
  //virtual void sendMessage(std::list<OLSRIface*>* ifaceList,
  // Message* message) = 0;

  /// Possibly forward the message. Some message (such as HELLO) are not
  /// forwarded, in which case nothing is done, otherwise, using
  /// PacketManager helper function, the message can be forwarded
  /// (message is borrowed)
  /// Will return true iff the message is forwarded
  virtual void considerForwardMessage(/*borrowed*/ Message* message,
				      string& info) = 0;

  /// Parse the message in a message specific-way ; i.e. parse the content
  /// in 'message.packedContent' into a proper value in 'message.content'
  /// and return this last value.
  virtual IMessageContent* parseMessageContent(Message* message) = 0;

  /// XXX: possibly obsolete doc warning!
  /// Perform the opposite of parseMessageContent: given a message,
  /// with a proper message.content field, the message.content is transformed
  /// into network format (a sequence of bytes), into 'message.packedContent'.
  /// The operation is here complicated by the maximum message size:
  /// - the result is stored in messageResult, which should be a newly 
  /// created instance of Message (with messageResult.content == NULL)
  /// - if there wasn't enough space to fully fill the message,
  /// the remaining information should be in a newly created instance
  /// of IMessageHandler, holding the remaining information. In this case
  /// a new messageSequenceNumber must be allocated. If there was enough
  /// space *messageRemainingResult must be set to NULL.
  /// - if the packing fails, *messageResult and *messageRemainingResult
  /// must be set to NULL, and the message will be discarded.
  virtual void packMessageContent(IMessageContent* message,
				  int maximumMessageSize,
				  MemoryBlock*& packedResult,
				  IMessageContent*& messageRemainingResult)=0;


  virtual void adjustMessageSize(IMessageContent* message) = 0;
};

//---------------------------------------------------------------------------

class LinkEntry
{
public:
  LinkType     linkType;
  NeighborType neighborType;
  Address      address;
};

const int HelloHeaderSize = 4; // @@1523
const int HelloLinkMessageHeaderSize = 4; // @@1525

class HelloMessage : public IMessageContent
{
public:
  int reserved;
  int htime;
  int willingness;
  std::list<LinkEntry> linkList; /// (owned) the list of link entries

  /// Makes a copy of the message.
  virtual IMessageContent* clone()
  { 
    HelloMessage* result = new HelloMessage;
    result->reserved = reserved;
    result->htime = htime;
    result->willingness = willingness;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<LinkEntry> > ii(result->linkList,
						    result->linkList.begin());
    std::copy(linkList.begin(), linkList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(std::ostream& out) const
  {
    out << "hello reserved=" << reserved << " htime="
	<< fromMantissaExponentByte(htime) << "(" << htime << ")"
	<< " willing=" << willingness << " link=";
    for(std::list<LinkEntry>::const_iterator it = linkList.begin();
	it != linkList.end(); it++) {
      if (it != linkList.begin()) out << ",";
      out << neighborTypeToString((*it).neighborType) << "+" 
          << linkTypeToString((*it).linkType)
	  << ":" << (*it).address;
    }
  }

  void addLinkEntry(LinkType linkType, NeighborType neighborType,
		    Address address)
  {
    LinkEntry linkEntry;
    linkEntry.linkType = linkType;
    linkEntry.neighborType = neighborType;
    linkEntry.address = address;
    linkList.push_back(linkEntry);
  }
};

class Node;

class HelloMessageHandler : public IMessageHandler
{
public:
  HelloMessageHandler(Node* aNode) : node(aNode) {}

  virtual void processMessage(Message* message);

  virtual void considerForwardMessage(Message* message, string& info)
  { /* no forwarding - @@1803-1807 */ } 

  virtual IMessageContent* parseMessageContent(Message* message);

  int internalGetMessageSize(HelloMessage* m, 
			     std::list<Address>* resultList=NULL);

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& messageResult,
				  IMessageContent*& messageRemainingResult);

  virtual void adjustMessageSize(IMessageContent* message);

protected:
  Node* node;
};


//---------------------------------------------------------------------------

class MIDMessage : public IMessageContent
{
public:
  std::list<Address> addressList; /// (owned) a list of addresses

  virtual IMessageContent* clone()
  {
    MIDMessage* result = new MIDMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<Address> > ii(result->addressList,
						  result->addressList.begin());
    std::copy(addressList.begin(), addressList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(std::ostream& out) const
  {
    out << "mid "
	<< " address=";
    for(std::list<Address>::const_iterator it = addressList.begin();
	it != addressList.end(); it++) {
      if (it != addressList.begin()) out << ",";
      out << (*it);
    }
  }
};


//---------------------------------------------------------------------------

const int TCHeaderSize = 4; // @@XXX

class TCMessage : public IMessageContent
{
public:
  unsigned int ansn;
  unsigned int reserved;
  std::list<Address> addressList; /// (owned) a list of addresses

  void clearList() { addressList.clear(); }

  virtual IMessageContent* clone()
  {
    TCMessage* result = new TCMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    result->ansn = ansn;
    result->reserved = reserved;
    std::insert_iterator< std::list<Address> > ii(result->addressList,
						  result->addressList.begin());
    std::copy(addressList.begin(), addressList.end(), ii);
    return result;
  }

  /// Write the message content
  virtual void write(std::ostream& out) const
  {
    out << "tc ansn=" << ansn << " reserved=" << reserved
	<< " address=";
    for(std::list<Address>::const_iterator it = addressList.begin();
	it != addressList.end(); it++) {
      if (it != addressList.begin()) out << ",";
      out << (*it);
    }
  }
};

class TCSpecification
{
public:
  typedef TCMessage MessageContent;
  typedef Address MessageItem;
  static int getContentHeaderSize() { return TCHeaderSize; }
  static int getItemSize(int addressSize) { return addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer)
  {
    result->ansn = buffer.popUInt16();
    result->reserved = buffer.popUInt16();
  }
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { result->addressList.push_back( buffer.popAddress() ); }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer)
  {
    buffer.pushUInt16(m->ansn); // @@XXX
    buffer.pushUInt16(m->reserved); // @@XXX
  }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { buffer.packAddress(item); }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->addressList; }
};

class MIDSpecification
{
public:
  typedef MIDMessage MessageContent;
  typedef Address MessageItem;
  static int getContentHeaderSize() { return 0; }
  static int getItemSize(int addressSize) { return addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) { }
  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { result->addressList.push_back( buffer.popAddress() ); }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { buffer.packAddress(item); }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->addressList; }
};

//---------------------------------------------------------------------------

template <class MessageSpecification>
class GenericMessageHandler : public IMessageHandler
{
public:
  typedef typename MessageSpecification::MessageContent MessageContent;
  typedef typename MessageSpecification::MessageItem MessageItem;
  typedef typename std::list<typename MessageSpecification::MessageItem> 
  MessageItemList;

  GenericMessageHandler(Node* aNode) : node(aNode) {}

  virtual void processMessage(Message* message);

  virtual void considerForwardMessage(Message* message, string& info);

  virtual IMessageContent* parseMessageContent(Message* message);

  virtual void packMessageContent(IMessageContent* message, 
				  int maximumMessageSize,
				  MemoryBlock*& blockResult,
				  IMessageContent*& messageRemainingResult);

  virtual void adjustMessageSize(IMessageContent* message);

protected:
  Node* node;
};

typedef GenericMessageHandler<TCSpecification> TCMessageHandler;

typedef GenericMessageHandler<MIDSpecification> MIDMessageHandler;

//---------------------------------------------------------------------------
// HNA Messages
//---------------------------------------------------------------------------

class HNAEntry
{
public:
  Address address;
  Address addressMask;
};

class HNAMessage : public IMessageContent
{
public:
  std::list<HNAEntry> hnaEntryList; /// (owned) a list of addresses


  virtual IMessageContent* clone()
  {
    HNAMessage* result = new HNAMessage;
    result->header = header->clone(false); 
    result->header->content = result;
    std::insert_iterator< std::list<HNAEntry> > it(result->hnaEntryList,
					       result->hnaEntryList.begin());
    std::copy(hnaEntryList.begin(), hnaEntryList.end(), it);
    return result;
  }

  /// Write the message content
  virtual void write(std::ostream& out) const
  {
    out << "hna address=";
    for(std::list<HNAEntry>::const_iterator it = hnaEntryList.begin();
	it != hnaEntryList.end(); it++) {
      if (it != hnaEntryList.begin()) out << ",";
      out << (*it).address << "/" << (*it).addressMask;
    }
  }
};

class HNASpecification
{
public:
  typedef HNAMessage MessageContent;
  typedef HNAEntry MessageItem;
  static int getContentHeaderSize() { return 0; }
  static int getItemSize(int addressSize) { return 2*addressSize; }
  static void process(Node* node, MessageContent* m);
  static void parseMessageContentHeader(MessageContent* result,
					PacketBuffer& buffer) { }

  static void parseMessageItem(MessageContent* result,
			       PacketBuffer& buffer)
  { 
    HNAEntry entry;
    entry.address = buffer.popAddress();
    entry.addressMask = buffer.popAddress();
    result->hnaEntryList.push_back( entry ); 
  }
  
  static void packMessageContentHeader(MessageContent* m,
				       PacketBuffer& buffer) { }
  static void packMessageItem(MessageItem& item, PacketBuffer& buffer)
  { 
    buffer.packAddress(item.address); 
    buffer.packAddress(item.addressMask); 
  }
  static std::list<MessageItem>& getList(MessageContent* m) 
  { return m->hnaEntryList; }
};

typedef GenericMessageHandler<HNASpecification> HNAMessageHandler;

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

class MessageQueue
{
public:
  /// messages waiting to be delivered
  std::list<Message*> queue;
};

/// An OLSR Interface (as opposed to a system interface)
class OLSRIface
{
public:  
  OLSRIface(Node* aNode, ISystemIface* aSystemIface) 
    : node(aNode), iface(aSystemIface), buffer(NULL), nextSequenceNumber(0) 
  { iface->setOLSRIface(this); }

  ISystemIface* getSystemIface()
  { return iface; }

  IfaceConfig* getConfig()
  { return iface->getConfig(); }

  /// allocate a new packet sequence number (by incrementation)
  int allocateSequenceNumber()
  { 
    int result = nextSequenceNumber;  // @@XXX wrap around
    nextSequenceNumber = (nextSequenceNumber + 1) % MaxPacketSequenceNumber;
    return result;
  }

  Address getAddress();

  /// MTU of the OLSRIface - this is MTU of a packet being sent.
  /// Ensures: this doesn't change.
  int getMTU();

  /// actually send a packet. 
  void sendPacket(MemoryBlock* packet);

#ifdef LINK_MONITORING
  int getSignalLevel(Address txAddress)
  {
    return iface->getSignalLevel(txAddress);
  }
#endif
  /// Send a message on the local message queue
  //void sendMessageOnLocalQueue(Message* message)
  //{ localMessageQueue->queue.push_back(message); }


  int getFreeSpace()
  {
    if (buffer == NULL)
      prepareBuffer();
    return getMTU() - buffer->offset();
  }

  void appendBlock(MemoryBlock* block) // borrowed
  {
    if (getFreeSpace() < block->size)
      flushPacket();
    if (buffer == NULL)
      prepareBuffer();
    buffer->packBlock(block);
  }

  void flushPacket();

  ~OLSRIface()
  {
    if(buffer != NULL) {
      delete buffer;
      buffer = NULL;
    }
  }
	
protected:
  Node* node;

  /// The actual interface
  ISystemIface* iface;

  PacketBuffer* buffer;

  void prepareBuffer()
  { 
    assert(buffer==NULL);
    buffer = new PacketBuffer; 
    buffer->pushUInt16(0); // @@XXX
    buffer->pushUInt16(0); // size: to be completed
    assert( buffer->offset() == PacketHeaderSize );
  }

  int nextSequenceNumber;
};

//---------------------------------------------------------------------------

class Node;

class MessageAndIface
{
public:
  Message* message;
  OLSRIface* iface; // NULL means all ifaces.
};

class PacketManager
{
public:
  PacketManager(Node* aNode);

  /// Returns the global message queue of the OLSR interfaces
  /// (this can be also obtained from one OLSR interface).
  /// The local message queue of one OLSR interface is obtained via
  /// the associated OLSRIface.
  std::list<MessageAndIface>* queue;
  
  /// Allocate a new message sequence number (by incrementing the counter)
  /// Returns a value which fits in 16 bits, as demanded in OLSR specification
  int allocateMessageSequenceNumber();

  /// Send a message to all the OLSR interface (it will end up in the 
  /// global queue).
  void sendMessageToAll(Message* message)
  { sendMessage(NULL, message); }

  /// Send a message to one the OLSR interface. It will end up in the local
  /// queue, so it should be either:
  /// - not splittable
  /// - sent only on one interface
  /// - such that you really really know what you what you are doing.
  /// (if iface == NULL, the above doesn't apply, see sendMessageToAll instead)
  void sendMessage(OLSRIface* iface, Message* message);

  void notifyMessageQueuing();

  /// Send a message which is already in serialized form (message.packedContent
  /// is different of NULL) to all OLSR interfaces.
  void sendPackedMessageToAll(/*owned*/ Message* message) 
  { 
    MessageAndIface messageAndIface;
    messageAndIface.message = message;
    messageAndIface.iface = NULL;
    queue->push_back(messageAndIface);
    notifyMessageQueuing();
  }

  /// Send a message which is already in serialized form (message.packedContent
  /// is different of NULL) to one OLSR interface.
  void sendPackedMessage(OLSRIface* iface, /*owned*/ Message* message)
  { 
    MessageAndIface messageAndIface;
    messageAndIface.message = message;
    messageAndIface.iface = iface;
    queue->push_back(messageAndIface);
    notifyMessageQueuing();
  }

  /// This is the entry point where the processing of packet begans
  /// (rawPacket is owned)
  void processPacket(Address sendIfaceAddress, Address recvIfaceAddress,
                     MemoryBlock* rawPacket);

  /// An utility function for IMessageHandler (especially 
  /// IMessageHandler::considerForwardMessage) ; this implement the default
  /// forwarding of the OLSR specification.
  /// (message is borrowed)
  void defaultForwardingMessage(Message* message, string& info);

  /// Pack messages awaiting in the global message queue into one packet
  /// on each interface. 
  /// - If there is not enough room (MTU), and if possible, the last
  ///   global message will be split
  /// - If there is enough room (MTU), then for each interface, the
  ///   messages of the local queue are appended, and if necessary
  ///   split.
  void packMessageQueue();

  // A utility function
  //XXX parsePacket(Address sendIfaceAddress, Address recvIfaceAddress,
  // MemoryBlock* rawPacket);

  // A utility function
  // IMessageContent* parseMessage(Message* message);

  typedef struct {
    int sizeFieldPosition;
    int messageStartPosition;
  } PositionInfo;

  PositionInfo packMessageHeader(PacketBuffer& buffer, Message* m)
  {
    PositionInfo result;
    result.messageStartPosition = buffer.getPosition();
    buffer.pushUInt8(m->messageType); // @@XXX
    buffer.pushUInt8(m->vtime);
    result.sizeFieldPosition = buffer.getPosition();
    //printf("packMessageHeader-BP1\n");
    buffer.pushUInt16(0); // size: 0 for now, overwriting later
    buffer.packAddress(m->originatorAddress);
    buffer.pushUInt8(m->timeToLive);
    buffer.pushUInt8(m->hopCount);
    if(m->messageSequenceNumber == NoMessageSequenceNumber) {
      assert( m->origin == GeneratedMessage );
      m->messageSequenceNumber= allocateMessageSequenceNumber();
    }
    //printf("packMessageHeader-BP2\n");
    buffer.pushUInt16(m->messageSequenceNumber);
    return result;
  }

  void adjustPackedMessageSize(PacketBuffer& buffer, PositionInfo info)
  {
    int actualSize = buffer.getSizeFrom(info.messageStartPosition);
    int endPosition = buffer.getPosition();
    buffer.setPosition(info.sizeFieldPosition);
    buffer.pushUInt16(actualSize);
    buffer.setPosition(endPosition);
  }


  void sendUpToTime(Time limitTime);
 
  void addMessageHandler(unsigned int messageType, IMessageHandler* handler);

protected:

  void appendPackedMessage(OLSRIface* iface,
			   /*owned*/ Message* newMessage);

  void packMessage(Message* message, int maximumMessageSize,
		   MemoryBlock*& newBlock, Message*& newMessage);

  void genericAppendMessage(OLSRIface* iface, Message* message, int minMTU);

  void appendBlockOnAllIface(MemoryBlock* block);
  int getIfaceMinFreeSpace();
  int getIfaceMinMTU();

  int getMessageHeaderSize();

  void parsePacket(PacketBuffer& packet,
		   std::list<Message*>& resultMessageList,
		   int& resultPacketSequenceNumber,
		   Address sendIfaceAddress,
		   Address recvIfaceAddress);

  Message* popMessage(PacketBuffer& packet,
		      Address sendIfaceAddress,
		      Address recvIfaceAddress);

  /// Monitor all links on which packets are receiving and 
  /// calculate their quality. This information is used
  /// in link sensing mechanism.
  void processLinkMonitoring(Address sendIfaceAddress, 
			     Address recvIfaceAddress, 
			     int packetSequenceNumber);

  Node* node;

  int nextMessageSequenceNumber; /// The next allocated sequence number

  IMessageHandler* messageHandler[MessageTypeLimit];
};




//---------------------------------------------------------------------------

#endif // _PACKET_H
