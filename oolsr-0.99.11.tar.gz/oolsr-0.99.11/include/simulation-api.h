//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file can be used in C and C++ programs
//---------------------------------------------------------------------------

#ifndef _SIMULATION_API_H
#define _SIMULATION_API_H

//---------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

//--------------------------------------------------

typedef void(*GetLinkFunction)(void* data,
			       int srcNodeIdx, int srcIfaceIdx,
			       int* resultCount,
				int** nodeIdxList, 
			       int** ifaceIdxList);

int doesRequirePlugin();
void initSimulation(char* pluginFileName, int aMaxNodeIndex);
void addNode(int nodeIndex, int nbIface, int mtu, 
	     void* configData, int configSize);
void addNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		 int dstNodeIdx, int dstIfaceIdx);
void removeNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		    int dstNodeIdx, int dstIfaceIdx);
void addDynamicLink(int srcNodeIdx, int srcIfaceIdx, 
		    GetLinkFunction getLinkFunction, void* data);
void removeDynamicLink(int srcNodeIdx, int srcIfaceIdx);
double getSimulationTime();
void runUntil(double maxTime);
void writeState(char* fileName, char* info);
void scheduleFunctionAt(double relativeTime, //XXX: useless cruft
			void(*f)(void*, void*, void*), void* data);

//--------------------------------------------------

void getSimulationStat(char** resultData, int* resultSize);

//--------------------------------------------------

#ifdef __cplusplus
} // end of extern "C"
#endif // __cplusplus

//---------------------------------------------------------------------------

#endif // _SIMULATION_API_H
