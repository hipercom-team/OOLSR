//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <sstream>

//--------------------------------------------------

#include "address.h"

//---------------------------------------------------------------------------

int Address::getNetSize() const
{ return factory->addressSize; }

int Address::getMaxTextSize() const
{ return factory->addressSize*10; }

Address::Address(AddressFactory* aFactory, RawAddress address)
{
  factory = aFactory;
  addressIndex = factory->addAddress(address);
}

std::ostream& operator << (std::ostream& out, const Address& address)
{ address.write(out); return out; }

void Address::write(std::ostream& out) const
{ 
  if(factory!= NULL)
    factory->write(out, *this);
  else out << "(null address)";
}

void Address::toNet(void* data) const
{
  void* rawAddress = factory->getAddress(addressIndex);
  memcpy(data, rawAddress, factory->addressSize);
}

void Address::toText(char* data) const
{
  std::ostringstream out;
  write(out);
  assert( strlen(out.str().c_str())+1 < getMaxTextSize() );
  strcpy(data, out.str().c_str());
}

RawAddress Address::getRawAddress() const
{ return factory->getAddress(addressIndex); }

string toText(Address address)
{
  int maxSize = address.getMaxTextSize();
  char* tmp = new char[maxSize+1];
  memset(tmp, 0, maxSize+1);
  address.toText(tmp);
  string result = tmp;
  delete [] tmp;
  return result;
}

//---------------------------------------------------------------------------
