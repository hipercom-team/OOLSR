//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <stdlib.h>
#include <dlfcn.h>

#include <iostream>

#include <protocol-plugin-api.h> // XXX: filename

//---------------------------------------------------------------------------

extern "C" int doesRequirePlugin()
{
  return 1;
}

extern "C" void loadPlugin(char* fileName, 
			   PPA_PlugeeApi* myApi, PPA_PluginApi** pluginApi)
{
  void* pluginLibrary = dlopen(fileName, RTLD_NOW);

  if(!pluginLibrary) {
    std::cerr << "load-plugin: cannot open library file '"
	      << fileName << "': " << dlerror() << std::endl;
    exit(EXIT_FAILURE);
  }

  PPA_ProtocolPluginApiInitFunc pluginInitFunc = 
    (PPA_ProtocolPluginApiInitFunc) dlsym(pluginLibrary, PPA_InitFunctionName);
  if(pluginInitFunc == NULL) {
    std::cerr << "load-plugin: cannot find init function in plugin\n";
    dlclose(pluginLibrary);
    exit(EXIT_FAILURE);
  }


  int status = pluginInitFunc(PPA_VERSION_MAJOR, PPA_VERSION_MINOR,
			      myApi, pluginApi);
  if (status != PPA_OK) {
    std::cerr << "load-plugin: init function of plugin returned FAILURE";
    dlclose(pluginLibrary);
    exit(EXIT_FAILURE);
  }
}

//---------------------------------------------------------------------------
