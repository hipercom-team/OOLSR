//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// parts from olsrdv7, olsr_python_extension.py
//---------------------------------------------------------------------------

#include "http_support.h"
#include "node.h"

//---------------------------------------------------------------------------

string strReplace(string data, string before, string after);

string HTMLReplyHeader =
"<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n"
"<html>\n"
"\n"
"<head><title>OOLSR Daemon management</title></head>\n"
"\n"
"<!-- Layout from http://www.python.org/ page, which comes from ht2html -->\n"
"<body bgcolor=\"#ffffff\" text=\"#000000\"\n"
"      marginwidth=\"0\" marginheight=\"0\"\n"
"      link=\"#0000bb\"  vlink=\"#551a8b\"\n"
"      alink=\"#ff0000\">\n"
"\n"
"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n"
"<!-- start of banner row -->\n"
"<tr>\n"
"<!-- start of corner cells -->\n"
"<td width=\"150\" valign=\"middle\" bgcolor=\"#003366\">\n"
"<center>\n"
"<a href=\"./\">\n"
"@<CORNER>@\n" // <- the html in the corner
"</a></center></td>\n"
"<td width=\"15\" bgcolor=\"#99ccff\">&nbsp;&nbsp;</td><!--spacer-->\n"
"<!-- end of corner cells -->\n"
"\n"
"<!-- start of banner -->\n"
"<td width=\"90%\" bgcolor=\"#99ccff\">\n"
"<!-- start of site links table -->\n"
"<table width=\"100%\" border=\"0\"\n"
"cellspacing=\"0\" cellpadding=\"0\"\n"
"       bgcolor=\"#ffffff\">\n"
"<tr>\n"
"@<BANNERLINKLIST>@\n" // <- the html in the banner
"</tr>\n"
"</table><!-- end of site links table -->\n"
"</td><!-- end of banner -->\n"
"</tr><!-- end of banner row -->\n"
"<tr><!-- start of sidebar/body row -->\n"
"\n"
"<!-- start of sidebar cells -->\n"
"<td width=\"150\" valign=\"top\" bgcolor=\"#99ccff\">\n"
"<!-- start of sidebar table -->\n"
"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"\n"
"       bgcolor=\"#ffffff\">\n"
"@<SIDELINKLIST>@\n" // <- the html on the side
"\n"
"\n"
"</table><!-- end of sidebar table -->\n"
"\n"
"</td>\n"
"<td width=\"15\">&nbsp;&nbsp;</td><!--spacer-->\n"
"<!-- end of sidebar cell -->\n"
"<!-- start of body cell -->\n"
"<td valign=\"top\" width=\"90%\"><br>\n";

string HTMLBannerLink = 
"<td bgcolor=\"#99ccff\" align=\"center\">\n"
"@<DATA>@\n"
"</td>\n";

string HTTPMovedReply = 
"HTTP/1.0 302 Moved Temporarily\n"
"Location: %s\n"
"Content-Type: text/html\n"
"\n"
"<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n"
"<HTML><HEAD>\n"
"<TITLE>302 Moved Temporarily</TITLE>\n"
"</HEAD><BODY>\n"
"<H1>Moved Temporarily</H1>\n"
"The document has moved <A HREF=\"@<LOCATION>@\">here</A>.<P>\n"
"</BODY></HTML>\n";

string HTMLSideTitle = 
"<tr><td bgcolor=\"#003366\"><b><font color=\"#ffffff\">\n"
"@<DATA>@\n"
"</font></b></td></tr>\n";

string HTMLSideLink = 
"<tr><td bgcolor=\"#99ccff\">\n"
"@<DATA>@\n"
"</td></tr>\n";

string HTMLLogoImg
  = "<img src=\"/serve/mprlogo3.png\" border=\"0\">";
string HTMLBannerImg
  = "<img src=\"/serve/oolsrd-plain.png\" border=\"0\">";

string HTTPReplyHeader = 
  "HTTP/1.1 200 OK\nContent-Type: text/html\r\n\r\n";

string sideTitle(string text)
{ return strReplace(HTMLSideTitle, "@<DATA>@", text); }

string sideLink(string text)
{ return strReplace(HTMLSideLink, "@<DATA>@", text); }

string getHTMLReplyHeader()
{
  string tmp1 
    = strReplace(HTMLReplyHeader, 
		 "@<BANNERLINKLIST>@",
		 strReplace(HTMLBannerLink,
			    "@<DATA>@",
			    HTMLBannerImg));
  string side = 
    sideLink("<a href=\"/\">Main</a>")
    +sideTitle("Tables")
    +sideLink("<a href=\"/internal/table/neighbor.html\">Neighbor</a>")
    +sideLink("<a href=\"/internal/table/topology.html\">Topology</a>")
    +sideLink("<a href=\"/internal/table/neighbor2.html\">Two hops</a>")
    +sideLink("<a href=\"/internal/table/route.html\">Route</a>")
    +sideLink("<a href=\"/internal/table/mpr.html\">MPR&amp;MPRS</a>")
    +sideLink("<a href=\"/internal/table/mid.html\">MID</a>")
    +sideLink("<a href=\"/internal/table/gateway.html\">Gateway</a>") 
    +sideLink("<a href=\"/internal/table/all.html\">All</a>")    
    +sideTitle("Internals")
    //#+sideLink("<a href="/info/config">Config</a>")
    +sideLink("<a href=\"/info/system\">System</a>")
    //#+sideLink("<a href=\"/info/table\">Raw tables</a>")
    +sideLink("<a href=\"/info/exception\">Exceptions</a>")
    //#+sideTitle(\"Command\")
    //#+sideLink("<a href=\"/restart\">Restart</a>")
    +sideTitle("Management")
    +sideLink("<a href=\"/internal/stat\">Stat</a>")    
    +sideLink("<a href=\"/internal/clock\">Clock</a>")
    +sideLink("<a href=\"/internal/capture\">Capture</a>")
    +sideLink("<a href=\"/internal/report\">Reporting</a>")
    +sideLink("<a href=\"/internal/attach\">Attachment</a>")
    +sideTitle("External links")
    +sideLink("<a href=\"http://hipercom.inria.fr/olsr/\">OLSR Page</a>");

  string tmp2 = strReplace(tmp1, "@<SIDELINKLIST>@", side);
  string tmp3 = strReplace(tmp2, "@<CORNER>@", HTMLLogoImg);
  return tmp3;
}

//---------------------------------------------------------------------------

class ProtocolHTTPVisitor : public IHTTPConnectionVisitor
{
public:
  ProtocolHTTPVisitor(Node* aNode) : node(aNode) {}

  virtual void visit(IHTTPConnection* connection)
  {
    //if (connection->
    serveIndex(connection);
  }


  void serveIndex(IHTTPConnection* connection)
  {
    string output = HTTPReplyHeader +
      getHTMLReplyHeader() + "<h1>OOLSR Daemon HTTP interface</h1>";
    connection->write(output);
    connection->close();
  }

  void serveAction(IHTTPConnection* connection)
  {
    string output = HTTPReplyHeader +
      getHTMLReplyHeader() + "<h1>ACTION!</h1>";
    connection->write(output);
    connection->close();
  }

protected:
  Node* node;
};

//---------------------------------------------------------------------------
