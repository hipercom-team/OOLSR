//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "general.h"
#include <vector>
#include <list>

//---------------------------------------------------------------------------

class WorldNode
{
public:
  double pos[2];
  double speed[2];
  double lastClock;
  
  double receiveRange;

  double minPos[2], maxPos[2];

  void getPos(double clock, double xy[2]) {
    assert( clock >= lastClock);
    for(int i=0;i<2;i++) {
      pos[i] += speed[i] * (clock-lastClock);
      for(;;) {
	if(pos[i] < minPos[i])
	  pos[i] = minPos[i] - pos[i];
	else if (pos[i] > maxPos[i])
	  pos[i] = maxPos[i] - pos[i];
	else break;
      }
      xy[i] = pos[i];
    }
    lastClock=clock;
  }

};

//---------------------------------------------------------------------------

static double randomDouble(double minValue = 0.0, double maxValue = 1.0)
{ return minValue + (maxValue - minValue) * drand48(); }

class World
{
public:
  World(int aMaxNode, double aWidth, double aHeight, 
	double aMinRange, double aMaxRange, double aMaxSpeed) 
    : nbNode(aMaxNode), width(aWidth), height(aHeight),
      minRange(aMinRange), maxRange(aMaxRange), maxSpeed(aMaxSpeed)
  { 
    for(int i=0;i<nbNode;i++)
      nodeArray.push_back(NULL);
  }
  
  void create(int nodeIdx)
  {
    assert(inrange(0, nodeIdx, nbNode));
    assert(nodeArray[nodeIdx] == NULL);
    
    WorldNode* node = new WorldNode;
    node->pos[0] = randomDouble(0, width);
    node->minPos[0] = 0.0;
    node->maxPos[0] = width;
    node->pos[1] = randomDouble(0, height);
    node->minPos[1] = 0.0;
    node->maxPos[1] = height;
    node->lastClock = 0.0;
    node->receiveRange = randomDouble(minRange, maxRange);
    node->speed[0] = randomDouble(0, maxSpeed);
    node->speed[1] = randomDouble(0, maxSpeed);

    nodeArray[nodeIdx] = node;
  }

  void getReceiverList(int nodeIdx, double clock, std::list<int>& resultList) 
  {
    double xy[2];
    nodeArray[nodeIdx]->getPos(clock, xy);
    for(int i=0;i<nbNode;i++) {
      if(nodeArray[i] != NULL) {
	double otherXY[2];
	nodeArray[i]->getPos(clock, otherXY);
	double dx = xy[0] - otherXY[0];
	double dy = xy[1] - otherXY[1];
	double d = nodeArray[i]->receiveRange;
	if (dx*dx+dy*dy <= d*d)
	  resultList.push_back(i);
      }
    }
  }

protected:
  int nbNode;
  std::vector<WorldNode*> nodeArray;

  double width, height, minRange, maxRange, maxSpeed;
};

//---------------------------------------------------------------------------
