//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _GENERAL_H
#define _GENERAL_H

//---------------------------------------------------------------------------

#include "base.h"

#include <assert.h>

#include <cstdlib>
#include <string>
#include "mystream.h"
#include <vector>
#include <list>

using std::string;
using std::vector;
using std::list;

//---------------------------------------------------------------------------
//
/// General: 
/// - owning one reference, indicated by /* owned */,
///    means that the reference belongs to the caller
/// - borrowing one reference, indicated by /* borrowed */,
///    means that the reference belongs to the callee, and
///    hence must be freed
/// - Some interfaces, like ISystemFactory, are (more or less) pure
/// abstract interface: their name is prefixed by "I".
//---------------------------------------------------------------------------

// because VC++6 doesn't have std::min
template <class T>
T myMin(T x, T y)
{ if (x<y) return x; else return y; }

template <class T>
T myMax(T x, T y)
{ if (x>y) return x; else return y; }

//---------------------------------------------------------------------------

extern string strReplace(string data, string before, string after);
extern string format3UInt(void* data);

//---------------------------------------------------------------------------

/// The type used to represent time in the system.
typedef double Time;

// The constant used to represent a time which will never happen.
const double TimeNever = 1e10;

typedef unsigned char octet;

/// A block of memory
class MemoryBlock
{
public:
  octet* data;
  int size;

  MemoryBlock(octet* initialData, int initialSize, bool shouldCopy)
  { 
    size = initialSize; 
    if (shouldCopy) {
      data = new octet[size];
      memcpy(data, initialData, size);
    } else data = initialData;
  }

  MemoryBlock(int initialSize);
  MemoryBlock* clone();
  ~MemoryBlock();
};

ostream& operator << (ostream& out, MemoryBlock& block);

/// Converts a Time into a byte holding mantissa/exponent, as
/// used in Vtime
int toMantissaExponentByte(Time value);

/// Converts a byte holding mantissa/exponent, as used in Vtime, into
/// a Time.
Time fromMantissaExponentByte(int valueAsByte);

//---------------------------------------------------------------------------

template <typename T>
static inline bool inrange(const T& minInclVal, T& val, const T& maxExclVal)
{ return (minInclVal <= val) && (val < maxExclVal); }

//---------------------------------------------------------------------------

const int PacketHeaderSize = 4; // @@743

const int MessageHeaderWithoutAddressSize = 8; // @@743-749

const int MessageTypeLimit = 256; // XXX@@
const int LinkCodeLimit = 16; // @@1613

typedef enum {
  UNSPEC_LINK = 0, // @@3621
  ASYM_LINK = 1,   // @@3623
  SYM_LINK = 2,    // @@3625
  LOST_LINK = 3    // @@3627
} LinkType;

static inline bool validLinkType(LinkType linkType)
{ 
  int linkTypeInt = (int)linkType;
  return inrange(0, linkTypeInt, 4);
} // @@3621-3627

#if 0
// XXX: already defined after
static inline const char* linkTypeToString(LinkType type)
{ 
  switch(type) {
  case UNSPEC_LINK: return "unspec-link";
  case ASYM_LINK: return "asym-link";
  case SYM_LINK: return "sym-link";
  case LOST_LINK: return "lost-link";
  default: return "???";
  }
}
#endif


static inline string linkTypeToString(LinkType linkType)
{ 
  switch(linkType) {
  case UNSPEC_LINK: return "unspec";
  case ASYM_LINK: return "asym";
  case SYM_LINK: return "sym";
  case LOST_LINK: return "lost";
  default:  return "???"; //XXX: Fatal("Impossible link type: " << (int)linkType);
  }
}


typedef enum {
  NOT_NEIGH = 0, // @@3631
  SYM_NEIGH = 1, // @@3633
  MPR_NEIGH = 2  // @@3635
} NeighborType;

static inline bool validNeighborType(NeighborType neighborType)
{
  int neighborTypeInt = (int)neighborType;
  return inrange(0, neighborTypeInt, 4); // @@3631-3635
}

static inline const string neighborTypeToString(NeighborType type)
{ 
  switch(type) {
  case NOT_NEIGH: return "not-neigh";
  case SYM_NEIGH: return "sym-neigh";
  case MPR_NEIGH: return "mpr-neigh";
  default: return "???";
  }
}


static inline NeighborType linkCodeToNeighborType(int linkCode)
{ 
  assert( inrange(0, linkCode, LinkCodeLimit) ); 
  return (NeighborType)(linkCode >> 2); 
} // @@1620

static inline LinkType linkCodeToLinkType(int linkCode)
{ 
  assert( inrange(0, linkCode, LinkCodeLimit) ); 
  return (LinkType)(linkCode & 3); 
} // @@1620

static inline int linkAndNeighborToCode(LinkType linkType,
					NeighborType neighborType)
{ 
  assert( validLinkType(linkType) );
  assert( validNeighborType(neighborType) );
  return ((int)linkType) | (((int)neighborType) << 2); 
}

typedef enum {
  HELLO_MESSAGE = 1, // @@3611
  TC_MESSAGE = 2,    // @@3613
  MID_MESSAGE = 3,   // @@3615
  HNA_MESSAGE = 4,    // @@3617
  GMA_MESSAGE =0x80,
  MI_MESSAGE = 0x81 
 } MessageType;

static inline const string messageTypeToString(MessageType type)
{ 
  static char resultCache[128]; //XXX: dangerous -- No longer, with 'string'
  switch(type) {
  case HELLO_MESSAGE: return "hello";
  case TC_MESSAGE: return "tc";
  case MID_MESSAGE: return "mid";
  case HNA_MESSAGE: return "hna";
  default: sprintf(resultCache, "0x%02x", type); return resultCache;
  }
}

const int MaxTTL = 255; // @@2403,

typedef enum {
  WILL_NEVER = 0,   // @@3657
  WILL_LOW = 1,     // @@3659
  WILL_DEFAULT = 3, // @@3661
  WILL_HIGH = 6,    // @@3663
  WILL_ALWAYS = 7   // @@3665
} Willingness;


typedef enum {
  TC_REDUNDANCY_BASIC=0,   // @@3317 
  TC_REDUNDANCY_EXTENDED=1,// @@3321
  TC_REDUNDANCY_FULL=2     // @@3325
}TC_redundancy;

const int MaxPacketSequenceNumber = (1<<16); // 16 bits - @@XXX
const int MaxANSN = (1<<16); // 16 bits - @@XXX
const int MaxValue  = (1<<16); // 16 bits - @@XXX

extern bool _ansnGreater(int s1, int s2);

const double HYST_THRESHOLD_HIGH = 0.8;
const double HYST_THRESHOLD_LOW  = 0.3;
const double HYST_SCALING = 0.5;

//---------------------------------------------------------------------------

const double DefaultFreeSpaceSplittingProportionLimit = 0.3; // 30%

const double DefaultLocalSplittingProportionLimit = 0.1;     // 10%
  
const double DefaultGlobalSplittingProportionLimit = 0.5;    // 50%

//---------------------------------------------------------------------------

#define BeginMacro do {
#define EndMacro } while(0)

#define UNUSED(x) BeginMacro (x)=(x); EndMacro

//---------------------------------------------------------------------------

extern ostream* createLogFile(string fileTemplate, string infix);

//---------------------------------------------------------------------------

extern bool stringStartsWith(string a, string b);
extern bool stringEndsWith(string a, string b);
extern string strReplace(string data, string before, string after);
extern string stringReplace(const string& aLine, const string& before, 
			    const string& after);
extern vector<string> stringSplit(string aLine, string charSet);

extern string stringBitAnd(string a, string b);
extern string stringBitNot(string a);
extern string makeStringBitMaskNetworkOrder(int size, int prefix);
extern string stringStrip(string a, string charSet);
extern string stringLower(string a);

//---------------------------------------------------------------------------

//extern double drawRandomDouble();

extern double drawDouble(double maxValue);

extern double getTimeOfDay();

//---------------------------------------------------------------------------
// defined in md5sum.cc, not general.cc:

extern string getMD5(string data);
extern string getHexMD5(string data);

//---------------------------------------------------------------------------

#ifdef UNDER_CE
#define errno  (WSAGetLastError())
extern char* strerror(int errorCode);
#endif

#endif // _GENERAL_H
