//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _GENERAL_PLUGIN_H
#define _GENERAL_PLUGIN_H

//---------------------------------------------------------------------------

#include "base.h"

#include <protocol-plugin-api.h>

extern PPA_PlugeeApi* simulatorApi; 

extern void pluginSchedulerCallBack(void* data1, void* data2, void* data3);

//---------------------------------------------------------------------------

#endif // _GENERAL_PLUGIN_H
