//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This is the interface to "observe" events of the OLSR protocol
//---------------------------------------------------------------------------

#ifndef _PROTOCOL_OBSERVER_H
#define _PROTOCOL_OBSERVER_H

//---------------------------------------------------------------------------

#include "base.h"

#include <string>
#include <vector>
//#include <pair>

using std::string;
using std::vector;
using std::pair;

//---------------------------------------------------------------------------

class Node;

class ITupleSubject
{
public:
  virtual string getTupleName() = 0;
#if 0
  virtual int countField() = 0;
  virtual string getFieldName(int index) = 0;
  virtual string getFieldValue(int index) = 0;
#endif
  virtual vector< string >* getContent(Node*, bool) = 0; /* owned*/
};

//---------------------------------------------------------------------------

class IProtocolObserver;

typedef pair<string,string> StringPair;

class IProtocolSubject
{
public:
  virtual void attach(IProtocolObserver* observer,
		      bool observeMajorTupleChange,
		      bool observeMinorTupleChange) = 0;
  //		      bool observeEvent) = 0;
  virtual void detach(IProtocolObserver* observer) = 0;

  virtual vector<string>* getTableNameList()= 0; /* result is borrowed */
  virtual vector<vector<string>*>* getTableContent(string name) = 0;
};

class IProtocolObserver
{
public:
  /// change type is:
  /// "addition", "removal" or "change"
  virtual void notifyTupleChange(string changeType,
				 ITupleSubject* subject) = 0;
#if 0
  virtual notifyPacketReception(string packet, string sourceAddress);
  virtual notifyPacketTransmission(string packet, 
				   string interfaceAddress);
#endif
};

//---------------------------------------------------------------------------

class DumpProtocolObserver : public IProtocolObserver
{
public:
  ostream& out;
  Node* node;
  DumpProtocolObserver(Node *aNode, ostream& output) 
    : out(output), node(aNode) {}
  virtual void notifyTupleChange(string changeType,
				 ITupleSubject* subject) = 0;
};


//---------------------------------------------------------------------------

#endif /* _PROTOCOL_OBSERVER_H */

//---------------------------------------------------------------------------
