//-----------------------------------------------------------------*- c++ -*-
//                             OOLSR
//               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SYSTEM_LINUX_H
#define _SYSTEM_LINUX_H

//---------------------------------------------------------------------------

#include "general.h"
#include "address.h"
#include "network_generic.h"
#include "scheduler_unix.h"

//---------------------------------------------------------------------------

//#include "http_support.cc"

class LinuxLowLevel
{
public:
  static void setSocketReuseAddr(int sd);

  static void setSocketBroadcast(int sd);

  static void addRoute(int family, int ifaceIndex, Address destIpAddress,
		       Address gatewayAddress, Address netMaskAddress, 
		       int metric, bool notFatal);

  static void removeRoute(int family, int ifaceIndex, Address destIpAddress,
			  Address gatewayAddress, Address netMaskAddress, 
			  int metric, bool notFatal);

protected:

  static int modifyRoute( int action, int flags, int family, int ifaceIndex,
			  Address destIpAddress,
			  Address gatewayAddress, Address netMaskAddress, 
			  int metric, bool notFatal);
  static int prefix_length(int family, void *anetmask);
  static int get_system_reply(int sockFd, int seqNum, bool notFatal);
  static int addattr(struct nlmsghdr* header, int type, void* data, int alen);
};

//---------------------------------------------------------------------------

template <class LowLevel>
class LinuxAddressFactory : public AddressFactory
{
public:

  typedef typename LowLevel::SystemAddress SystemAddress;

  LinuxAddressFactory() : AddressFactory(LowLevel::AddressSize)
  {}

  Address makeAddress(SystemAddress& systemAddress) 
  { return Address(this, LowLevel::systemAddressToRawAddress(systemAddress)); }

  void makeSystemAddress(Address address, SystemAddress& result)
  { LowLevel::rawAddressToSystemAddress(address.getRawAddress(), result); }

  virtual Address parseAddress(string textString) {
    SystemAddress systemAddress;
    LowLevel::strToAddress(systemAddress, textString);
    return makeAddress(systemAddress);
  }

  virtual void write(ostream& out, const Address& address)
  {
    typename LowLevel::SystemAddress systemAddress;
    LowLevel::rawAddressToSystemAddress(address.getRawAddress(),
					systemAddress);
    char strAddress[4096]; // XXX
    LowLevel::reprAddress(systemAddress, strAddress);
    out << strAddress;
  }
};

//---------------------------------------------------------------------------

template<class LowLevel>
class LinuxSystemIface : public ISystemIface, public IFdHandler
{
public:
  IOScheduler* scheduler;
  LinuxAddressFactory<LowLevel>* addressFactory;
  IPacketReceiver* packetReceiver;
  Address address;
  string strOutputAddress;
  unsigned int port;
  unsigned int recvPort;

  virtual ~LinuxSystemIface() { }

  LinuxSystemIface(string aIfaceName, Address aAddress, int aIfaceIndex,
		   IOScheduler* aScheduler,
		   LinuxAddressFactory<LowLevel>* aFactory,
		   string aStrOutputAddress, 
		   IfaceConfig* aIfaceConfig, 
		   unsigned int aPort);

#ifdef LINK_MONITORING
  int getSignalLevel(Address txAddress);
#endif

  virtual void openSocket(IPacketReceiver* aPacketReceiver);
  
  virtual void sendPacket(MemoryBlock* packet);

  virtual int getMTU()
  { return ifaceConfig->mtu; }

  virtual Address getAddress()
  { return address; }

  // IFdHandler
  virtual FileDescriptor getFileDescriptor() { return inputSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; } // XXX:  check
  virtual void handleInput();
  virtual void handleOutput() { Fatal("Impossible call to handleOutput"); }
  virtual void handleExcept() { Fatal("Impossible call to handleExcept"); }

  // borrowed
  string getName() { return name; }

public:
  int ifaceIndex;

protected:
  typename LowLevel::SystemAddress sendSystemAddress;
  int inputSocket;
  int outputSocket;
#ifdef LINK_MONITORING
  int signalSocket;
#endif
  string name; // system name of the interface
};

//---------------------------------------------------------------------------

extern ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig);
extern ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig);
extern void startHTTPServer(IOScheduler* scheduler, Node* node);

//---------------------------------------------------------------------------

#endif // _SYSTEM_LINUX_H
