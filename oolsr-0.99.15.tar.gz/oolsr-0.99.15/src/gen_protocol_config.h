//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//---------------------------------------------------------------------------
// Parts of this file automatically were generated
// Template: template_protocol_config.h
// Date: Wed Oct 20 14:41:13 2004
// User: adjih
// Command: generateProtocolConfig.py
//---------------------------------------------------------------------------
// DO NOT MODIFY THIS FILE - CHANGES COULD BE LOST
// - SINCE IT WAS AUTOMATICALLY GENERATED
//---------------------------------------------------------------------------

#ifndef _GEN_PROTOCOL_CONFIG_H
#define _GEN_PROTOCOL_CONFIG_H

//---------------------------------------------------------------------------

using std::string;

#include <map>
#include <string>
#include <vector>
#include "mystream.h"
#include <list>

//#include "address.h"
#include "general.h"

//---------------------------------------------------------------------------

class ParseError
{
public: 
  ParseError(string aError) : error(aError) {}
  string error;
};

#define ThrowParseError(x) \
    BeginMacro \
      ostringstream message; \
      message << x; \
      throw (ParseError(message.str())); \
    EndMacro

static inline bool parseBool(string data)
{ return atoi(data.c_str())>0; }

static inline string parseString(string data)
{ return data; }

static inline int parseInt(string data)
{ 
  char* info=NULL;
  int result = strtol(data.c_str(), &info, 0);
  if (*info != '\0')
    ThrowParseError("Cannot parse integer: " << data);
  else return result;
}
//{ return atoi(data.c_str()); }

static inline double parseFloat(string data)
{ return atof(data.c_str()); /* XXX: error handling */ }

extern std::vector<string> stringSplit(string aLine, string charSet);

static inline std::list< std::pair<string,string> > parseHNAList(string data)
{ 
  std::list< std::pair<string,string> > result;
  string dashSeparator = "/";
  string semiColonSeparator = ";";

  std::vector<string> hnaStrList = stringSplit(data, semiColonSeparator);
  for (std::vector<string>::iterator it = hnaStrList.begin();
       it != hnaStrList.end();it++) {
    std::vector<string> oneHNA = stringSplit((*it), dashSeparator);
    assert (oneHNA.size() == 2);
    result.push_back( std::pair<string,string> (oneHNA[0], oneHNA[1]) );
  }
  return result;
}

static inline ostream& operator << 
  (ostream& out, std::list< std::pair< string, string> > data)
{
  bool isFirst = true;
  out << "(";
  for (std::list< std::pair< string, string> >::iterator it = data.begin();
       it != data.end(); it++) {
    if (!isFirst) 
      out << ", ";
    else isFirst = false;
    out << (*it).first << "/" << (*it).second ;
  }
  out << ")";
  return out;
}
					 

//--------------------------------------------------

class GeneratedLog
{
public:
  bool lWarning;
  bool lEvent;
  bool lEventStrategy;
  bool lPacket;
  bool lMessage;
  bool lPacketContent;
  bool lState;
  bool lPacketProcessing;
  bool lExpiration;
  bool lConfig;
  bool lRoute;
  bool lMulticast;


  GeneratedLog() { setDefaultValue(); }

  void setDefaultValue() {
    lWarning = 0;
    lEvent = 1;
    lEventStrategy = 1;
    lPacket = 1;
    lMessage = 1;
    lPacketContent = 1;
    lState = 1;
    lPacketProcessing = 1;
    lExpiration = 1;
    lConfig = 1;
    lRoute = 1;
    lMulticast = 1;

  }

  void setAllDefaultValue(bool value) {
    lWarning = value;
    lEvent = value;
    lEventStrategy = value;
    lPacket = value;
    lMessage = value;
    lPacketContent = value;
    lState = value;
    lPacketProcessing = value;
    lExpiration = value;
    lConfig = value;
    lRoute = value;
    lMulticast = value;

  }

  void write(ostream& out) const
  {
    out  << "log-warning " << lWarning  << "; "  << "log-event " << lEvent  << "; "  << "log-event-strategy " << lEventStrategy  << "; "  << "log-packet " << lPacket  << "; "  << "log-message " << lMessage  << "; "  << "log-packet-content " << lPacketContent  << "; "  << "log-state " << lState  << "; "  << "log-packet-processing " << lPacketProcessing  << "; "  << "log-expiration " << lExpiration  << "; "  << "log-config " << lConfig  << "; "  << "log-route " << lRoute  << "; "  << "log-multicast " << lMulticast ;
  }
};

//--------------------------------------------------

class GeneratedIfaceConfig
{
public:
  GeneratedIfaceConfig() { setDefaultValue(); }

  double localSplittingProportionLimit;
  int mtu;


  void setDefaultValue() {
    localSplittingProportionLimit = 0.3;
    mtu = 1024;

  }

  string parseData(std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    else if (data[0] == "local-splitting-proportion-limit") {
      localSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "mtu") {
      mtu = parseInt(data[1]);
    }  else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out  << "local-splitting-proportion-limit " << localSplittingProportionLimit  << "; "  << "mtu " << mtu ;
  }
};

class GeneratedProtocolConfig
{
public:
  GeneratedProtocolConfig() { setDefaultValue(); }

  double HELLO_INTERVAL;
  double REFRESH_INTERVAL;
  double TC_INTERVAL;
  double MID_INTERVAL;
  double HNA_INTERVAL;
  double NEIGHB_HOLD_TIME;
  double TOP_HOLD_TIME;
  double DUP_HOLD_TIME;
  double MID_HOLD_TIME;
  double HNA_HOLD_TIME;
  double MAXJITTER;
  int willingness;
  int tc_redundancy;
  int mpr_coverage;
  int multicastType;
  double strategyInterval;
  double hyst_threshold_high;
  double hyst_threshold_low;
  double hyst_scaling;
  int signal_threshold_high;
  int signal_threshold_low;
  bool useHysteresisMonitoring;
  bool useSignalMonitoring;
  bool delayGeneration;
  double freeSpaceSplittingProportionLimit;
  double globalSplittingProportionLimit;
  bool immediateMessageTransmission;
  string mainIface;
  bool ipv4;
  bool ipv6;
  string logFileName;
  bool onlyParseConfig;
  bool noLog;
  double startTime;
  double stopTime;
  bool noRouteCalculation;
  bool fastRouteCalculation;
  double routeCalculationStartTime;
  bool noFork;
  int udpPort;
  int httpAdminPort;
  string ipv6MulticastAddress;
  string ipv6AddressFilter;
  string ipv4MulticastAddress;
  bool noRouteSetup;
  bool ignoreRouteSetupError;
  std::list< std::pair<string,string> > hnaList;
  double GMA_INTERVAL;
  double MEMBERSHIP_VALID_TIME;


  void setDefaultValue() {
    HELLO_INTERVAL = 1.0;
    REFRESH_INTERVAL = 2.0;
    TC_INTERVAL = 5.0;
    MID_INTERVAL = 5.0;
    HNA_INTERVAL = 5.0;
    NEIGHB_HOLD_TIME = 6.0;
    TOP_HOLD_TIME = 15.0;
    DUP_HOLD_TIME = 30.0;
    MID_HOLD_TIME = 15.0;
    HNA_HOLD_TIME = 15.0;
    MAXJITTER = 0.25;
    willingness = 3;
    tc_redundancy = 0;
    mpr_coverage = 1;
    multicastType = -1;
    strategyInterval = 0.05;
    hyst_threshold_high = 0.8;
    hyst_threshold_low = 0.3;
    hyst_scaling = 0.5;
    signal_threshold_high = -85;
    signal_threshold_low = -94;
    useHysteresisMonitoring = 0;
    useSignalMonitoring = 0;
    delayGeneration = 0;
    freeSpaceSplittingProportionLimit = 0.5;
    globalSplittingProportionLimit = 0.5;
    immediateMessageTransmission = 0;
    mainIface = "";
    ipv4 = 1;
    ipv6 = 0;
    logFileName = "tmp/olsr.%s";
    onlyParseConfig = 0;
    noLog = 0;
    startTime = -1.0;
    stopTime = -1.0;
    noRouteCalculation = 0;
    fastRouteCalculation = 0;
    routeCalculationStartTime = 0.0;
    noFork = 1;
    udpPort = 698;
    httpAdminPort = 11698;
    ipv6MulticastAddress = "ff02::1";
    ipv6AddressFilter = "";
    ipv4MulticastAddress = "255.255.255.255";
    noRouteSetup = 0;
    ignoreRouteSetupError = 1;
    GMA_INTERVAL = 3;
    MEMBERSHIP_VALID_TIME = 9;

  }

  string parseData(GeneratedLog& log, std::vector<string>& data) {
    if (data.size() < 2) return "not enough arguments";
    else if (data[0] == "hello-interval") {
      HELLO_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "refresh-interval") {
      REFRESH_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "tc-interval") {
      TC_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "mid-interval") {
      MID_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "hna-interval") {
      HNA_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "neighb-hold-time") {
      NEIGHB_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "top-hold-time") {
      TOP_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "dup-hold-time") {
      DUP_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "mid-hold-time") {
      MID_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "hna-hold-time") {
      HNA_HOLD_TIME = parseFloat(data[1]);
    } else if (data[0] == "maxjitter") {
      MAXJITTER = parseFloat(data[1]);
    } else if (data[0] == "willingness") {
      willingness = parseInt(data[1]);
    } else if (data[0] == "tc-redundancy") {
      tc_redundancy = parseInt(data[1]);
    } else if (data[0] == "mpr-coverage") {
      mpr_coverage = parseInt(data[1]);
    } else if (data[0] == "multicast-type") {
      multicastType = parseInt(data[1]);
    } else if (data[0] == "strategy-interval") {
      strategyInterval = parseFloat(data[1]);
    } else if (data[0] == "hyst-threshold-high") {
      hyst_threshold_high = parseFloat(data[1]);
    } else if (data[0] == "hyst-threshold-low") {
      hyst_threshold_low = parseFloat(data[1]);
    } else if (data[0] == "hyst-scaling") {
      hyst_scaling = parseFloat(data[1]);
    } else if (data[0] == "signal-threshold-high") {
      signal_threshold_high = parseInt(data[1]);
    } else if (data[0] == "signal-threshold-low") {
      signal_threshold_low = parseInt(data[1]);
    } else if (data[0] == "use-hysteresis-monitoring") {
      useHysteresisMonitoring = parseBool(data[1]);
    } else if (data[0] == "use-signal-monitoring") {
      useSignalMonitoring = parseBool(data[1]);
    } else if (data[0] == "delay-generation") {
      delayGeneration = parseBool(data[1]);
    } else if (data[0] == "free-space-splitting-proportion-limit") {
      freeSpaceSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "global-splitting-proportion-limit") {
      globalSplittingProportionLimit = parseFloat(data[1]);
    } else if (data[0] == "immediate-message-transmission") {
      immediateMessageTransmission = parseBool(data[1]);
    } else if (data[0] == "main-iface") {
      mainIface = parseString(data[1]);
    } else if (data[0] == "ipv4") {
      ipv4 = parseBool(data[1]);
    } else if (data[0] == "ipv6") {
      ipv6 = parseBool(data[1]);
    } else if (data[0] == "log-file-name") {
      logFileName = parseString(data[1]);
    } else if (data[0] == "only-parse-config") {
      onlyParseConfig = parseBool(data[1]);
    } else if (data[0] == "no-log") {
      noLog = parseBool(data[1]);
    } else if (data[0] == "start-time") {
      startTime = parseFloat(data[1]);
    } else if (data[0] == "stop-time") {
      stopTime = parseFloat(data[1]);
    } else if (data[0] == "no-route-calculation") {
      noRouteCalculation = parseBool(data[1]);
    } else if (data[0] == "fast-route-calculation") {
      fastRouteCalculation = parseBool(data[1]);
    } else if (data[0] == "route-calculation-start-time") {
      routeCalculationStartTime = parseFloat(data[1]);
    } else if (data[0] == "no-fork") {
      noFork = parseBool(data[1]);
    } else if (data[0] == "udp-port") {
      udpPort = parseInt(data[1]);
    } else if (data[0] == "http-admin-port") {
      httpAdminPort = parseInt(data[1]);
    } else if (data[0] == "ipv6-multicast-address") {
      ipv6MulticastAddress = parseString(data[1]);
    } else if (data[0] == "ipv6-address-filter") {
      ipv6AddressFilter = parseString(data[1]);
    } else if (data[0] == "ipv4-multicast-address") {
      ipv4MulticastAddress = parseString(data[1]);
    } else if (data[0] == "no-route-setup") {
      noRouteSetup = parseBool(data[1]);
    } else if (data[0] == "ignore-route-setup-error") {
      ignoreRouteSetupError = parseBool(data[1]);
    } else if (data[0] == "hna-list") {
      hnaList = parseHNAList(data[1]);
    } else if (data[0] == "log-warning") {
      log.lWarning = parseBool(data[1]);
    } else if (data[0] == "log-event") {
      log.lEvent = parseBool(data[1]);
    } else if (data[0] == "log-event-strategy") {
      log.lEventStrategy = parseBool(data[1]);
    } else if (data[0] == "log-packet") {
      log.lPacket = parseBool(data[1]);
    } else if (data[0] == "log-message") {
      log.lMessage = parseBool(data[1]);
    } else if (data[0] == "log-packet-content") {
      log.lPacketContent = parseBool(data[1]);
    } else if (data[0] == "log-state") {
      log.lState = parseBool(data[1]);
    } else if (data[0] == "log-packet-processing") {
      log.lPacketProcessing = parseBool(data[1]);
    } else if (data[0] == "log-expiration") {
      log.lExpiration = parseBool(data[1]);
    } else if (data[0] == "log-config") {
      log.lConfig = parseBool(data[1]);
    } else if (data[0] == "log-route") {
      log.lRoute = parseBool(data[1]);
    } else if (data[0] == "log-multicast") {
      log.lMulticast = parseBool(data[1]);
    } else if (data[0] == "gma-interval") {
      GMA_INTERVAL = parseFloat(data[1]);
    } else if (data[0] == "membership-valid-time") {
      MEMBERSHIP_VALID_TIME = parseFloat(data[1]);
    }  else {
      return "Cannot parse XXX";
    }
    return "";
  }

  void write(ostream& out) const
  {
    out  << "hello-interval " << HELLO_INTERVAL  << "; "  << "refresh-interval " << REFRESH_INTERVAL  << "; "  << "tc-interval " << TC_INTERVAL  << "; "  << "mid-interval " << MID_INTERVAL  << "; "  << "hna-interval " << HNA_INTERVAL  << "; "  << "neighb-hold-time " << NEIGHB_HOLD_TIME  << "; "  << "top-hold-time " << TOP_HOLD_TIME  << "; "  << "dup-hold-time " << DUP_HOLD_TIME  << "; "  << "mid-hold-time " << MID_HOLD_TIME  << "; "  << "hna-hold-time " << HNA_HOLD_TIME  << "; "  << "maxjitter " << MAXJITTER  << "; "  << "willingness " << willingness  << "; "  << "tc-redundancy " << tc_redundancy  << "; "  << "mpr-coverage " << mpr_coverage  << "; "  << "multicast-type " << multicastType  << "; "  << "strategy-interval " << strategyInterval  << "; "  << "hyst-threshold-high " << hyst_threshold_high  << "; "  << "hyst-threshold-low " << hyst_threshold_low  << "; "  << "hyst-scaling " << hyst_scaling  << "; "  << "signal-threshold-high " << signal_threshold_high  << "; "  << "signal-threshold-low " << signal_threshold_low  << "; "  << "use-hysteresis-monitoring " << useHysteresisMonitoring  << "; "  << "use-signal-monitoring " << useSignalMonitoring  << "; "  << "delay-generation " << delayGeneration  << "; "  << "free-space-splitting-proportion-limit " << freeSpaceSplittingProportionLimit  << "; "  << "global-splitting-proportion-limit " << globalSplittingProportionLimit  << "; "  << "immediate-message-transmission " << immediateMessageTransmission  << "; "  << "main-iface " << mainIface  << "; "  << "ipv4 " << ipv4  << "; "  << "ipv6 " << ipv6  << "; "  << "log-file-name " << logFileName  << "; "  << "only-parse-config " << onlyParseConfig  << "; "  << "no-log " << noLog  << "; "  << "start-time " << startTime  << "; "  << "stop-time " << stopTime  << "; "  << "no-route-calculation " << noRouteCalculation  << "; "  << "fast-route-calculation " << fastRouteCalculation  << "; "  << "route-calculation-start-time " << routeCalculationStartTime  << "; "  << "no-fork " << noFork  << "; "  << "udp-port " << udpPort  << "; "  << "http-admin-port " << httpAdminPort  << "; "  << "ipv6-multicast-address " << ipv6MulticastAddress  << "; "  << "ipv6-address-filter " << ipv6AddressFilter  << "; "  << "ipv4-multicast-address " << ipv4MulticastAddress  << "; "  << "no-route-setup " << noRouteSetup  << "; "  << "ignore-route-setup-error " << ignoreRouteSetupError  << "; "  << "hna-list " << hnaList  << "; "  << "gma-interval " << GMA_INTERVAL  << "; "  << "membership-valid-time " << MEMBERSHIP_VALID_TIME ;
  }

  std::map<string,GeneratedIfaceConfig*> ifaceConfig;
};

//---------------------------------------------------------------------------

#endif /*_GEN_PROTOCOL_CONFIG_H*/

