#---------------------------------------------------------------------------
#                               OOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2004 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import sys, os, re
import SimulationUtil, Check

#---------------------------------------------------------------------------

tmpDir = "./tmp"

#---------------------------------------------------------------------------

if os.environ.has_key("SIMULPROG"):
    simulProg = os.environ["SIMULPROG"]

argList = sys.argv[1:]

if len(argList) == 0: USAGE

if argList[0] == "--auto-check":
    argList = argList[1:]
    forceCheck = True
else: forceCheck = False

rComment = re.compile(r"([^#]*)(#.*)?")

if os.path.exists(argList[0]):
    data = open(argList[0]).read()
    dataList = [ rComment.match(line).group(1) 
                 for line in data.split("\n")]
    data = "\n".join(dataList)
    
    fileName = argList[0].replace(".scenario","")    
else:
    data = " ".join(argList)
    fileName = "inline"

scenarioList = SimulationUtil.parseSeveralScenario(data)

try: os.mkdir(tmpDir)
except: pass # XXX already exists only

for scenarioName, (nodeList, ifaceList, matrix, checkList,
                   nodeConfigTable) in scenarioList:
    fileName = os.path.basename(fileName)
    resultDir = tmpDir+"/"+fileName+"/"+scenarioName
    try: os.mkdir(tmpDir+"/"+fileName)
    except: pass # XXX already exists only    
    try: os.mkdir(resultDir)
    except: pass # XXX already exists only
    f = open(resultDir+"/scenario", "w")
    #print resultDir, nodeTable, realLinkList
    maxNodeIdx = max(nodeList)
    f.write("%s %s %s %s\n"
            % (maxNodeIdx+1, len(nodeList), len(matrix), len(checkList)))
    for nodeIdx in nodeList:
        f.write("  %s %s %s\n" % (nodeIdx, max(ifaceList[nodeIdx])+1,
                                  nodeConfigTable.get(nodeIdx, "")))
    matrix.sort()
    for (clock, isUp, (src1, dst1), (src2, dst2)) in matrix:
        f.write("%s %s %s %s %s %s\n" % (src1,dst1,src2,dst2,clock,int(isUp)))
    for info in checkList:
        f.write("%s %s\n" % (info[0], "check" in info))
    f.close()

    #print scenarioName, checkList
    
    okFileName= resultDir + "/ok"
    try: os.remove(okFileName)
    except: pass # XXX: does not exist

    outputFileName= resultDir + "/output"
    try: os.remove(outputFileName)
    except: pass # XXX: does not exist

    errorFileName= resultDir + "/errors"
    try: os.remove(errorFileName)
    except: pass # XXX: does not exist
    
    f = open(resultDir + "/.gdbinit", "w")
    if simulProg.startswith(".."): #XXX: Windows, MAC
        f.write("file ../../../"+simulProg+"\n")
    else: f.write("file "+simulProg+"\n")
    f.write("set lang c++\n")
    f.write("dir %s\n" % "../../../../include")
    f.write("set args --topology %s --output %s"
            % ("scenario","output"))    
    f.close()
    
    f = open(resultDir + "/.rungdb.el", "w")
    f.write('(gdb "gdb")')
    f.close()

    f = open(resultDir + "/emacsgdb.sh", "w")
    f.write("#! /bin/sh\nemacs -fn fixed -l ./.rungdb.el\n")
    f.close()
    os.chmod(resultDir+"/emacsgdb.sh", 0700)

    os.system("%s --quiet --topology %s --output %s && touch %s"
              #" && echo '%s passed' || echo '%s failed'"
              % (simulProg, resultDir+"/scenario", resultDir+"/output",
                 okFileName))
    #             fileName+":"+scenarioName,
    #             fileName+":"+scenarioName))
    s = fileName+":"+scenarioName
    if os.path.exists(okFileName):
        errorCount, checkCount = Check.parseAndCheck(outputFileName,
                                                     errorFileName, forceCheck)
        #os.system("XXX")
        if errorCount == 0:
            print "ok %s (%s checkpoints)" % (s, checkCount)
        else: print "FAILED %s - %s inconsistencies" % (s, errorCount)
    else:
        print "%s -> FAILED, execution" % s

#---------------------------------------------------------------------------
